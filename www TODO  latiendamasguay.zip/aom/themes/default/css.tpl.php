<?php
/********************************************************************
Associate-O-Matic v5.2.0
http://www.associate-o-matic.com

Justin Mecham
info@associate-o-matic.com

DESCRIPTION
Default CSS Template

IMPORTANT NOTE
You can edit any aspect of this template file to modify how the
/themes/[current theme]/css/style.css file is generated. Do NOT
directly edit the /themes/[current theme]/css/style.css file as
your changes will be overwritten when you save your settings from 
Control Panel.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/

$version = "5.2.0";

?>
html {margin:0; padding:0;}
body {
	margin:0;
	padding:0;
	width:<?php echo (strstr($this->css['Width'],"%") ? $this->css['Width'] : $this->css['Width']."px") ?>;
	min-width:<?php echo (($this->css['ColumnWidthLeft'] * 2) + $this->css['ColumnWidthRight']) ?>px;
	
	<?php if ($this->css['Alignment']=="Center"): ?>
  	margin-left:auto;
  	margin-right:auto;	
	<?php elseif ($this->css['Alignment']=="Left"): ?>
	margin-left:0;
  	margin-right:auto;
	<?php else: ?>
	margin-left:auto;
  	margin-right:0;
	<?php endif; ?>
		
	color:<?php echo $this->css['TextColor'] ?>;
	font-family:<?php echo $this->css['TextFont'] ?>;
	font-size:<?php echo $this->css['TextSize'] ?>;
	background-color:<?php echo $this->css['BgColor'] ?>;
	<?php
	if ($this->css['BgImage']!="") {
	?>
	background:url(<?php echo $this->css['BgImage'] ?>)<?php echo ($this->css['TileBgImage']=="Yes" ? "" :" no-repeat") ?> left top;
	<?php
	}				
	?>
}
img {border:0;}

<?php
// CORNERS:ROUNDED
if ($this->css['Corners']=="r") {
?>
#aom_body_content, #aom_body_content_l, #aom_body_content_r, #aom_body_content_n {-webkit-border-radius:7px; -moz-border-radius:7px; CCborderRadius:7px; -opera-border-radius:7px; -khtml-border-radius:7px; border-radius:7px;}
.aom_box_top, #aom_search {-webkit-border-top-left-radius:7px; -webkit-border-top-right-radius:7px; -moz-border-radius-topleft:7px; -moz-border-radius-topright:7px; CCborderRadiusTL:7px; CCborderRadiusTR:7px; -opera-border-top-left-radius:7px; -opera-border-top-right-radius:7px; -khtml-border-top-left-radius:7px; -khtml-border-top-right-radius:7px; border-top-left-radius:7px; border-top-right-radius:7px;}
.aom_box_bottom, #aom_breadcrumbs {-webkit-border-bottom-left-radius:7px; -webkit-border-bottom-right-radius:7px; -moz-border-radius-bottomleft:7px; -moz-border-radius-bottomright:7px; CCborderRadiusBL:7px; CCborderRadiusBR:7px; -opera-border-bottom-left-radius:7px; -opera-border-bottom-right-radius:7px; -khtml-border-bottom-left-radius:7px; -khtml-border-bottom-right-radius:7px; border-bottom-left-radius:7px; border-bottom-right-radius:7px; }

<?php
}
?>

#aom_header {padding:0; margin:0;}
#aom_content {padding-left:<?php echo $this->css['ColumnWidthLeft'] ?>px; padding-right:<?php echo $this->css['ColumnWidthRight'] ?>px;}
#aom_content_l {padding-left:<?php echo $this->css['ColumnWidthLeft'] ?>px;}
#aom_content_r {padding-right:<?php echo $this->css['ColumnWidthRight'] ?>px;}
#aom_content_n {}
#aom_content .column {position:relative; float:left;}
#aom_content_l .column {position:relative; float:left;}
#aom_content_r .column {position:relative; float:left;}
#aom_content_n .column {position:relative; float:left;}
#aom_body {width:100%;}
#aom_left {width:<?php echo $this->css['ColumnWidthLeft'] ?>px; right:<?php echo $this->css['ColumnWidthLeft'] ?>px; margin-left:-100%;}
#aom_right {width:<?php echo ($this->css['ColumnWidthRight']) ?>px; margin-right:-<?php echo $this->css['ColumnWidthRight'] ?>px;}
#aom_footer {clear:both;}
* html #aom_left {left:<?php echo ($this->css['ColumnWidthRight']) ?>px;} /*** IE6 Fix ***/
html>body #aom_content>#aom_left {*right:-<?php echo $this->css['ColumnWidthLeft'] ?>px;} /*** IE7 Fix ***/
html>body #aom_content_l>#aom_left {*right:0;} /*** IE7 Fix ***/

#aom_logo {margin:0; padding:0; width:100%; text-align:<?php echo $this->css['LogoAlignment'] ?>;}

#aom_search {margin:0; padding:4px 0; width:100%; float:left; background-color:<?php echo $this->css['MainColor'] ?>; color:<?php echo $this->css['MainColorInverse'] ?>; white-space:nowrap;}
#aom_search a:link {font-weight:normal; color:<?php echo $this->css['MainColorInverse'] ?>;} /*searchbar link*/
#aom_search a:hover {font-weight:normal; color:<?php echo $this->css['MainColorInverse'] ?>;} /*searchbar link*/
#aom_search a:active {font-weight:normal; color:<?php echo $this->css['MainColorInverse'] ?>;} /*searchbar link*/
#aom_search a:visited {font-weight:normal; color:<?php echo $this->css['MainColorInverse'] ?>;} /*searchbar link*/
.aom_sbt {font-weight:bold; padding:0 4px 0 8px;}
.aom_smenu {}
#aom_sleft {margin:0; padding:0; text-align:left; float:left;}
#aom_sright {margin:0; padding:4px 0 0 0; text-align:right; float:right;}

#aom_breadcrumbs {margin:0; padding:4px 0; width:100%; background-color:<?php echo $this->css['AccentColor'] ?>; float:left;}
#aom_breadcrumbs a {float:none; color:<?php echo $this->css['AccentColorInverse'] ?>;}
#aom_tabs {padding:0; margin-left:6px;}

.aom_l {padding:0 8px; font-weight:bold; color:<?php echo $this->css['AccentColorInverse'] ?>; text-align:left; float:left;} /*location*/
.aom_lt {color:<?php echo $this->css['AccentColorInverse'] ?>; float:left;} /*location text*/
.aom_lb {color:<?php echo $this->css['AccentColorInverse'] ?>;} /*location text*/
a:link.aom_lt {font-weight:normal; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*location link*/
a:hover.aom_lt {font-weight:normal; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*location link*/
a:active.aom_lt {font-weight:normal; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*location link*/
a:visited.aom_lt {font-weight:normal; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*location link*/

.aom_d {padding-right:12px; font-size:smaller; text-align:right; color:<?php echo $this->css['AccentColorInverse'] ?>; float:right;} /*date*/

#aom_body_content {padding:<?php echo $this->css['BodyPadding'] ?>px; margin:<?php echo $this->css['BodySpacingVertical'] ?>px <?php echo $this->css['BoxSpacingHorizontal'] ?>px 0 <?php echo $this->css['BoxSpacingHorizontal'] ?>px; background-color:<?php echo $this->css['BodyBgColor'] ?>; color:<?php echo $this->css['BodyBgColorInverse'] ?>; border:<?php echo $this->css['BodyBorderSize'] ?>px solid <?php echo $this->css['BodyBorderColor'] ?>;}
#aom_body_content_l {padding:<?php echo $this->css['BodyPadding'] ?>px; margin:<?php echo $this->css['BodySpacingVertical'] ?>px 0 0 <?php echo $this->css['BoxSpacingHorizontal'] ?>px; background-color:<?php echo $this->css['BodyBgColor'] ?>; color:<?php echo $this->css['BodyBgColorInverse'] ?>; border:<?php echo $this->css['BodyBorderSize'] ?>px solid <?php echo $this->css['BodyBorderColor'] ?>;}
#aom_body_content_r {padding:<?php echo $this->css['BodyPadding'] ?>px; margin:<?php echo $this->css['BodySpacingVertical'] ?>px <?php echo $this->css['BoxSpacingHorizontal'] ?>px 0 0; background-color:<?php echo $this->css['BodyBgColor'] ?>; color:<?php echo $this->css['BodyBgColorInverse'] ?>; border:<?php echo $this->css['BodyBorderSize'] ?>px solid <?php echo $this->css['BodyBorderColor'] ?>;}
#aom_body_content_n {padding:<?php echo $this->css['BodyPadding'] ?>px; margin:<?php echo $this->css['BodySpacingVertical'] ?>px 0 0 0; background-color:<?php echo $this->css['BodyBgColor'] ?>; color:<?php echo $this->css['BodyBgColorInverse'] ?>; border:<?php echo $this->css['BodyBorderSize'] ?>px solid <?php echo $this->css['BodyBorderColor'] ?>;}

.aom_home_welcome {padding:4px 0; display:block;}

.aom_home_mall {width:100%; display:table;}
.aom_home_mall_cat {margin-bottom:15px;}
.aom_home_mall ul {font-size:smaller; font-weight:bold; margin:0; padding:0;}
.aom_home_mall li {font-size:smaller; margin:0 0 0 2em; padding:2px 0 2px 2px; text-indent:-.9em;}
.aom_home_mall_col {float:left; width:33%;}

.aom_category {width:100%;}
h1 {font-size:18px; font-weight:bold; display:inline; color:<?php echo $this->css['BodyBgColorInverse'] ?>;}
h2 {font-size:16px; font-weight:bold; display:inline; color:<?php echo $this->css['BodyBgColorInverse'] ?>;}
#aom_sort {margin-top:15px;}
.aom_pagination {margin:8px 0; display:table;}
#aom_pagination a {text-decoration:none;}

#aom_items {width:100%; margin:0; padding:0;}
#aom_marketplace {width:100%; margin:0; padding:0;}
#aom_marketplace ul {list-style:none; margin:0; padding:10px 0 0 10px;}
#aom_marketplace li {list-style-type:none; margin:0 5px 0 0; padding:4px; float:left; width:auto; border-top:1px solid <?php echo $this->css['TabBorderColor'] ?>; border-left:1px solid <?php echo $this->css['TabBorderColor'] ?>; border-right:1px solid <?php echo $this->css['TabBorderColor'] ?>;}
.aom_marketplace_tab {font-weight:normal; font-size:smaller;}
#aom_headings {display:table; width:100%; margin:0; padding:4px 0 4px 0; background-color:#eaeaea; font-weight:bold;}
#aom_h_price {padding:4px; width:95px; float:left;}
#aom_h_condition {padding:4px; margin-left:4px; width:110px; float:left;}
#aom_h_buy {padding:4px; width:145px; float:left;}
#aom_h_seller {padding:4px; float:left;}
.aom_offer {display:block; width:100%; margin:0; padding:4px; background-color:#FFFFFF;}
.aom_o_price {display:block; margin:0; padding:4px; width:95px; float:left;}
.aom_o_condition {display:block; margin:0; padding:4px; margin-left:4px; width:110px; float:left;}
.aom_o_buy {display:block; margin:0; padding:4px; width:145px; float:left;}
.aom_o_seller {display:block; margin:0; padding:4px; width:285px; float:left; font-size:smaller; font-weight:bold;}
.aom_value {font-weight:normal;}
.aom_value_r {font-weight:normal; color:<?php echo $this->css['TextHighlightColor'] ?>;}
.aom_amazon {background-color:#F5F5F5; border:1px solid #CCCCCC;}

.aom_cond_N {font-weight:bold; font-size:larger; color:#8DD647;} /*new*/
.aom_cond_U {font-weight:bold; font-size:larger; color:#F79820;} /*used*/
.aom_cond_R {font-weight:bold; font-size:larger; color:#F81832;} /*refurbished*/
.aom_cond_C {font-weight:bold; font-size:larger; color:#1DA4DB;} /*collectible*/

.aom_item_category {margin:0; padding:8px 0 0 0; float:left; width:<?php echo floor(100/$this->css['CategoryColumns']) ?>%;}
.aom_item_category img {border:0;}
.aom_detail div {display:table;}

<?php
if (isset($this->css['ImageSizeCategory_width']))
	$ciwidth = $this->css['ImageSizeCategory_width'];
else if ($this->css['ImageSizeCategory']=="Small")
	$ciwidth = "75";
else if ($this->css['ImageSizeCategory']=="Tiny")
	$ciwidth = "110";
else if ($this->css['ImageSizeCategory']=="Medium")
	$ciwidth = "160";
else if ($this->css['ImageSizeCategory']=="Large")
	$ciwidth = "160";
?>

ul.aom_item{margin:10px 0; padding:0; list-style:none; float:left; width:100%; }
ul.aom_item li .aom_img {float:left; width:<?php echo ($ciwidth-10) ?>px; margin-right:10px; display:block; text-align:right; }
ul.aom_item li .aom_img img {margin-bottom:0; text-align:center; }
ul.aom_item li .aom_detail {margin-left:<?php echo $ciwidth+5 ?>px; margin-right:10px; width:auto; }
ul.aom_item li {float:none; margin:0; padding:0; list-style:none; border:0; width:auto; }

ul.aom_item .aom_lh {float:none; width:100%; list-style-type:none; margin:8px 0 0 0; padding:0;}
ul.aom_item .aom_lh li {float:left; margin:0; padding:0 6px 0 0;}
.aom_lv {width:100%; list-style-type:none; margin:6px 0; padding:0; display:table;}
.aom_lv li {margin:0; padding:6px 0 0 0; display:table;}

#aom_item_wrapper {margin:0; padding:0; width:100%;}
#aom_item_wrapper h1 {margin:0; padding:0; margin-bottom:10px; width:100%; display:block;}
#aom_item {margin:0; padding:0; width:100%;}
#aom_img {padding:0; margin:0; float:left; text-align:center;}
#aom_detail {padding:0; margin:0 0 0 10px; float:left; display:inline; width:300px;}
#aom_info hr {margin:15px 0; padding:0;}

.aom_category_blended {width:100%;}
#aom_title_blended {margin:0; padding:0 0 10px 0; width:100%; display:block;}
.aom_item_blended {width:33%; float:left; margin:5px 0 0 0; padding:0;}
.aom_item_blended ul {list-style:none; margin:0; padding:0;}
.aom_item_blended li {list-style-type:none; margin:0; padding:0;}
.aom_img_blended {float:left; margin:0; padding:0 6px 0 0;}
.aom_detail_blended {width:100%; margin:0; padding:0;}

.aom_swatches {display:table; margin-top:12px; padding:0;}
.aom_swatch {float:left; width:40px; height:55px; overflow:hidden; padding:0; margin:2px 5px; text-align:center;}
.aom_simg {padding:0; margin:0; width:40px; height:30px;}
.aom_simg img {vertical-align:bottom; margin:0; padding:0;}
.aom_swatch_other {float:left; min-width:75px; margin:0; padding:2px 5px; text-align:center;}

.aom_pics {display:table; margin:0; padding:0;}
.aom_pics ul {margin:0; padding:0; list-style:none; float:left; width:100%;}
.aom_pics li {list-style-type:none; text-align:center; float:left; width:150px; height:120px; overflow:hidden; margin:0; padding:0;}

#aom_page {width:100%; margin:0; padding:0;}
#aom_page div {margin:10px 0; padding:0; font-weight:bold;}
#aom_page li {margin:0; padding:2px;}

.aom_lv2 {width:100%; list-style-type:none; margin:6px 0; padding:0; display:table;}
.aom_lv2 li {margin:0; padding:0; display:table;}

.aom_hr {width:100%; display:table; margin:10px 0 6px 0; border:none 0; height:1px; border-top:<?php echo $this->css['LineSize'] ?>px <?php echo $this->css['LineType'] ?> <?php echo $this->css['LineColor'] ?>;} /*categories*/
.aom_hr2 {width:100%; display:table; clear:both; margin:0; border:none 0; height:4px; border-top:5px solid <?php echo $this->css['MainColor'] ?>;} /*marketplace*/
.aom_hrb {height:1px; border:0; color:#EAEAEA; background-color:#EAEAEA; width:100%;} /*boxes*/

.aom_btn {display:block; margin:10px 0;}
.aom_form {display:inline; margin-top:0px; margin-bottom:0px;}

#aom_cart {width:100%; padding:0; margin:0;}
#aom_cart h1 {margin:0; padding:0; margin-bottom:10px; width:100%; display:block;}
#aom_cart table {margin:0; padding:0; width:100%; border:1px solid <?php echo $this->css['MainColor'] ?>; border-collapse:collapse;}
#aom_cart td {padding:4px; margin:0; border:1px solid <?php echo $this->css['MainColor'] ?>; border-collapse:collapse;}
#aom_cart_headings {background-color:<?php echo $this->css['AccentColor'] ?>; color:<?php echo $this->css['AccentColorInverse'] ?>; font-weight:bold;}
.aom_cart_col1 {width:91px; text-align:center;}
.aom_cart_col2 {min-width:250px; text-align:left;}
.aom_cart_col3 {width:70px; text-align:center; white-space:nowrap;}
.aom_cart_col4 {width:70px; text-align:center; white-space:nowrap;}
.aom_cart_col5 {width:70px; text-align:right; white-space:nowrap;}
.aom_cart_col6 {width:70px; text-align:center;}
.aom_cart_col7 {width:70px; text-align:right; white-space:nowrap;}
.aom_cart_col8 {width:70px; text-align:center;}
.aom_cte {background-color:<?php echo $this->css['CartBgColorEven'] ?>; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>;}
a:link.aom_cte {font-weight:bold; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>;}
a:active.aom_cte {font-weight:bold; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>;}
a:hover.aom_cte {font-weight:bold; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>;}
a:visited.aom_cte {font-weight:bold; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>;}
.aom_cto {background-color:<?php echo $this->css['CartBgColorOdd'] ?>; color:<?php echo $this->css['CartBgColorOddInverse'] ?>;}
a:link.aom_cto {font-weight:bold; color:<?php echo $this->css['CartBgColorOddInverse'] ?>;}
a:active.aom_cto {font-weight:bold; color:<?php echo $this->css['CartBgColorOddInverse'] ?>;}
a:hover.aom_cto {font-weight:bold; color:<?php echo $this->css['CartBgColorOddInverse'] ?>;}
a:visited.aom_cto {font-weight:bold; color:<?php echo $this->css['CartBgColorOddInverse'] ?>;}

#aom_cart_subtotal {background-color:<?php echo $this->css['AccentColor'] ?>; color:<?php echo $this->css['AccentColorInverse'] ?>; font-weight:bold;}
#aom_cart_subtotal td {text-align:right;}
#aom_subtotal {background-color:<?php echo $this->css['CartBgColorEven'] ?>; color:<?php echo $this->css['CartBgColorEvenInverse'] ?>; font-weight:bold; font-size:larger; text-align:right;}
.aom_cts {color:#000000; font-weight:bold; background-color:#CCCCCC;} /*cart subtotal*/

.aom_cart_msg {font-weight:bold; color:#000000; background-color:#FFFFFF;}
.aom_cart_err {font-weight:bold; color:<?php echo $this->css['TextHighlightColor'] ?>; background-color:#FFFFFF;}
#aom_cart_buttons {width:100%; padding:0; margin-top:10px; text-align:center;}
#aom_cart_buttons span {padding:8px; margin:0;}

a:link {color:<?php echo $this->css['LinkColor'] ?>;}
<?php
if (isset($this->css['LinkHoverColor']) AND $this->css['LinkHoverColor']!="") {
?>
a:hover {color:<?php echo $this->css['LinkHoverColor'] ?>;}
<?php
}

if (isset($this->css['LinkVisitedColor']) AND $this->css['LinkVisitedColor']!="") {
?>a:visited {color:<?php echo $this->css['LinkVisitedColor'] ?>;}
<?php
}
?>
<?php if (isset($this->css['TextLogo']['Text'])): ?>
.aom_tl {text-align:<?php echo $this->css['LogoAlignment'] ?>; margin:7px 8px 2px 8px; font-family:<?php echo $this->css['TextLogo']['Font'] ?>; font-size:<?php echo $this->css['TextLogo']['Size'] ?>; font-weight:<?php echo $this->css['TextLogo']['Weight'] ?>; color:<?php echo $this->css['TextLogo']['Color'] ?>;} /*textlogo*/
<?php endif; ?>

.aom_e {color:<?php echo $this->css['TextHighlightColor'] ?>; font-family:<?php echo $this->css['TextFont'] ?>; font-weight:bold; font-size:14px; padding:6px;} /*error text*/

a.aom_il {font-weight:bold;} /*item link*/
a.aom_ilr {font-weight:normal;} /*item link regular*/

.aom_n {font-size:smaller; color:<?php echo $this->css['TextHighlightColor'] ?>; font-family:<?php echo $this->css['TextFont'] ?>; font-weight:bold;} /*new text*/

/*related category levels*/
.aom_r0 {padding:1px; padding-left:8px;}
.aom_r1 {padding:1px; padding-left:12px;}
.aom_r2 {padding:1px; padding-left:16px;}
.aom_r3 {padding:1px; padding-left:20px;}
.aom_r4 {padding:1px; padding-left:24px;}
.aom_r5 {padding:1px; padding-left:28px;}
.aom_r6 {padding:1px; padding-left:32px;}
.aom_r7 {padding:1px; padding-left:36px;}

.aom_pb {font-weight:bold; font-size:larger; color:<?php echo $this->css['TextHighlightColor'] ?>;} /*price buy*/
.aom_pl {font-weight:normal;} /*price list*/
.aom_po {font-size:smaller; font-weight:normal;} /*price onsale*/

.aom_sh {color:<?php echo $this->css['TextHighlightColor'] ?>; font-family:<?php echo $this->css['TextFont'] ?>; font-size:smaller;} /*shipping text*/
.aom_sl {font-weight:bold; text-align:left; margin-top:10px;} /*subtitle*/
.aom_slb {font-weight:bold; text-align:left; margin-top:10px; padding-right:10px;} /*subtitle*/
.aom_st {font-size:smaller; font-weight:bold; padding-right:4px;} /*subtext*/
.aom_st2 {font-size:smaller; font-weight:bold;} /*subtext*/
.aom_sto {font-size:smaller; font-weight:bold; color:#339900;} /*In Stock*/
.aom_stt {font-size:smaller; color:#999999;} /*price timestamp*/
.aom_sth {font-size:smaller; font-weight:bold; color:<?php echo $this->css['TextHighlightColor'] ?>;} /*subtext highlight*/
.aom_stn {font-size:smaller; font-weight:normal;} /*subtext norm*/
.aom_t {font-size:larger; font-weight:bold;} /*title*/
.aom_tr {font-weight:normal;} /*text regular*/
.aom_ts {font-size:smaller;} /*text small*/
.aom_smat {font-size:smaller; font-weight:bold;} /*subtitle subtitles*/
.aom_smap {font-weight:bold;} /*sitemap links*/
.aom_z {margin:2px; white-space:nowrap;} /*zoom link*/
.aom_z2 {width:100%; margin:2px; white-space:nowrap;} /*zoom link*/

.aom_dr {width:100%; text-align:center; margin:4px; padding:0; font-size:9px;} /*disclaimer*/

.aom_mto {font-weight:bold; padding:3px; border-right:#000000 1px solid; border-top:#000000 1px solid; background:<?php echo $this->css['MainColor'] ?>; border-left:#000000 1px solid; border-bottom:<?php echo $this->css['MainColor'] ?> 0 solid;} /*market tab on*/
a:link.aom_mlo {text-decoration:none; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*market link on*/
a:hover.aom_mlo {text-decoration:none; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*market link on*/
a:active.aom_mlo {text-decoration:none; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*market link on*/
a:visited.aom_mlo {text-decoration:none; color:<?php echo $this->css['AccentColorInverse'] ?>;} /*market link on*/
.aom_mtf {font-weight:bold; padding:3px; border-right:#000000 1px solid; border-top:#000000 1px solid; background:<?php echo $this->css['AccentColor'] ?>; border-left:#000000 1px solid; border-bottom:<?php echo $this->css['MainColor'] ?> 0 solid;} /*market tab off*/
a:link.aom_mlf {text-decoration:none; color:<?php echo $this->css['MainColorInverse'] ?>;} /*market link off*/
a:hover.aom_mlf {text-decoration:none; color:<?php echo $this->css['MainColorInverse'] ?>;} /*market link off*/
a:active.aom_mlf {text-decoration:none; color:<?php echo $this->css['MainColorInverse'] ?>;} /*market link off*/
a:visited.aom_mlf {text-decoration:none; color:<?php echo $this->css['MainColorInverse'] ?>;} /*market link off*/
.aom_mb {background-color:<?php echo $this->css['MainColor'] ?>;} /*market bar*/
.aom_ma {background-color:#EAEAEA;} /*amazon offer in marketplace*/
.aom_mpt {font-size:10; font-weight:normal;} /* tab offer price text */

.aom_box_side {padding:0;}
.aom_box_side ul {list-style-type:none; font-size:smaller; font-weight:bold; margin:0; padding:0;}
.aom_box_side li.l1 {font-size:smaller; margin:0 0 0 1em; padding:2px 0 2px 2px; text-indent:-.9em; vertical-align:text-top; clear:both;}
.aom_box_side li.l2 {margin:0; padding:4px 4px 4px 0; border-bottom:1px solid #eaeaea; clear:both; display:table;}
.aom_box_side img {padding:0; margin:0; float:left;}
.aom_box_L {margin:<?php echo ($this->css['BoxSpacingVertical']>0 ? $this->css['BoxSpacingVertical']."px" :"0" ) ?> 0 0 0;}
.aom_box_R {margin:<?php echo ($this->css['BoxSpacingVertical']>0 ? $this->css['BoxSpacingVertical']."px" :"0" ) ?> 0 0 0;}
.aom_subtitle {font-weight:bold; list-style-type:none; padding:0;}
.aom_list {font-size:larger; margin:0; padding:0;}
.aom_box_vertical {width:100%; margin:0; padding:0; margin:<?php echo ($this->css['BoxSpacingVertical']>0 ? $this->css['BoxSpacingVertical']."px" :"0" ) ?> 0;}
.aom_sub {list-style-type:none; font-size:smaller; font-weight:bold; margin:0; padding:0; float:left;}
.aom_sub li.l1 {font-size:smaller; margin:0 0 0 1em; padding:2px 0 2px 2px; text-indent:-.9em; vertical-align:text-top; clear:both;}
.aom_spacer {margin-left:10px;}

.aom_bl {font-weight:bold;} /*box label*/
.aom_bt {font-size:smaller;	font-weight:bold;} /*box text*/
.aom_bb {font-weight:bold; margin-right:4px;} /*box bullets*/

.aom_mbox {font-size:smaller; font-weight:bold; margin:5px 5px 5px 0; padding:5px; border:1px solid #CCCCCC; width:200px;}
.aom_mr1 {background-color:#FFFFFF;}  /* merchant 1 item pages */
.aom_mr2 {background-color:#CEDEF4;}  /* merchant 2 item pages */
.aom_mr3 {background-color:#FFFFCC;}  /* merchant 3 item pages */
.aom_mr4 {background-color:#FFCC99;}  /* merchant 4 item pages */
.aom_mr5 {background-color:#CCCCFF;}  /* merchant 5 item pages */
.aom_mr6 {background-color:#FF9999;}  /* merchant 6 item pages */
.aom_mr7 {background-color:#99CCCC;}  /* merchant 7 item pages */
.aom_mr8 {background-color:#FFCC66;}  /* merchant 8 item pages */
.aom_mr9 {background-color:#99CC99;}  /* merchant 9 item pages */
.aom_mr10 {background-color:#CCFF66;}  /* merchant 10 item pages */
.aom_mr11 {background-color:#9999CC;}  /* merchant 11 item pages */
.aom_mr12 {background-color:#66CCFF;}  /* merchant 12 item pages */
.aom_mr13 {background-color:#FF9933;}  /* merchant 13 item pages */
.aom_mr14 {background-color:#CC9900;}  /* merchant 14 item pages */
.aom_mr15 {background-color:#FF6699;}  /* merchant 15 item pages */

/*price info box*/
/*
.aom_prb {padding:2px; background-image:url('../tag.jpg'); background-repeat:no-repeat; width:30em;} 
*/

<?php
// TABS:ROUNDED
if ($this->css['DisplayTabs']=="Yes" AND $this->css['TabStyle']=="style_01") {
?>
.tabBorder {border-style:solid; border-color:<?php echo $this->css['MainColor'] ?>; border-top-width:1px; border-bottom-width:0; border-left-width:1px; border-right-width:1px;}
.aom_t1 DT {display:none;}
.aom_t1 DD {margin:0 <?php echo $this->css['TabSpacing'] ?>px 0 0; float:left;}
.aom_t1 .aa {background:<?php echo $this->css['AccentColor'] ?>; float:left; width:5px;}
.aom_t1 .bb {white-space:nowrap; padding:2px 1px 2px 1px; border-top:<?php echo $this->css['TabBorderColor'] ?> 1px solid; background:<?php echo $this->css['AccentColor'] ?>; color:<?php echo $this->css['AccentColorInverse'] ?>; float:left; text-align:center;}
.aom_t1 .sela {background:<?php echo $this->css['MainColor'] ?>; float:left; width:5px;}
.aom_t1 .selb {white-space:nowrap; padding:2px 1px 2px 1px; border-top:<?php echo $this->css['TabBorderColor'] ?> 1px solid; background:<?php echo $this->css['MainColor'] ?>; color:<?php echo $this->css['MainColorInverse'] ?>; float:left; text-align:center;}
.aom_t1 .va {border-top:<?php echo $this->css['BgColor'] ?> 5px solid; background:<?php echo $this->css['TabBorderColor'] ?>; float:left; width:1px;}
.aom_t1 .va {height:auto;}
html>body .aom_t1 .va {height:16px;}
.aom_t1 .vb {border-top:<?php echo $this->css['BgColor'] ?> 3px solid; background:<?php echo $this->css['TabBorderColor'] ?>; float:left; width:1px; height:3px;}
.aom_t1 .vc {border-top:<?php echo $this->css['BgColor'] ?> 2px solid; background:<?php echo $this->css['TabBorderColor'] ?>; float:left; width:1px; height:2px;}
.aom_t1 .vd {border-top:<?php echo $this->css['BgColor'] ?> 1px solid; background:<?php echo $this->css['TabBorderColor'] ?>; float:left; width:2px; height:1px;}
.aom_t1 A {cursor:pointer; color:<?php echo $this->css['TextColor'] ?>; text-decoration:none;}
.aom_t1 A:visited {cursor:pointer; color:<?php echo $this->css['TextColor'] ?>; text-decoration:none;}
.aom_t1 A:hover {background:<?php echo $this->css['MainColor'] ?>; color:<?php echo $this->css['TextColor'] ?>;}
.aom_t1 A:hover .aa {background:<?php echo $this->css['MainColor'] ?>;}
.aom_t1 A:hover .bb {background:<?php echo $this->css['MainColor'] ?>;  color:<?php echo $this->css['MainColorInverse'] ?>;}

<?php
}
// TABS:SQUARE
else if ($this->css['DisplayTabs']=="Yes" AND $this->css['TabStyle']=="style_02") {
?>
.aom_t2 {white-space:nowrap; position:relative; float:Left; width:100%; padding:0 0 0 1em; margin:0; list-style:none; line-height:1em;}
.aom_t2 LI {float:Left; margin:0; padding:0;}
.aom_t2 A {display:block; color:<?php echo $this->css['AccentColorInverse'] ?>; text-decoration:none; font-weight:normal; background:<?php echo $this->css['AccentColor'] ?>; margin:0 <?php echo $this->css['TabSpacing'] ?>px 0 0; padding:0.35em .40em; border-left:1px solid <?php echo $this->css['TabBorderColor'] ?>; border-top:1px solid <?php echo $this->css['TabBorderColor'] ?>; border-right:1px solid <?php echo $this->css['TabBorderColor'] ?>; padding-bottom:4px;}
.aom_t2 A.here:link, .aom_t2 A:hover, .aom_t2 A:active, .aom_t2 A.here:visited {background:<?php echo $this->css['MainColor'] ?>; color:<?php echo $this->css['MainColorInverse'] ?>;}
.aom_t2 A:visited {color:<?php echo $this->css['AccentColorInverse'] ?>;}
.aom_t2 A:hover, .aom_t2 A:active {color:<?php echo $this->css['MainColorInverse'] ?>;}
<?php
}
// TABS:CUSTOM
else if ($this->css['DisplayTabs']=="Yes" AND $this->css['TabStyle']=="style_00") {
/*
For dozens of additional tab styles see the CSS Tab Designer by OverZone Software
http://www.highdots.com/css-tab-designer/

The CSS IDs built into AOM for custom tabs are...
aom_navcontainer  (used in the DIV tag)
aom_navlist  (used in the UL tag)
aom_navactive  (used in the selected A link)

Enter your custom tab CSS **BELOW THIS LINE***/ ?>



<?php // Enter your custom tab CSS **ABOVE THIS LINE**
}
?>

/*
UNIQUE TAB COLORS
Each tab is automatically assigned a class ID which is in the format aom_tab_[YourCategoryID] (e.g. aom_tab_ebooks).
To customize a tab you would use your Category ID in place of the example ebooks ID used in the example below.
Then change the color (e.g. #FFFFFF) and background-color (e.g. #5A7BAD) to the colors you would like to use.
*/
?>
/* rounded tab style */
/*
.aom_t1 .aom_tab_ebooks_on {color:#FFFFFF; background-color:#5A7BAD;}
.aom_t1 A:hover .aom_tab_ebooks {color:#FFFFFF; background-color:#5A7BAD;}
.aom_sb_ebooks {background-color:#5A7BAD;}
A.aom_sbt_ebooks:link {color:#FFFFFF;}
*/

/* square tab style */
/*
.aom_t2 A.aom_tab_ebooks_on:link, .aom_t2 A.aom_tab_ebooks_on:visited {color:#FFFFFF; background-color:#5A7BAD;}
A.aom_tab_ebooks:hover, A.aom_tab_ebooks:active {color:#FFFFFF; background-color:#5A7BAD;}
.aom_sb_ebooks {background-color:#5A7BAD;}
A.aom_sbt_ebooks:link {color:#FFFFFF;}
*/

/* rss custom pages */
.aom_rss_cp_container {float:left;}
.aom_rss_cp_title {display:block;}
.aom_rss_cp_item_container {margin-top:5px; background-color:#FFFFFF; padding:15px; float:left;}
.aom_rss_cp_item_title {font-weight:bold;}
.aom_rss_cp_item_pubDate {font-size:10; color:#999999; margin-left:10px;}
.aom_rss_cp_item_copyright {font-size:10; color:#000000; float:left;}
.aom_rss_cp_item_description {}
.aom_rss_cp_item_link {}

/* rss custom boxes */
.aom_rss_cb_container {}
.aom_rss_cb_item_container {margin-top:10;}
.aom_rss_cb_item_title {font-weight:bold; line-break:strict;}
.aom_rss_cb_item_pubDate {font-size:9px; color:#999999;}
.aom_rss_cb_item_copyright {font-size:9px; color:#000000;}
.aom_rss_cb_item_link {}

/* previous/next/page numbers */
.aom_pg {margin:1em 0 0 0; clear:left; font-size:85%;}
.aom_pg a, .aom_pg span {float:left; padding:0.2em 0.4em; margin-right:0.1em; border:1px solid #fff; background:#fff;}
.aom_pg span.aom_current {border:1px solid <?php echo $this->css['MainColor'] ?>; font-weight:bold; background:<?php echo $this->css['MainColor'] ?>; color:<?php echo $this->css['MainColorInverse'] ?>;}
.aom_pg a {border:1px solid #999999; text-decoration:none;}
.aom_pg a:hover {background-color:#EAEAEA; color:#000000; text-decoration:underline;}
.aom_pg a.aom_np {font-weight:bold;}
.aom_pg span.aom_np {border:1px solid #ddd; color:#999;}
.aom_pg .aom_np-next {float:right;}
.aom_pg span.aom_sp {padding:0.5em 0 0 0; border:0; background:<?php echo $this->css['BodyBgColor'] ?>}

/* autocomplete hooks */
.ac_results {padding:0; border:1px solid black;	background-color:white;	overflow:hidden; z-index:99999;}
.ac_results ul {width:100%; list-style-position:outside; list-style:none; padding:0; margin:0;}
.ac_results li {margin:0; padding:2px 5px; cursor:default; display:block; font:menu; font-size:12px; line-height:16px; overflow:hidden;}
.ac_loading {background:white url('<?php echo $this->css['tpath'] ?>/images/indicator.gif') right center no-repeat;}
.ac_odd {background-color:#eee;}
.ac_over {background-color:#0A246A; color:white;}

/* amazon specific */
.tiny {font-family:verdana,arial,helvetica,sans-serif; font-size:x-small; }

/* to use the regular appearance for page numbering, comment out the section above and uncommment the section below */
/*
.aom_pg {margin:1em 0 0 0; clear:left; font-size:12px;}
.aom_pg a, .aom_pg span {float:left; padding:0.1em 0.2em; margin-right:0.1em;}
.aom_pg span.aom_current {font-weight:bold;}
.aom_pg a {text-decoration:underline;}
.aom_pg a:hover {color:#000000; text-decoration:underline;}
.aom_pg a.aom_np {font-weight:bold;}
.aom_pg span.aom_np {color:#999;}
.aom_pg .aom_np-next {float:right;}
.aom_pg span.aom_sp {padding:0.2em 0 0 0;}
*/

