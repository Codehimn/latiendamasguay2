<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: wordpress.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php //print_r($this->t) ?>

<a href="<?php echo $this->t['link'] ?>"><?php echo $this->t['title'] ?></a>
<?php echo $this->t['description'] ?>