<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: footer.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<div style="clear:both;"></div>
<script type="text/javascript">
var pmsg = '<?php echo $this->aom->t['DisclaimerPrice']; ?>'
</script>

<?php
if (!empty($this->aom->site['SiteTrafficCode'])) {
	echo $this->aom->site['SiteTrafficCode'];
}

// custom footer
if (!empty($this->aom->site['SiteFooter'])) {
	$page = $this->aom->page;
	include($this->aom->site['SiteFooter']);
}
// aom footer
else {
?>
<div id="aom_footer">
<?php $this->aom->displayContentVertical("PB2"); ?>
</div>
</body>
</html>
<?php
}
?>
