<?php
// ASSOCIATE-O-MATIC THEME

// INFORMATION
$theme['Name'] 			= "AOM Default";
$theme['Version'] 		= "1.0";
$theme['Author'] 		= "Associate-O-Matic";
$theme['Url'] 			= "http://www.associate-o-matic.com/themes";
$theme['AomFirst'] 		= "5.x"; // earliest compatible AOM version
$theme['AomLast'] 		= "5.x"; // latest compatible AOM version

?>