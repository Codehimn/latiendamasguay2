<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: sitemap.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php //$this->aom->dump($this->aom->t['Sitemap']) ?>
<?php $sitemap = $this->aom->t['Sitemap'] ?>

<div id="aom_page">
	<h1><?php echo $sitemap['Title'] ?></h1>
	
	<?php if (isset($sitemap['Categories'])): ?>
		<div><?php echo $this->aom->str['381'] ?></div>
		<ul>
		<?php foreach ($sitemap['Categories'] AS $category): ?>
			<li><a href="<?php echo $category['Url'] ?>"><?php echo $category['Name'] ?></a></li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	
	<?php if (isset($sitemap['CustomPages'])): ?>
		<div><?php echo $this->aom->str['99'] ?></div>	
		<ul>
		<?php foreach ($sitemap['CustomPages'] AS $custompage): ?>
			<li><a href="<?php echo $custompage['Url'] ?>"><?php echo $custompage['Name'] ?></a></li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
		
</div>