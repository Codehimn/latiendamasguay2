<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: tabs.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php //$this->aom->dump($this->aom->t['Tabs']) ?>

<?php // TABS: ROUNDED ?>
<?php if ($this->aom->site['TabStyle']=="style_01"): ?>
<div id="aom_tabs" class="aom_t1">
	<dl><?php foreach ($this->aom->t['Tabs'] as $tab): ?>
	<?php if ($tab['Active']=="Y"): ?><dd><a href="<?php echo $tab['Url'] ?>"><span class="sela aom_tab_<?php echo $tab['Id'] ?>_on"><span class="va"></span><span class="vb"></span><span class="vc"></span><span class="vd"></span></span><span class="selb aom_tab_<?php echo $tab['Id'] ?>_on"><?php echo $tab['Name'] ?></span><span class="sela aom_tab_<?php echo $tab['Id'] ?>_on"><span class="vd"></span><span class="vc"></span><span class="vb"></span><span class="va"></span></span></a></dd>
	<?php else: ?><dd><a href="<?php echo $tab['Url'] ?>"><span class="aa aom_tab_<?php echo $tab['Id'] ?>"><span class="va"></span><span class="vb"></span><span class="vc"></span><span class="vd"></span></span><span class="bb aom_tab_<?php echo $tab['Id'] ?>"><?php echo $tab['Name'] ?></span><span class="aa aom_tab_<?php echo $tab['Id'] ?>"><span class="vd"></span><span class="vc"></span><span class="vb"></span><span class="va"></span></span></a></dd>
	<?php endif; ?><?php endforeach; ?>
	</dl>
</div>

<?php // TABS: SQUARE ?>
<?php elseif ($this->aom->site['TabStyle']=="style_02"): ?>
<div id="aom_tabs">
	<ul class="aom_t2">
	<?php foreach ($this->aom->t['Tabs'] as $tab): ?>
		<?php if ($tab['Active']=="Y"): ?>
			<li><a class="here aom_tab_<?php echo $tab['Id'] ?>_on" href="<?php echo $tab['Url'] ?>"><?php echo $tab['Name'] ?></a></li>
		<?php else: ?>
			<li><a class="aom_tab_<?php echo $tab['Id'] ?>" href="<?php echo $tab['Url'] ?>"><?php echo $tab['Name'] ?></a></li>
		<?php endif; ?>
	<?php endforeach; ?>
	</ul>
</div>

<?php // TABS: CUSTOM ?>
<?php elseif ($this->aom->site['TabStyle']=="style_00"): ?>
<div id="aom_navcontainer">
	<ul id="aom_navlist">
	<?php foreach ($this->aom->t['Tabs'] as $tab): ?>
		<?php if ($tab['Active']=="Y"): ?>
			<li id="aom_navactive"><a href="<?php echo $tab['Url'] ?>"><span><?php echo $tab['Name'] ?></span></a></li>
		<?php else: ?>
			<li><a href="<?php echo $tab['Url'] ?>"><span><?php echo $tab['Name'] ?></span></a></li>
		<?php endif; ?>
	<?php endforeach; ?>
	</ul>
</div>
<?php endif; ?>
