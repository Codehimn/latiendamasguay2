<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: header.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php if (empty($this->aom->site['SiteDocType'])): ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//<?php echo $this->aom->t['Lang'] ?>" "http://www.w3.org/TR/html4/loose.dtd">
<?php else: ?>
<?php echo $this->aom->site['SiteDocType'] ?>
<?php endif; ?>
<?php if (!empty($this->aom->site['SiteHeader'])): ?>
<?php $page = $this->aom->page ?>
<?php include($this->aom->site['SiteHeader']) ?>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/shop.js"></script>
<?php if ($this->aom->site['SearchAutocomplete']=="Yes"): ?>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/jquery.autocomplete.js"></script>
<?php endif; ?>
<?php if (strstr($this->aom->site['ImageZoom'], "lightbox")): ?>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/lightbox/jquery.colorbox.js"></script>
<link type="text/css" media="screen" rel="stylesheet" href="<?php echo $this->aom->path_js; ?>/lightbox/<?php echo $this->aom->site['ImageZoom']; ?>/colorbox.css">
<?php endif; ?>
<?php if ($this->aom->site['CssOverride']=="No"): ?>
<link rel="stylesheet" type="text/css" href="<?php echo $this->aom->tpath."/css/".$this->aom->cfg_file_css; ?>">
<?php endif; ?>
<?php if (!empty($this->aom->site['SiteCss'])): ?>
<link rel="stylesheet" type="text/css" href="<?php echo $this->aom->site['SiteCss']; ?>">
<?php endif; ?>
<?php if (isset($this->aom->t['Rss']['Url'])): ?>
<link rel="alternate" type="application/rss+xml" href="<?php echo $this->aom->t['Rss']['Url'] ?>" title="RSS">
<?php endif; ?>
<?php if (isset($this->aom->t['CanonicalLink'])): ?>
<link rel="canonical" href="<?php echo $this->aom->t['CanonicalLink'] ?>">
<?php endif; ?>
<?php else: ?>
<html>
<head>
<title><?php echo $this->aom->page['Title'] ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="description" content="<?php echo $this->aom->page['MetaDescription'] ?>">
<meta name="keywords" content="<?php echo $this->aom->page['MetaKeywords'] ?>">
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/shop.js"></script>
<?php if ($this->aom->site['SearchAutocomplete']=="Yes"): ?>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/jquery.autocomplete.js"></script>
<?php endif; ?>
<?php if (strstr($this->aom->site['ImageZoom'], "lightbox")): ?>
<script type="text/javascript" src="<?php echo $this->aom->path_js; ?>/lightbox/jquery.colorbox.js"></script>
<link type="text/css" media="screen" rel="stylesheet" href="<?php echo $this->aom->path_js; ?>/lightbox/<?php echo $this->aom->site['ImageZoom']; ?>/colorbox.css">
<?php endif; ?>
<?php if (!empty($this->aom->site['SiteHead'])): ?>
<?php echo $this->aom->site['SiteHead'] ?>
<?php endif; ?>
<?php if ($this->aom->site['CssOverride']=="No"): ?>
<link rel="stylesheet" type="text/css" href="<?php echo $this->aom->tpath."/css/".$this->aom->cfg_file_css; ?>">
<?php endif; ?>
<?php if (!empty($this->aom->site['SiteCss'])): ?>
<link rel="stylesheet" type="text/css" href="<?php echo $this->aom->site['SiteCss']; ?>">
<?php endif; ?>
<?php if (isset($this->aom->t['Rss']['Url'])): ?>
<link rel="alternate" type="application/rss+xml" href="<?php echo $this->aom->t['Rss']['Url'] ?>" title="RSS">
<?php endif; ?>
<?php if (isset($this->aom->t['CanonicalLink'])): ?>
<link rel="canonical" href="<?php echo $this->aom->t['CanonicalLink'] ?>">
<?php endif; ?>
</head>
<body>
<?php endif; ?>
<div id="aom_header">
<?php $this->aom->displayContentVertical("PT"); ?>
<?php $this->aom->loadTemplate("logo.tpl.php") ?>
<?php /* Tabs */ ?>
<?php if ($this->aom->site['DisplayTabs']=="Yes"): ?>
	<?php $this->aom->loadTemplate("tabs.tpl.php") ?>
<?php endif; ?>
<?php /* Search */ ?>
<?php if ($this->aom->site['DisplaySearchBar']=="Yes"): ?>
	<?php $this->aom->loadTemplate("search.tpl.php") ?>
<?php endif; ?>
<?php /* Breadcrumbs */ ?>
<?php if (!empty($this->aom->page['Breadcrumbs'])): ?>
	<?php $this->aom->loadTemplate("breadcrumbs.tpl.php") ?>
<?php endif; ?>
</div>
<div style="clear:both;"></div>