<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: box_narrowbybrand.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php //$this->aom->dump($this->aom->site['Brands']) ?>

<ul>
<?php foreach($this->aom->site['Brands'] AS $brand): ?>
	<li class="l1"><span class="aom_bb"><?php echo $this->aom->site['Bullet'] ?></span><span class="aom_list"><a href="<?php echo $brand['Url'] ?>"<?php echo $this->aom->nofollow['N1'] ?>><?php echo $brand['Name'] ?></a></span></li>
<?php endforeach; ?>
</ul>
<div style="clear:both;"></div>