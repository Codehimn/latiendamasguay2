<?php
/********************************************************************
Associate-O-Matic Theme: default
Associate-O-Matic Template: button_aom_collections.tpl.php

IMPORTANT NOTE
It is recommended that instead of editing the default template files,
you install a copy of the default template and edit those files instead.

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/
?>
<?php //$this->aom->dump($this->aom->t['Button']) ?>
<?php $button = $this->aom->t['Button'] ?>

<?php if (isset($button['InStock'])): ?>
	<span class="aom_sto"><?php echo $this->aom->str['309'] ?></span><br>
<?php endif; ?>
<a href="<?php echo $button['Url'] ?>" rel="nofollow">
<img src="<?php echo $button['Image'] ?>" border="0" alt="<?php echo $this->aom->str['352'] ?>">
</a>