<?php
/********************************************************************
Associate-O-Matic v5.2.0
http://www.associate-o-matic.com

Justin Mecham
info@associate-o-matic.com

DESCRIPTION
Image masking script

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/

$version = "5.2.0";

if (!empty($_GET['i'])) {
	$i = htmlentities($_GET['i'], ENT_QUOTES, 'UTF-8');
	$img = "http://ecx.images-amazon.com/images/I/".$i;
	echo file_get_contents($img);
}
else if (!empty($_GET['t'])) {
	$t = htmlentities($_GET['t'], ENT_QUOTES, 'UTF-8');
	$img = "http://images.amazon.com/images/P/".$t;
	echo file_get_contents($img);
}

?>