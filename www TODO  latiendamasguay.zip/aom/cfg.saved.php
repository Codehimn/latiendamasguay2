<?xml version="1.0" encoding="UTF-8"?>
<Associate-O-Matic Version="5.2.0">
  <AccentColor><![CDATA[#77C1DD]]></AccentColor>
  <AdvancedSearch><![CDATA[Yes]]></AdvancedSearch>
  <Alignment><![CDATA[Center]]></Alignment>
  <AmazonAccessKeyId><![CDATA[AKIAJCNFCQN7SZWJWLHA]]></AmazonAccessKeyId>
  <AmazonAssociateId><![CDATA[latimagu-21]]></AmazonAssociateId>
  <AmazonConnectionMethod><![CDATA[aom]]></AmazonConnectionMethod>
  <AmazonSecretAccessKey />
  <AmazonStoreType><![CDATA[Amazon.es]]></AmazonStoreType>
  <AmazonTimeOffset><![CDATA[0]]></AmazonTimeOffset>
  <AspectRatio><![CDATA[On]]></AspectRatio>
  <BestsellerBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Bestsellers]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Count><![CDATA[10]]></Count>
    <Photos><![CDATA[Yes]]></Photos>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </BestsellerBox>
  <BestsellerImage />
  <BgColor><![CDATA[#EAEAEA]]></BgColor>
  <BgImage />
  <BodyBgColor><![CDATA[#FFFFFF]]></BodyBgColor>
  <BodyBorderColor><![CDATA[#EAEAEA]]></BodyBorderColor>
  <BodyBorderSize><![CDATA[0]]></BodyBorderSize>
  <BodyPadding><![CDATA[8]]></BodyPadding>
  <BodySpacingHorizontal><![CDATA[10]]></BodySpacingHorizontal>
  <BodySpacingVertical><![CDATA[10]]></BodySpacingVertical>
  <BoxSpacingHorizontal><![CDATA[10]]></BoxSpacingHorizontal>
  <BoxSpacingVertical><![CDATA[10]]></BoxSpacingVertical>
  <BreadcrumbSeparator><![CDATA[ra]]></BreadcrumbSeparator>
  <Bullet><![CDATA[&#8226;]]></Bullet>
  <BuyButtonLocations>
    <Option><![CDATA[C1]]></Option>
    <Option><![CDATA[I1]]></Option>
  </BuyButtonLocations>
  <BuyButtonNewWindow><![CDATA[_blank]]></BuyButtonNewWindow>
  <BuyButtonQuantity><![CDATA[No]]></BuyButtonQuantity>
  <BuyButtonQuantityRange>
    <MinQty />
    <MaxQty />
  </BuyButtonQuantityRange>
  <BuyButtonType><![CDATA[product]]></BuyButtonType>
  <BuyButtonViewCart><![CDATA[Yes]]></BuyButtonViewCart>
  <CacheCleanup><![CDATA[20]]></CacheCleanup>
  <CacheFooter><![CDATA[Yes]]></CacheFooter>
  <CacheHeader><![CDATA[Yes]]></CacheHeader>
  <CacheLifetime><![CDATA[24]]></CacheLifetime>
  <CacheRss><![CDATA[Yes]]></CacheRss>
  <CanonicalLinks><![CDATA[Yes]]></CanonicalLinks>
  <CartAddTrackingCode />
  <CartBgColorEven><![CDATA[#F5F5F5]]></CartBgColorEven>
  <CartBgColorOdd><![CDATA[#FFFFFF]]></CartBgColorOdd>
  <CartCheckoutTrackingCode />
  <Categories>
    <Category>
      <Id><![CDATA[9739]]></Id>
      <Mode><![CDATA[Toys]]></Mode>
      <Name><![CDATA[Juguetes]]></Name>
      <Node><![CDATA[599386031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[8847]]></Id>
      <Mode><![CDATA[VideoGames]]></Mode>
      <Name><![CDATA[Juegos video]]></Name>
      <Node><![CDATA[599383031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[9849]]></Id>
      <Mode><![CDATA[Watches]]></Mode>
      <Name><![CDATA[Relojes]]></Name>
      <Node><![CDATA[599389031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[6246]]></Id>
      <Mode><![CDATA[Electronics]]></Mode>
      <Name><![CDATA[Electrónica]]></Name>
      <Node><![CDATA[667050031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[1061]]></Id>
      <Mode><![CDATA[Software]]></Mode>
      <Name><![CDATA[Software]]></Name>
      <Node><![CDATA[599377031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[3761]]></Id>
      <Mode><![CDATA[Music]]></Mode>
      <Name><![CDATA[Música]]></Name>
      <Node><![CDATA[599374031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[5334]]></Id>
      <Mode><![CDATA[Kitchen]]></Mode>
      <Name><![CDATA[Cocina]]></Name>
      <Node><![CDATA[599392031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
    <Category>
      <Id><![CDATA[2252]]></Id>
      <Mode><![CDATA[Books]]></Mode>
      <Name><![CDATA[Libros]]></Name>
      <Node><![CDATA[599365031]]></Node>
      <SDK><![CDATA[Off]]></SDK>
      <Keyword><![CDATA[%20]]></Keyword>
      <Con><![CDATA[A]]></Con>
      <Tab><![CDATA[On]]></Tab>
      <Menu><![CDATA[On]]></Menu>
      <Box><![CDATA[On]]></Box>
      <Sub><![CDATA[On]]></Sub>
      <Sort><![CDATA[salesrank]]></Sort>
    </Category>
  </Categories>
  <CategoryBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Categories]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <Order />
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[I]]></Option>
      <Option><![CDATA[C]]></Option>
      <Option><![CDATA[CP]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
  </CategoryBox>
  <CategoryColumns><![CDATA[2]]></CategoryColumns>
  <CategoryIcons><![CDATA[No]]></CategoryIcons>
  <CategoryItemRandomizer><![CDATA[Off]]></CategoryItemRandomizer>
  <CheckoutNewWindow><![CDATA[_self]]></CheckoutNewWindow>
  <ColorScheme><![CDATA[aom_classic]]></ColorScheme>
  <ColumnWidthLeft><![CDATA[160]]></ColumnWidthLeft>
  <ColumnWidthRight><![CDATA[160]]></ColumnWidthRight>
  <Corners><![CDATA[r]]></Corners>
  <CssOverride><![CDATA[No]]></CssOverride>
  <CurrencyRate />
  <CurrencyRateFile />
  <CurrencySymbolPrefix />
  <CurrencySymbolSuffix />
  <CustomBoxes />
  <CustomPages />
  <Debugger><![CDATA[Off]]></Debugger>
  <DisplayAccessories><![CDATA[Yes]]></DisplayAccessories>
  <DisplayAlternateVersions><![CDATA[Yes]]></DisplayAlternateVersions>
  <DisplayAmazonRefs><![CDATA[No]]></DisplayAmazonRefs>
  <DisplayAsins>
    <Option><![CDATA[I]]></Option>
  </DisplayAsins>
  <DisplayAvailability>
    <Option><![CDATA[I]]></Option>
  </DisplayAvailability>
  <DisplayBabyRegistryLink><![CDATA[No]]></DisplayBabyRegistryLink>
  <DisplayBreadcrumbs>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplayBreadcrumbs>
  <DisplayCartBestsellers><![CDATA[No]]></DisplayCartBestsellers>
  <DisplayCartNewReleases><![CDATA[No]]></DisplayCartNewReleases>
  <DisplayCartSimilarItems><![CDATA[Yes]]></DisplayCartSimilarItems>
  <DisplayCartSimilarViewedItems><![CDATA[No]]></DisplayCartSimilarViewedItems>
  <DisplayCategory>
    <Option><![CDATA[I]]></Option>
  </DisplayCategory>
  <DisplayCategoryColumn><![CDATA[Yes]]></DisplayCategoryColumn>
  <DisplayCheckoutLink><![CDATA[Yes]]></DisplayCheckoutLink>
  <DisplayCollections><![CDATA[Yes]]></DisplayCollections>
  <DisplayConditionNote>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplayConditionNote>
  <DisplayCrossSellLinks><![CDATA[Yes]]></DisplayCrossSellLinks>
  <DisplayCustomerReviews><![CDATA[No]]></DisplayCustomerReviews>
  <DisplayDate>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplayDate>
  <DisplayEditorialReviews><![CDATA[No]]></DisplayEditorialReviews>
  <DisplayFeatures><![CDATA[Yes]]></DisplayFeatures>
  <DisplayHomeTab><![CDATA[Yes]]></DisplayHomeTab>
  <DisplayImageColumn><![CDATA[Yes]]></DisplayImageColumn>
  <DisplayInStock><![CDATA[Yes]]></DisplayInStock>
  <DisplayListPrice>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplayListPrice>
  <DisplayMarketplaceLinks><![CDATA[Yes]]></DisplayMarketplaceLinks>
  <DisplayPromotions><![CDATA[Yes]]></DisplayPromotions>
  <DisplayQuantityInStock><![CDATA[No]]></DisplayQuantityInStock>
  <DisplaySalePrice>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplaySalePrice>
  <DisplaySalesRank>
    <Option><![CDATA[I]]></Option>
  </DisplaySalesRank>
  <DisplaySavingsPrice>
    <Option><![CDATA[H]]></Option>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[I]]></Option>
  </DisplaySavingsPrice>
  <DisplaySearchAllOption><![CDATA[Yes]]></DisplaySearchAllOption>
  <DisplaySearchBar><![CDATA[Yes]]></DisplaySearchBar>
  <DisplaySellerColumn><![CDATA[No]]></DisplaySellerColumn>
  <DisplayShipping>
    <Option><![CDATA[I]]></Option>
  </DisplayShipping>
  <DisplaySimilarItems><![CDATA[Yes]]></DisplaySimilarItems>
  <DisplaySitemapLink><![CDATA[Yes]]></DisplaySitemapLink>
  <DisplaySoldBy><![CDATA[Yes]]></DisplaySoldBy>
  <DisplaySortBy><![CDATA[Yes]]></DisplaySortBy>
  <DisplayTabs><![CDATA[Yes]]></DisplayTabs>
  <DisplayTellAFriendLink><![CDATA[No]]></DisplayTellAFriendLink>
  <DisplayViewAllItemsLink><![CDATA[Yes]]></DisplayViewAllItemsLink>
  <DisplayViewCartLink><![CDATA[Yes]]></DisplayViewCartLink>
  <DisplayWeddingRegistryLink><![CDATA[No]]></DisplayWeddingRegistryLink>
  <DisplayWishlistLink><![CDATA[Yes]]></DisplayWishlistLink>
  <ErrorApiLimit />
  <ErrorApiLimitFile />
  <ErrorCart />
  <ErrorHttp404 />
  <ErrorItemNotAvailable />
  <ErrorNoData />
  <ErrorSearch />
  <Filter />
  <GoogleTrackingId />
  <HomeAsins />
  <HomeAsinsPerPage><![CDATA[10]]></HomeAsinsPerPage>
  <HomeAsinsRandomizer><![CDATA[Off]]></HomeAsinsRandomizer>
  <HomeBlendedCount><![CDATA[3]]></HomeBlendedCount>
  <HomeFile><![CDATA[/home/latienda/public_html/shop/iframe.php]]></HomeFile>
  <HomeHtml />
  <HomeItem />
  <HomeNode>
    <Mode><![CDATA[Toys]]></Mode>
    <Node><![CDATA[599386031]]></Node>
    <Keyword />
  </HomeNode>
  <HomePageFormat><![CDATA[file]]></HomePageFormat>
  <HomeWelcomeFile />
  <HomeWelcomeHtml />
  <ImageCloak><![CDATA[On]]></ImageCloak>
  <ImageFilter><![CDATA[Yes]]></ImageFilter>
  <ImageOverride><![CDATA[Off]]></ImageOverride>
  <ImageSizeCategory><![CDATA[Medium]]></ImageSizeCategory>
  <ImageSizeHome><![CDATA[Small]]></ImageSizeHome>
  <ImageSizeItem><![CDATA[Medium]]></ImageSizeItem>
  <ImageSizeRss><![CDATA[Small]]></ImageSizeRss>
  <ImageZoom><![CDATA[lightbox2]]></ImageZoom>
  <InformationBox>
    <Display><![CDATA[No]]></Display>
    <Label><![CDATA[Information]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[R]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[I]]></Option>
      <Option><![CDATA[C]]></Option>
      <Option><![CDATA[CP]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </InformationBox>
  <IpFilter />
  <ItemFilter />
  <ItemPages><![CDATA[10]]></ItemPages>
  <LineColor><![CDATA[#EAEAEA]]></LineColor>
  <LineSize><![CDATA[2]]></LineSize>
  <LineType><![CDATA[dashed]]></LineType>
  <LinkColor><![CDATA[#0000CC]]></LinkColor>
  <LinkHoverColor><![CDATA[#6666FF]]></LinkHoverColor>
  <LinkVisitedColor><![CDATA[#551A8B]]></LinkVisitedColor>
  <Logo />
  <LogoAlignment><![CDATA[Left]]></LogoAlignment>
  <MainColor><![CDATA[#0289C1]]></MainColor>
  <MarketplaceItems>
    <Option><![CDATA[New]]></Option>
    <Option><![CDATA[Used]]></Option>
    <Option><![CDATA[Refurbished]]></Option>
    <Option><![CDATA[Collectible]]></Option>
  </MarketplaceItems>
  <MaximumPrice />
  <Merchant><![CDATA[All]]></Merchant>
  <MerchantCount><![CDATA[5]]></MerchantCount>
  <MerchantFilter />
  <MerchantItems><![CDATA[All]]></MerchantItems>
  <MerchantPreference><![CDATA[lowest_new]]></MerchantPreference>
  <MetaDescriptionCategory><![CDATA[{CATEGORY_NAME} - {CATEGORY_DESCRIPTION} - {SITE_DESCRIPTION}{PAGE}]]></MetaDescriptionCategory>
  <MetaDescriptionHome><![CDATA[{SITE_DESCRIPTION}{PAGE}]]></MetaDescriptionHome>
  <MetaDescriptionItem><![CDATA[{ITEM_NAME} - {EDITORIAL_REVIEW} - {SUBCATEGORY_NAME} - {CATEGORY_NAME}]]></MetaDescriptionItem>
  <MetaDescriptionSearch><![CDATA[{KEYWORD} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE}]]></MetaDescriptionSearch>
  <MetaDescriptionSearchAll><![CDATA[{KEYWORD} - {SITE_DESCRIPTION}{PAGE}]]></MetaDescriptionSearchAll>
  <MetaDescriptionSubcategory><![CDATA[{SUBCATEGORY_NAME} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE}]]></MetaDescriptionSubcategory>
  <MetaKeywordsCategory><![CDATA[{CATEGORY_NAME}, {SITE_KEYWORDS}]]></MetaKeywordsCategory>
  <MetaKeywordsHome><![CDATA[{SITE_KEYWORDS}]]></MetaKeywordsHome>
  <MetaKeywordsItem><![CDATA[{ITEM_NAME}, {SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS}]]></MetaKeywordsItem>
  <MetaKeywordsSearch><![CDATA[{KEYWORD}, {CATEGORY_NAME}, {SITE_KEYWORDS}]]></MetaKeywordsSearch>
  <MetaKeywordsSearchAll><![CDATA[{KEYWORD}, {SITE_KEYWORDS}]]></MetaKeywordsSearchAll>
  <MetaKeywordsSubcategory><![CDATA[{SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS}]]></MetaKeywordsSubcategory>
  <MiniCartBox>
    <Display><![CDATA[No]]></Display>
    <Label><![CDATA[Shopping Cart]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[I]]></Option>
      <Option><![CDATA[C]]></Option>
      <Option><![CDATA[CP]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </MiniCartBox>
  <MinimumPrice />
  <ModRewrite><![CDATA[Off]]></ModRewrite>
  <MostGiftedBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Most Gifted]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Count><![CDATA[10]]></Count>
    <Photos><![CDATA[Yes]]></Photos>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </MostGiftedBox>
  <MostWishedForBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Most Wished For]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Count><![CDATA[10]]></Count>
    <Photos><![CDATA[Yes]]></Photos>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </MostWishedForBox>
  <MovieFilter />
  <Mp3ClipsBox>
    <Display><![CDATA[Yes]]></Display>
    <Label />
    <BorderSize><![CDATA[0]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[I4]]></Location>
    <PlayerSize><![CDATA[250x250]]></PlayerSize>
    <DisplayPages>
      <Option><![CDATA[I]]></Option>
    </DisplayPages>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </Mp3ClipsBox>
  <NarrowByBrandBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Narrow By Brand]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
    </DisplayPages>
    <Order />
  </NarrowByBrandBox>
  <NarrowByPriceBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Narrow By Price]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
    </DisplayPages>
    <Order />
  </NarrowByPriceBox>
  <NewReleaseBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[New Releases]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Count><![CDATA[10]]></Count>
    <Photos><![CDATA[Yes]]></Photos>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </NewReleaseBox>
  <NewReleaseImage />
  <NoFollow>
    <Option><![CDATA[B]]></Option>
    <Option><![CDATA[I]]></Option>
    <Option><![CDATA[M]]></Option>
    <Option><![CDATA[R]]></Option>
    <Option><![CDATA[SB]]></Option>
    <Option><![CDATA[RB]]></Option>
    <Option><![CDATA[BB]]></Option>
    <Option><![CDATA[NB]]></Option>
    <Option><![CDATA[GB]]></Option>
    <Option><![CDATA[WB]]></Option>
    <Option><![CDATA[TB]]></Option>
    <Option><![CDATA[N1]]></Option>
    <Option><![CDATA[N2]]></Option>
    <Option><![CDATA[IB]]></Option>
  </NoFollow>
  <NodeFilter />
  <PageCaching><![CDATA[On]]></PageCaching>
  <PoweredBy><![CDATA[Lo mejor de España!]]></PoweredBy>
  <RelatedCategoryBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Related Categories]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[I]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </RelatedCategoryBox>
  <RelatedCategoryBoxNodes><![CDATA[All]]></RelatedCategoryBoxNodes>
  <RelatedCategoryBoxParent><![CDATA[4]]></RelatedCategoryBoxParent>
  <Reports>
    <Option><![CDATA[R1]]></Option>
    <Option><![CDATA[R2]]></Option>
  </Reports>
  <ReportsEmailFrom />
  <ReportsEmailHeader><![CDATA[Alguien Ha entrado a Comprar!]]></ReportsEmailHeader>
  <ReportsEmailTo><![CDATA[info@latiendamasguay.es]]></ReportsEmailTo>
  <ReportsTitle><![CDATA[{SITE_NAME} ({ASSOCIATE_ID}): Associate-O-Matic {REPORT} Report ({DATE} {TIME})]]></ReportsTitle>
  <ReviewBoxHeight><![CDATA[550]]></ReviewBoxHeight>
  <ReviewBoxWidth><![CDATA[100%]]></ReviewBoxWidth>
  <ReviewSort><![CDATA[-OverallRating]]></ReviewSort>
  <Rss>
    <Option><![CDATA[L]]></Option>
    <Option><![CDATA[S]]></Option>
    <Option><![CDATA[SA]]></Option>
  </Rss>
  <RssCustomBoxes><![CDATA[5]]></RssCustomBoxes>
  <RssCustomPages><![CDATA[10]]></RssCustomPages>
  <RssExternalFields>
    <Option><![CDATA[item-description]]></Option>
    <Option><![CDATA[item-pubDate]]></Option>
  </RssExternalFields>
  <RssFooter />
  <RssIcons><![CDATA[On]]></RssIcons>
  <RssLinkTarget><![CDATA[_blank]]></RssLinkTarget>
  <SearchAllProducts>
    <Mode><![CDATA[All]]></Mode>
  </SearchAllProducts>
  <SearchAutocomplete><![CDATA[Yes]]></SearchAutocomplete>
  <SearchBtnImage />
  <SearchCombo><![CDATA[Yes]]></SearchCombo>
  <SearchWithinResults><![CDATA[Yes]]></SearchWithinResults>
  <ShoppingCart><![CDATA[Yes]]></ShoppingCart>
  <ShoppingCartInstructions />
  <ShoppingCartInstructions2 />
  <SiteCss />
  <SiteDefaultKeyword />
  <SiteDescription><![CDATA[Compra en España con los precios MAS GUAYS!!!!!]]></SiteDescription>
  <SiteDisclaimer><![CDATA[{DISCLAIMER}]]></SiteDisclaimer>
  <SiteDocType />
  <SiteFooter />
  <SiteHead />
  <SiteHeader />
  <SiteKeywords><![CDATA[tienda, ofertas, españa, regalos]]></SiteKeywords>
  <SiteName><![CDATA[La Tienda Mas Guay!]]></SiteName>
  <SiteSlogan />
  <SiteTrafficCode><![CDATA[<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-27346668-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>]]></SiteTrafficCode>
  <Sort />
  <Subcategories />
  <SubcategoryBox>
    <Display><![CDATA[Yes]]></Display>
    <Label><![CDATA[Subcategories]]></Label>
    <BorderSize><![CDATA[1]]></BorderSize>
    <BorderColor><![CDATA[#CCCCCC]]></BorderColor>
    <BgColor><![CDATA[#FFFFFF]]></BgColor>
    <Location><![CDATA[L]]></Location>
    <DisplayPages>
      <Option><![CDATA[H]]></Option>
      <Option><![CDATA[L]]></Option>
      <Option><![CDATA[S]]></Option>
      <Option><![CDATA[I]]></Option>
      <Option><![CDATA[SA]]></Option>
    </DisplayPages>
    <Order />
    <Home><![CDATA[Off]]></Home>
  </SubcategoryBox>
  <SubcategoryColumns><![CDATA[4]]></SubcategoryColumns>
  <SubcategoryDescriptions />
  <SubcategoryPreference><![CDATA[ao]]></SubcategoryPreference>
  <TabBorderColor><![CDATA[#000000]]></TabBorderColor>
  <TabSpacing><![CDATA[0]]></TabSpacing>
  <TabStyle><![CDATA[style_01]]></TabStyle>
  <TextColor><![CDATA[#000000]]></TextColor>
  <TextDarkColor><![CDATA[#000000]]></TextDarkColor>
  <TextFont><![CDATA[Arial, sans-serif]]></TextFont>
  <TextHighlightColor><![CDATA[#990000]]></TextHighlightColor>
  <TextLightColor><![CDATA[#FFFFFF]]></TextLightColor>
  <TextLogo />
  <TextSize><![CDATA[small]]></TextSize>
  <Theme><![CDATA[default]]></Theme>
  <TileBgImage><![CDATA[No]]></TileBgImage>
  <TitleCategory><![CDATA[{SITE_NAME}: {CATEGORY_NAME}{PAGE}]]></TitleCategory>
  <TitleHome><![CDATA[{SITE_NAME}: {SITE_SLOGAN}{PAGE}]]></TitleHome>
  <TitleItem><![CDATA[{SITE_NAME}: {CATEGORY_NAME}: {ITEM_NAME}]]></TitleItem>
  <TitleMarketplace><![CDATA[{SITE_NAME}: {ITEM_NAME} - {OFFERS}{PAGE}]]></TitleMarketplace>
  <TitleSearch><![CDATA[{SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME} {KEYWORD} {PAGE}]]></TitleSearch>
  <TitleSearchAll><![CDATA[{SITE_NAME}: {KEYWORD}{PAGE}]]></TitleSearchAll>
  <TitleSubcategory><![CDATA[{SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME}{PAGE}]]></TitleSubcategory>
  <UrlCloak><![CDATA[On]]></UrlCloak>
  <UrlEndsWith><![CDATA[.html]]></UrlEndsWith>
  <UrlHomeFile><![CDATA[home]]></UrlHomeFile>
  <UrlNameLength><![CDATA[200]]></UrlNameLength>
  <UrlPlaceholder><![CDATA[none]]></UrlPlaceholder>
  <UrlSeparator><![CDATA[-]]></UrlSeparator>
  <UrlWithName><![CDATA[Yes]]></UrlWithName>
  <Version><![CDATA[5.2.0]]></Version>
  <Width><![CDATA[99%]]></Width>
</Associate-O-Matic>