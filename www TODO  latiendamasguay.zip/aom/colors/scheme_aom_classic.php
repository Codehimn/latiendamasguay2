<?php
// ASSOCIATE-O-MATIC COLOR SCHEME

// INFORMATION
$scheme['Name'] 				= "AOM Classic";
$scheme['Author'] 				= "Associate-O-Matic";
$scheme['Url'] 					= "http://www.associate-o-matic.com/colorschemes";

// COLORS (required)
$scheme['MainColor'] 			= "#0289C1";
$scheme['AccentColor'] 			= "#77C1DD";
$scheme['BgColor'] 				= "#EAEAEA";
$scheme['BodyBorderColor']		= "#EAEAEA";
$scheme['BodyBgColor'] 			= "#FFFFFF";
$scheme['BoxBorderColor'] 		= "#CCCCCC";
$scheme['BoxBgColor'] 			= "#FFFFFF";

// COLORS (optional)
$scheme['TextColor'] 			= "#000000";
$scheme['TextHighlightColor'] 	= "#990000";
$scheme['TextDarkColor'] 		= "#000000";
$scheme['TextLightColor'] 		= "#FFFFFF";
$scheme['LineColor'] 			= "#EAEAEA";
$scheme['LinkColor'] 			= "#0000CC";
$scheme['LinkHoverColor'] 		= "#6666FF";
$scheme['LinkVisitedColor'] 	= "#551A8B";
$scheme['TabBorderColor'] 		= "#000000";

?>