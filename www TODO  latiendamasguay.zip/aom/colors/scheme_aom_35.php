<?php
// ASSOCIATE-O-MATIC COLOR SCHEME

// INFORMATION
$scheme['Name'] 				= "AOM #35";
$scheme['Author'] 				= "Associate-O-Matic";
$scheme['Url'] 					= "http://www.associate-o-matic.com/colorschemes";

// COLORS (required)
$scheme['MainColor'] 			= "#78A8A8";
$scheme['AccentColor'] 			= "#A8C0C0";
$scheme['BgColor'] 				= "#BD4646";
$scheme['BodyBorderColor']		= "#FFFFFF";
$scheme['BodyBgColor'] 			= "#FFFFFF";
$scheme['BoxBorderColor'] 		= "#78A8A8";
$scheme['BoxBgColor'] 			= "#A8C0C0";

// COLORS (optional)
$scheme['TextColor'] 			= "#000000";
$scheme['TextHighlightColor'] 	= "#990000";
$scheme['TextDarkColor'] 		= "#000000";
$scheme['TextLightColor'] 		= "#FFFFFF";
$scheme['LineColor'] 			= "#EAEAEA";
$scheme['LinkColor'] 			= "#78A8A8";
$scheme['LinkHoverColor'] 		= "#A8C0C0";
$scheme['LinkVisitedColor'] 	= "#A8C0C0";
$scheme['TabBorderColor'] 		= "#000000";

?>