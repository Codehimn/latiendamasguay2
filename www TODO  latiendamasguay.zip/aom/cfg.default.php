<?php
/********************************************************************
Associate-O-Matic v5.2.0
http://www.associate-o-matic.com

Justin Mecham
info@associate-o-matic.com

DESCRIPTION
Default configuration settings

Copyright (c) 2004-2011 Associate-O-Matic. All Rights Reserved.
********************************************************************/

// *** DO NOT MODIFY ANYTHING BELOW THIS LINE UNLESS DIRECTED, AS ASSOCIATE-O-MATIC MAY NOT WORK PROPERLY ***

$version = "5.2.0";

$backups = 25; // number of AOM Admin backup files to keep

// AmazonStoreType
$cfg['AmazonStoreType']['enhanced'] = TRUE;
$cfg['AmazonStoreType']['section'] = "0";
$cfg['AmazonStoreType']['list'] = Array(
	'Amazon.com' 		=> 'Amazon.com (United States)',
	'Amazon.co.uk'		=> 'Amazon.co.uk (United Kingdom)',
	'Amazon.ca'		=> 'Amazon.ca (Canada)',
	'Amazon.de'		=> 'Amazon.de (Germany)',
	'Amazon.fr'		=> 'Amazon.fr (France)',
	'Amazon.co.jp'		=> 'Amazon.co.jp (Japan)',
	'Amazon.it'		=> 'Amazon.it (Italy)',
	'Amazon.cn'		=> 'Amazon.cn (China)',
	'Amazon.es'		=> 'Amazon.es (Spain)'
	);
$cfg['AmazonStoreType']['type'] = "country";
$cfg['AmazonStoreType']['help'] = "Select the locale for your Amazon store.";
$cfg['AmazonStoreType']['default'] = "Amazon.com";
$cfg['AmazonStoreType']['required'] = TRUE;

// AmazonAssociateId
$cfg['AmazonAssociateId']['section'] = "0";
$cfg['AmazonAssociateId']['type'] = "text";
$cfg['AmazonAssociateId']['help'] = "Enter your Amazon Associate ID. <b>Note:</b> This ID is country-specific (e.g. an ID for the US will not give you credit in a UK store). You must register for an Associate ID from the locale that matches your store:<br>
<a target=\"_blank\" href=\"http://associates.amazon.com/gp/associates/apply/main.html\">Amazon.com</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.co.uk/gp/associates/apply/main.html\">Amazon.co.uk</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.ca/gp/associates/apply/main.html\">Amazon.ca</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.de/gp/associates/apply/main.html\">Amazon.de</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.fr/gp/associates/apply/main.html\">Amazon.fr</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.co.jp/gp/associates/apply/main.html\">Amazon.co.jp</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"https://programma-affiliazione.amazon.it/gp/flex/associates/apply-login.html\">Amazon.it</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"http://associates.amazon.cn/gp/associates/apply/main.html\">Amazon.cn</a>&nbsp;&nbsp;
<a target=\"_blank\" href=\"https://afiliados.amazon.es/gp/flex/associates/apply-login.html\">Amazon.es</a>
";
$cfg['AmazonAssociateId']['default'] = "";
$cfg['AmazonAssociateId']['required'] = TRUE;

// AmazonAccessKeyId
$cfg['AmazonAccessKeyId']['section'] = "0";
$cfg['AmazonAccessKeyId']['type'] = "text";
if (!DEFINED("BRANDED"))
	$cfg['AmazonAccessKeyId']['help'] = "Enter your Amazon Access Key ID (a 20-character, alphanumeric sequence). <b>Note:</b> To obtain this ID, you must <a target=\"_blank\" href=\"https://aws-portal.amazon.com/gp/aws/developer/registration/index.html\">register with Amazon</a> to open a free AWS account. For more information see our <a target=\"_blank\" href=\"http://www.associate-o-matic.com/docs/doc_cp_amazon.html\">documentation</a>.";
else
	$cfg['AmazonAccessKeyId']['help'] = "Enter your Amazon Access Key ID (a 20-character, alphanumeric sequence). <b>Note:</b> To obtain this ID, you must <a target=\"_blank\" href=\"https://aws-portal.amazon.com/gp/aws/developer/registration/index.html\">register with Amazon</a> to open a free AWS account.";
$cfg['AmazonAccessKeyId']['default'] = "";
$cfg['AmazonAccessKeyId']['required'] = TRUE;

// AmazonSecretAccessKey
$cfg['AmazonSecretAccessKey']['section'] = "0";
$cfg['AmazonSecretAccessKey']['type'] = "password";
if (!DEFINED("BRANDED"))
	$cfg['AmazonSecretAccessKey']['help'] = "Enter your Amazon Secret Access Key (a 40-character sequence). <b>Note:</b> Keep this Key secure and never share it with anyone but Amazon. Because the Key is saved in a different file (cfg.secretkey.php) than your saved settings file (cfg.saved.php), you can share your saved settings in the forum or with support and your Key remains secure. <b>Another Note:</b> To obtain this Key, you must <a target=\"_blank\" href=\"https://aws-portal.amazon.com/gp/aws/developer/registration/index.html\">register with Amazon</a> to open a free AWS account. For more information see our <a target=\"_blank\" href=\"http://www.associate-o-matic.com/docs/doc_cp_amazon.html\">documentation</a>.";
else
	$cfg['AmazonSecretAccessKey']['help'] = "Enter your Amazon Secret Access Key (a 40-character sequence). <b>Note:</b> Keep this Key secure and never share it with anyone but Amazon. Because the Key is saved in a different file (cfg.secretkey.php) than your saved settings file (cfg.saved.php), you can share your saved settings in the forum or with support and your Key remains secure. <b>Another Note:</b> To obtain this Key, you must <a target=\"_blank\" href=\"https://aws-portal.amazon.com/gp/aws/developer/registration/index.html\">register with Amazon</a> to open a free AWS account.";	
$cfg['AmazonSecretAccessKey']['default'] = "";
$cfg['AmazonSecretAccessKey']['required'] = TRUE;

// AmazonTimeOffset
$cfg['AmazonTimeOffset']['section'] = "0";
$cfg['AmazonTimeOffset']['type'] = "text";
$cfg['AmazonTimeOffset']['help'] = "This allows you to adjust your server connection timestamp forward or backward. Add minutes (e.g. 20) or subtract minutes (e.g. -150). <b>Note:</b> Leave set at zero unless you are seeing errors that your server time is before or after Amazon server time.";
$cfg['AmazonTimeOffset']['default'] = "0";

// AmazonConnectionMethod
$cfg['AmazonConnectionMethod']['section'] = "0";
$cfg['AmazonConnectionMethod']['list'] = Array(
	'aom' => '[RECOMMENDED]&nbsp;&nbsp;&nbsp;&nbsp;Automatic Connection Detection',
	'rest_file' => 'REST (file) - Requires PHP setting allow_url_fopen be enabled (php.ini)',
	'rest_curl' => 'REST (curl) - Requires PHP libcurl library be installed',
	//'soap' => '[SLOWER]&nbsp;&nbsp;&nbsp;&nbsp;SOAP - Requires included /aom/cfg.soap.php',
	);
$cfg['AmazonConnectionMethod']['type'] = "complexmenu";
$cfg['AmazonConnectionMethod']['help'] = "This controls how data is pulled from Amazon servers and should not be changed unless you are directed to do so by our support team or you are not able to connect to Amazon and get errors to this effect. Almost always you will want to use <b>Automatic Connection Detection</b>.";
$cfg['AmazonConnectionMethod']['default'] = "aom";

// EcsVersion
$cfg['EcsVersion']['section'] = "20";
$cfg['EcsVersion']['type'] = "text";
$cfg['EcsVersion']['help'] = "Enter the ECS Version";
$cfg['EcsVersion']['default'] = "2005-09-15";
$cfg['EcsVersion']['required'] = TRUE;

// UrlRest
$cfg['UrlRest']['section'] = "20";
$cfg['UrlRest']['type'] = "text";
$cfg['UrlRest']['help'] = "Enter the URL for REST calls";
$cfg['UrlRest']['default'] = "http://webservices.amazon.com/onca/xml";
$cfg['UrlRest']['required'] = TRUE;

// UrlSoap
$cfg['UrlSoap']['section'] = "20";
$cfg['UrlSoap']['type'] = "text";
$cfg['UrlSoap']['help'] = "Enter the WSDL for SOAP calls";
$cfg['UrlSoap']['default'] = "";
$cfg['UrlSoap']['required'] = TRUE;

// sort
$cfg['Sort']['section'] = "-999";
$cfg['Sort']['required'] = TRUE;

////////////////////
// SORT: Amazon.com
$cfg['Sort']['list']['Amazon.com']['Apparel'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'-launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'pricerank' 		=> 'Price (Low to High)',
	'inverseprice'		=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['Appliances'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['ArtsAndCrafts'] = Array(
	'relevancerank' 	=> 'Relevance',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);	
$cfg['Sort']['list']['Amazon.com']['Automotive'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Baby'] = Array(
	'psrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);		
$cfg['Sort']['list']['Amazon.com']['Beauty'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'-launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);									
$cfg['Sort']['list']['Amazon.com']['Books'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['DVD'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-video-release-date' 	=> 'Release Date (Newer to Older)',
	'-releasedate'		=> 'Release Date (Older to Newer)',
	);
$cfg['Sort']['list']['Amazon.com']['Electronics'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.com']['GourmetFood'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'pricerank' 		=> 'Price (Low to High)',
	'inverseprice'		=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['Grocery'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'inverseprice'		=> 'Price (Low to High)',
	'pricerank' 		=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['HealthPersonalCare'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'inverseprice' 		=> 'Price (Low to High)',
	'pricerank'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['HomeGarden'] = Array(
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Industrial'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);				
$cfg['Sort']['list']['Amazon.com']['Jewelry'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'launch-date' 		=> 'Newest Arrivals',
	'pricerank' 		=> 'Price (Low to High)',
	'inverseprice'		=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['KindleStore'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'pricerank' 			=> 'Price (Low to High)',
	'inverse-pricerank'			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Kitchen'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Magazines'] = Array(
	'subslot-salesrank'	=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	);
$cfg['Sort']['list']['Amazon.com']['MobileApps'] = Array(
	'relevancerank' 	=> 'Relevance',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'reviewrank' 		=> 'Reviews (High to Low)',
	);	
$cfg['Sort']['list']['Amazon.com']['MP3Downloads'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-releasedate'		=> 'Release Date (Older to Newer)',
	);
$cfg['Sort']['list']['Amazon.com']['Music'] = Array(
	'psrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'artistrank'		=> 'Artist Name',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	'orig-rel-date'		=> 'Original Release Date (Newer to Older)',
	'release-date'		=> 'Release Date (Newer to Older)',
	'-releasedate'		=> 'Release Date (Older to Newer)',
	);
$cfg['Sort']['list']['Amazon.com']['MusicalInstruments'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'-launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['OfficeProducts'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.com']['OutdoorLiving'] = Array(
	'psrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['PCHardware'] = Array(
	'psrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.com']['PetSupplies'] = Array(
	'+pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Photo'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Shoes'] = Array(
	'pmrank' 			=> 'Relevance',
	'xsrelevancerank'	=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-launch-date' 		=> 'Newest Arrivals',
	);
$cfg['Sort']['list']['Amazon.com']['Software'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.com']['SportingGoods'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'launch-date' 		=> 'Newest Arrivals',
	'sale-flag' 		=> 'On Sale',
	'inverseprice' 		=> 'Price (Low to High)',
	'pricerank'			=> 'Price (High to Low)',
	);					
$cfg['Sort']['list']['Amazon.com']['Tools'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.com']['Toys'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-age-min' 			=> 'Age (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['UnboxVideo'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-video-release-date' 	=> 'Release Date (Newer to Older)',
	);
$cfg['Sort']['list']['Amazon.com']['VHS'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-video-release-date' 	=> 'Release Date (Newer to Older)',
	'-releasedate'		=> 'Release Date (Older to Newer)',
	);					
$cfg['Sort']['list']['Amazon.com']['VideoGames'] = Array(
	'pmrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.com']['Watches'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.com']['Wireless'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank' => 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	'daterank' 			=> 'Release Date (Newer to Older)',
	);
$cfg['Sort']['list']['Amazon.com']['WirelessAccessories'] = Array(
	'psrank' 			=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);

//////////////////////
// SORT: Amazon.co.uk
$cfg['Sort']['list']['Amazon.co.uk']['Apparel'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-launch-date' 		=> 'Newest Arrivals',
	);			
$cfg['Sort']['list']['Amazon.co.uk']['Automotive'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);	
$cfg['Sort']['list']['Amazon.co.uk']['Baby'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);	
$cfg['Sort']['list']['Amazon.co.uk']['Beauty'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Books'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'pubdate' 			=> 'Publication Date (Older to Newer)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['DVD'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	'daterank' 			=> 'Release Date (Newer to Older)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Electronics'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Grocery'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['HealthPersonalCare'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['HomeGarden'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['HomeImprovement'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Jewelry'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-launch-date' 		=> 'Newest Arrivals',
	);
$cfg['Sort']['list']['Amazon.co.uk']['KindleStore'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);	
$cfg['Sort']['list']['Amazon.co.uk']['Kitchen'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Lighting'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);				
$cfg['Sort']['list']['Amazon.co.uk']['MP3Downloads'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-releasedate'		=> 'Release Date (Older to Newer)',
	);	
$cfg['Sort']['list']['Amazon.co.uk']['Music'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank' => 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['OfficeProducts'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price' 			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['OutdoorLiving'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price' 			=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Shoes'] = Array(
	'pmrank' 			=> 'Relevance',
	'xsrelevancerank'	=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'-launch-date' 		=> 'Newest Arrivals',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Software'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['SportingGoods'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price' 			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Tools'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'daterank' 			=> 'Release Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);											
$cfg['Sort']['list']['Amazon.co.uk']['Toys'] = Array(
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'mfg-age-min' 		=> 'Age (Low to High)',
	'-mfg-age-min' 		=> 'Age (High to Low)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['VHS'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);		
$cfg['Sort']['list']['Amazon.co.uk']['VideoGames'] = Array(
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.co.uk']['Watches'] = Array(
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);

///////////////////					
// SORT: Amazon.ca				
$cfg['Sort']['list']['Amazon.ca']['Books'] = Array(
	'salesrank'			=> 'Bestselling',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'daterank' 			=> 'Publication Date (Newer to Older)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.ca']['DVD'] = Array(
	'salesrank'			=> 'Bestselling',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.ca']['Electronics'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);
$cfg['Sort']['list']['Amazon.ca']['Kitchen'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);
$cfg['Sort']['list']['Amazon.ca']['Music'] = Array(
	'salesrank'			=> 'Bestselling',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'orig-rel-date' 	=> 'Publication Date (Newer to Older)',
	);					
$cfg['Sort']['list']['Amazon.ca']['Software'] = Array(
	'salesrank'			=> 'Bestselling',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'-daterank' 		=> 'Publication Date (Older to Newer)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	);
$cfg['Sort']['list']['Amazon.ca']['SportingGoods'] = Array(
	'relevancerank' 	=> 'Relevance',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Reviews (High to Low)',
	'price' 			=> 'Price (Low to High)',
	'-price'			=> 'Price (High to Low)',
	);						
$cfg['Sort']['list']['Amazon.ca']['VHS'] = Array(
	'salesrank'			=> 'Bestselling',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);							
$cfg['Sort']['list']['Amazon.ca']['VideoGames'] = Array(
	'salesrank'			=> 'Bestselling',
	'pricerank' 		=> 'Price (Low to High)',
	'inverse-pricerank'	=> 'Price (High to Low)',
	'titlerank' 		=> 'Alphabetical (A-Z)',
	'-titlerank' 		=> 'Alphabetical (Z-A)',
	);

///////////////////					
// SORT: Amazon.de
$cfg['Sort']['list']['Amazon.de']['Automotive'] = Array(
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['Apparel'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['Baby'] = Array(
	'psrank' 			=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	);
$cfg['Sort']['list']['Amazon.de']['Beauty'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['Books'] = Array(
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'pricerank' 		=> 'Preis (Aufsteigend)',
	'inverse-pricerank'	=> 'Preis (Absteigend)',
	'-pubdate' 			=> 'Erscheinungsdatum (neu bis älter)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['DVD'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Electronics'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['ForeignBooks'] = Array(
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'pricerank' 		=> 'Preis (Aufsteigend)',
	'inverse-pricerank'	=> 'Preis (Absteigend)',
	'-pubdate' 			=> 'Erscheinungsdatum (neu bis älter)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Grocery'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Bestselling',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['HealthPersonalCare'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['HomeGarden'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Jewelry'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['KindleStore'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Kitchen'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Lighting'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['Magazines'] = Array(
	'salesrank'			=> 'Topseller',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['MP3Downloads'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'artistalbumrank' 	=> 'Künstler: A bis Z',
	'-artistalbumrank' 	=> 'Künstler: Z bis A',
	'albumrank' 		=> 'Album: A bis Z',
	'-albumrank' 		=> 'Album: Z bis A',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'-releasedate'		=> 'Erscheinungstermin',
	);
$cfg['Sort']['list']['Amazon.de']['Music'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'pubdate' 			=> 'Erscheinungsdatum (neu bis älter)',
	'-pubdate' 			=> 'Erscheinungsdatum (älter bis neu)',
	);
$cfg['Sort']['list']['Amazon.de']['MusicalInstruments'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'reviewrank' 		=> 'Kundenbewertung',
	);
$cfg['Sort']['list']['Amazon.de']['OfficeProducts'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	);
$cfg['Sort']['list']['Amazon.de']['OutdoorLiving'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['PCHardware'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Photo'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);
$cfg['Sort']['list']['Amazon.de']['Shoes'] = Array(
	'relevancerank' 	=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
 	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'-launch-date'		=> 'Erscheinungsdatum (neu bis älter)',
	);
$cfg['Sort']['list']['Amazon.de']['SportingGoods'] = Array(
	'salesrank'			=> 'Topseller',
	'reviewrank' 		=> 'Kundenbewertung',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'release-date' 		=> 'Erscheinungsdatum (neu bis älter)',
	'-release-date' 	=> 'Erscheinungsdatum (älter bis neu)',
	);
$cfg['Sort']['list']['Amazon.de']['Software'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'-date' 			=> 'Erscheinungsdatum (neu bis älter)',
	);
$cfg['Sort']['list']['Amazon.de']['Tools'] = Array(
	'pmrank' 			=> 'Gekennzeichnet',
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'-date' 			=> 'Erscheinungsdatum (neu bis älter)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	);
$cfg['Sort']['list']['Amazon.de']['Toys'] = Array(
	'+salesrank'		=> 'Topseller',
	'+price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'+titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'-date' 			=> 'Erscheinungsdatum (neu bis älter)',
	);
$cfg['Sort']['list']['Amazon.de']['VHS'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);					
$cfg['Sort']['list']['Amazon.de']['VideoGames'] = Array(
	'salesrank'			=> 'Topseller',
	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	'-date' 			=> 'Erscheinungsdatum (neu bis älter)',
	);
$cfg['Sort']['list']['Amazon.de']['Watches'] = Array(
	'salesrank'			=> 'Topseller',
 	'price' 			=> 'Preis (Aufsteigend)',
	'-price'			=> 'Preis (Absteigend)',
	'titlerank' 		=> 'Alphabet (A bis Z)',
	'-titlerank' 		=> 'Alphabet (Z bis A)',
	);

///////////////////					
// SORT: Amazon.fr
$cfg['Sort']['list']['Amazon.fr']['Apparel'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Beauty'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Baby'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	);
$cfg['Sort']['list']['Amazon.fr']['Books'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'pricerank' 		=> 'Prix (Croissant)',
	'inverse-pricerank'	=> 'Prix (Décroissant)',
	'-daterank' 		=> 'Date de publication (De la plus ancienne à la plus récente)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['PCHardware'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);	
$cfg['Sort']['list']['Amazon.fr']['DVD'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['Electronics'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['ForeignBooks'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'pricerank' 		=> 'Prix (Croissant)',
	'inverse-pricerank'	=> 'Prix (Décroissant)',
	'-daterank' 		=> 'Date de publication (De la plus ancienne à la plus récente)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['HealthPersonalCare'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Jewelry'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Kitchen'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	);
$cfg['Sort']['list']['Amazon.fr']['Lighting'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['MusicalInstruments'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['MP3Downloads'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'titlerank'			=> 'Titre chanson (A à Z)',
	'-titlerank'		=> 'Titre chanson (Z à A)',
	'artistalbumrank' 	=> 'Artiste (A à Z)',
	'-artistalbumrank' 	=> 'Artiste (Z à A)',
	'albumrank' 		=> 'Album (A à Z)',
	'-albumrank' 		=> 'Album (Z à A)',
	'relevancerank' 	=> 'Pertinence',
	'reviewrank'		=> 'Note moyenne des commentaires',
	'-releasedate'		=> 'Date de sortie',
	);
$cfg['Sort']['list']['Amazon.fr']['Music'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'pricerank' 		=> 'Prix (Croissant)',
	'inverse-pricerank'	=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['OfficeProducts'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Shoes'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Software'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-pricerank'		=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);
$cfg['Sort']['list']['Amazon.fr']['SportingGoods'] = Array(
	'relevancerank' 	=> 'Pertinence',
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'reviewrank'		=> 'Note moyenne des commentaires',
	);
$cfg['Sort']['list']['Amazon.fr']['Toys'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
 	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
 	);					
$cfg['Sort']['list']['Amazon.fr']['VHS'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);					
$cfg['Sort']['list']['Amazon.fr']['VideoGames'] = Array(
	'salesrank'			=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	'date' 				=> 'Date (De la plus récente à la plus ancienne)',
	);
$cfg['Sort']['list']['Amazon.fr']['Watches'] = Array(
	'salesrank'		=> 'Meilleures Ventes',
	'price' 			=> 'Prix (Croissant)',
	'-price'			=> 'Prix (Décroissant)',
	'titlerank' 		=> 'Alphabétique (A à Z)',
	'-titlerank' 		=> 'Alphabétique (Z à A)',
	);

///////////////////					
// SORT: Amazon.co.jp
$cfg['Sort']['list']['Amazon.co.jp']['Apparel'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Beauty'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Books'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['DVD'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Electronics'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Grocery'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['HealthPersonalCare'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['HomeImprovement'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Jewelry'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Kitchen'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['MP3Downloads'] = Array(
    'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Music'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['OfficeProducts'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Shoes'] = Array(
	'relevancerank' 	=> '&#12362;&#12377;&#12377;&#12417;&#21830;&#21697;',
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'reviewrank' 		=> '&#12524;&#12499;&#12517;&#12540;&#65288;[&#20302;]&#12395;&#39640;&#65289;',
	'-launch-date' 		=> 'Newest Arrivals',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Software'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['SportingGoods'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'release-date' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-release-date'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);					
$cfg['Sort']['list']['Amazon.co.jp']['Toys'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['VHS'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);					
$cfg['Sort']['list']['Amazon.co.jp']['VideoGames'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'releasedate' 		=> '&#21476;&#12356;&#12395;&#30330;&#22770;&#26085;&#65288;&#26032;&#12375;&#12356;&#65289;',
	'-releasedate'		=> '&#12381;&#12428;&#20197;&#38477;&#12395;&#30330;&#22770;&#26085;&#65288;&#21476;&#12356;&#65289;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);
$cfg['Sort']['list']['Amazon.co.jp']['Watches'] = Array(
	'salesrank'			=> '&#22770;&#12428;&#12390;&#12356;&#12427;&#38918;&#30058;',
	'price' 			=> '&#20385;&#26684;&#12398;&#23433;&#12356;&#38918;&#30058;',
	'-price'			=> '&#20385;&#26684;&#12398;&#39640;&#12356;&#38918;&#30058;',
	'titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#26119;&#38918;',
	'-titlerank' 		=> '&#12450;&#12523;&#12501;&#12449;&#12505;&#12483;&#12488;&#38918;&#38477;&#38918;',
	);

///////////////////					
// SORT: Amazon.it
$cfg['Sort']['list']['Amazon.it']['Books'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank_authority' 		=> 'Media recensioni clienti',
	'-pubdate' 		=> 'Data di pubblicazione'
	);
$cfg['Sort']['list']['Amazon.it']['DVD'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-releasedate'		=> 'Disponibile da'
	);	
$cfg['Sort']['list']['Amazon.it']['Electronics'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	);	
$cfg['Sort']['list']['Amazon.it']['ForeignBooks'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-pubdate' 			=> 'Data di pubblicazione'
	);
$cfg['Sort']['list']['Amazon.it']['Garden'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-pubdate' 			=> 'Data di pubblicazione'
	);
$cfg['Sort']['list']['Amazon.it']['Kitchen'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	);		
$cfg['Sort']['list']['Amazon.it']['Music'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-releasedate'		=> 'Disponibile da'
	);
$cfg['Sort']['list']['Amazon.it']['Shoes'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	);
$cfg['Sort']['list']['Amazon.it']['Software'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-releasedate'		=> 'Disponibile da'
	);
$cfg['Sort']['list']['Amazon.it']['Toys'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	);
$cfg['Sort']['list']['Amazon.it']['VideoGames'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	'-releasedate'		=> 'Disponibile da'
	);
$cfg['Sort']['list']['Amazon.it']['Watches'] = Array(
	'salesrank'			=> 'Popolarità',
	'price' 			=> 'Prezzo: crescente',
	'-price'			=> 'Prezzo: decrescente',
	'reviewrank' 		=> 'Media recensioni clienti',
	);

	
///////////////////					
// SORT: Amazon.cn
$cfg['Sort']['list']['Amazon.cn']['Apparel'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	'-pct-off'			=> '折扣',
	'reviewrank_authority' 		=> '用户评分',
	'-launch-date' 		=> '上架时间',
	);
$cfg['Sort']['list']['Amazon.cn']['Appliances'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	'-pct-off'			=> '折扣',
	'reviewrank_authority' 		=> '用户评分',
	'-launch-date' 		=> '上架时间',
	);
$cfg['Sort']['list']['Amazon.cn']['Automotive'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	'-pct-off'			=> '折扣',
	'reviewrank_authority' 		=> '用户评分',
	'-launch-date' 		=> '上架时间',
	);
$cfg['Sort']['list']['Amazon.cn']['Baby'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	'reviewrank_authority' 		=> '用户评分',
	);
$cfg['Sort']['list']['Amazon.cn']['Beauty'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Books'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	'-publication_date' 			=> '出版日期'
	);
$cfg['Sort']['list']['Amazon.cn']['Electronics'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Grocery'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['HealthPersonalCare'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Home'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['HomeImprovement'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Jewelry'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Music'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['OfficeProducts'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Photo'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Shoes'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Software'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['SportingGoods'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Toys'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Video'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['VideoGames'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);
$cfg['Sort']['list']['Amazon.cn']['Watches'] = Array(
	'salesrank'			=> '受欢迎程度',
	'price' 			=> '价格：由低到高',
	'-price'			=> '价格：由高到低',
	);

///////////////////					
// SORT: Amazon.es
$cfg['Sort']['list']['Amazon.es']['Books'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-pubdate'		=> 'Fecha de publicación'
	);
$cfg['Sort']['list']['Amazon.es']['DVD'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-releasedate'		=> 'Fecha de lanzamiento'
	);
$cfg['Sort']['list']['Amazon.es']['Electronics'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     );
$cfg['Sort']['list']['Amazon.es']['ForeignBooks'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-pubdate'		=> 'Fecha de publicación'
	);
$cfg['Sort']['list']['Amazon.es']['Kitchen'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     );
$cfg['Sort']['list']['Amazon.es']['Music'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-releasedate'		=> 'Fecha de lanzamiento'
	);
$cfg['Sort']['list']['Amazon.es']['Software'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-releasedate'		=> 'Fecha de lanzamiento'
	);
$cfg['Sort']['list']['Amazon.es']['Toys'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     );
$cfg['Sort']['list']['Amazon.es']['VideoGames'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     '-releasedate'		=> 'Fecha de lanzamiento'
	);
$cfg['Sort']['list']['Amazon.es']['Watches'] = Array(
	'relevancerank'	=> 'Importancia',
	'salesrank'		=> 'Popularidad',
	'price'			=> 'Precio: de más bajo a más alto',
     '-price'			=> 'Precio: de más alto a más bajo',
     'reviewrank_authority'	=> 'Opinión media de los clientes',
     );

	
	
// Categories
$cfg['Categories']['section'] = "4";
$cfg['Categories']['type'] = "categories";
$cfg['Categories']['help'] = "<b>INSTRUCTIONS:</b> This is where you setup your store categories.<br><br>
<b>Category ID:</b><br>Enter your own unique Category ID (e.g. books, 123, etc.)<br><br><b>Name:</b><br>Enter the Names for each<br><br><b>Amazon Category:</b><br>
There are 5 types of categories to choose from...<br>
<ul>
<li><b>Regular Category:</b> This is a category based on an Amazon category such as Books, DVD, etc.</li>
<li><b>Blended Category:</b> This is a category based on a specific keyword which will give results across multiple Amazon Categories.</li>
<li><b>ASIN List Category:</b> This is a category based on a ASINs (items) of your choice (comma separated in Keyword box).</li>
<li><b>ASIN File Category:</b> This is a category based on a ASINs (items) of your choice (comma separated inside a separate file) where the file name is entered in the Keyword box.</li>
<li><b>URL Category:</b> This is a category that simply points to any URL you specify which would be entered in the Keyword box</li>
</ul>
<b>Browse Node:</b><br>Leave the default Browse Node (Amazon Category ID) or enter a different one (must be associated with Amazon Category selected). <b>Tip:</b> You can also enter multiple browse nodes separated by commas (e.g. 111,222) for a unique blend of items. ";

if (!DEFINED("BRANDED"))
	$cfg['Categories']['help'] .= "<b>Note:</b> To find Amazon browse nodes visit our sister website: <b><a href=\"http://www.findbrowsenodes.com\" target=\"_blank\">FindBrowseNodes.com</a></b>";

$cfg['Categories']['help'] .= "<br><br><b>Site Default Keyword (SDK):</b><br>Check/uncheck box if you want this category to use the SDK (if specified)<br><br><b>Keyword/ASINs:</b><br>Optionally, specify a default Keyword to fine-tune results at category level. Or if you selected ASIN LIST as the Category type, enter specific ASINs to be displayed.<br><br><b>Item Type (I):</b><br>This setting controls the types of Items that will be featured on Category, Subcategory and Item pages. Note If set to a type other than All, fewer items will be availabe in your store. <b>A=All</b>, <b>N=New</b>, <b>U=Used</b>, <b>C=Collectible</b>, <b>R=Refurbished</b> <br><br><b>Tab (T):</b><br>Check/uncheck box if you want this category displayed as a Tab<br><br><b>Menu (M):</b><br>Check/uncheck box if you want this category displayed in the search drop down Menu<br><br><b>Box (B):</b><br>Check/uncheck box if you want this category displayed in the Category box<br><br><b>Subcategories (S):</b><br>Check/uncheck box if you want Subcategories displayed in this Category<br><br><b>Order:</b><br>Select the Display Order (1 will be displayed first and so on)<br><br><b>Notes:</b><br>&#149; To add categories enter the number you want to add below and click the Go button. To delete a category, clear out the Name and click Save All Settings<br><br>&#149; Browse Nodes in green are using the default Browse Node. Browse Nodes in Grey are using something other than the current default Browse Node (which is OK so long as it is part of the Amazon category selected). To get back to the original default Browse Node for a category, simply delete the node and leave the field. It will go back to the default.<br><br>&#149; All applicable related categories and subcategories are automatically displayed inside the associated Related Category and Subcategory Boxes if you choose to display them.<br><br>";
$cfg['Categories']['required'] = TRUE;

//////////////////////////
// Categories: Amazon.com
// Amazon.com: Apparel
$cfg['Categories']['list']['Amazon.com']['Apparel']['name'] = "Apparel";
$cfg['Categories']['list']['Amazon.com']['Apparel']['node'] = "1036682";
$cfg['Categories']['list']['Amazon.com']['Apparel']['nodes']['1036682'] = Array(
	'1040660'	=>  'Women',
	'1040658'	=>  'Men',
	'1040662'	=>  'Kids & Baby',
	);
// Amazon.com: Appliances
$cfg['Categories']['list']['Amazon.com']['Appliances']['name'] = "Appliances";
$cfg['Categories']['list']['Amazon.com']['Appliances']['node'] = "2619526011";
$cfg['Categories']['list']['Amazon.com']['Appliances']['nodes']['2619526011'] = Array(
	'267554011'	=>  'Air Purifiers',
	'3741271'	=>  'Dishwashers',
	'289935'	=>  'Microwave Ovens',
	);
// Amazon.com: ArtsAndCrafts
$cfg['Categories']['list']['Amazon.com']['ArtsAndCrafts']['name'] = "Arts & Crafts";
$cfg['Categories']['list']['Amazon.com']['ArtsAndCrafts']['node'] = "2617942011";
$cfg['Categories']['list']['Amazon.com']['ArtsAndCrafts']['nodes']['2617942011'] = Array(
	'2747968011'=>  'Art Supplies',
	'378733011'	=>  'Craft Supplies',
	'12898821'	=>  'Scrapbooking',
	);		
// Amazon.com: Automotive
$cfg['Categories']['list']['Amazon.com']['Automotive']['name'] = "Automotive";
$cfg['Categories']['list']['Amazon.com']['Automotive']['node'] = "15690151";
$cfg['Categories']['list']['Amazon.com']['Automotive']['nodes']['15690151'] = Array(
	'15857511' =>  'Exterior Accessories',
	'15857501' =>  'Interior Accessories',
	'15710351' =>  'Performance Parts',
	);
// Amazon.com: Baby
$cfg['Categories']['list']['Amazon.com']['Baby']['name'] = "Baby";
$cfg['Categories']['list']['Amazon.com']['Baby']['node'] = "165797011";
$cfg['Categories']['list']['Amazon.com']['Baby']['nodes']['165797011'] = Array(
	'166742011'  =>  'Bedding',
	'166842011'  =>  'Strollers',
	'166828011'  =>  'Gear',
	);
// Amazon.com: Beauty
$cfg['Categories']['list']['Amazon.com']['Beauty']['name'] = "Beauty";
$cfg['Categories']['list']['Amazon.com']['Beauty']['node'] = "11055981";
$cfg['Categories']['list']['Amazon.com']['Beauty']['nodes']['11055981'] = Array(
	'11055991' => 'Bath & Shower',
	'11056591' => 'Fragrance',
	'11057241' => 'Hair Care',
	);
// Amazon.com: Books
$cfg['Categories']['list']['Amazon.com']['Books']['name'] = "Books";
$cfg['Categories']['list']['Amazon.com']['Books']['node'] = "1000";
$cfg['Categories']['list']['Amazon.com']['Books']['nodes']['1000'] = Array(
	'3' 		=>	'Business',
	'17' 		=>	'Fiction',
	'53' 		=>	'Nonfiction',
	);
// Amazon.com: Computers
$cfg['Categories']['list']['Amazon.com']['PCHardware']['name'] = "Computers";
$cfg['Categories']['list']['Amazon.com']['PCHardware']['node'] = "541966";
$cfg['Categories']['list']['Amazon.com']['PCHardware']['nodes']['541966'] = Array(
	'565118'	=>  'Brands',
	'565098'  =>  'Desktops',
	'172455'  =>  'Computer Add-Ons',
	);
// Amazon.com: DVD
$cfg['Categories']['list']['Amazon.com']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.com']['DVD']['node'] = "2625374011";
$cfg['Categories']['list']['Amazon.com']['DVD']['nodes']['2625374011'] = Array(
	'2649512011'  	=>  'Movies',
	'2649513011'  	=>  'TV',
	);
// Amazon.com: Electronics	  
$cfg['Categories']['list']['Amazon.com']['Electronics']['name'] = "Electronics";
$cfg['Categories']['list']['Amazon.com']['Electronics']['node'] = "493964";
$cfg['Categories']['list']['Amazon.com']['Electronics']['nodes']['493964'] = Array(
	'226721'  =>  'Brands',
	'1065836' =>  'Audio & Video',
	'172526'  =>  'GPS',
	);
// Amazon.com: Gourmet Food
$cfg['Categories']['list']['Amazon.com']['GourmetFood']['name'] = "Gourmet Food";
$cfg['Categories']['list']['Amazon.com']['GourmetFood']['node'] = "2255571011";
$cfg['Categories']['list']['Amazon.com']['GourmetFood']['nodes']['2255571011'] = Array(
	'2255572011' =>  'Candy',
	'2255573011' =>  'Cheese',
	'2255574011' =>  'Chocolate',
	);
// Amazon.com: Grocery
$cfg['Categories']['list']['Amazon.com']['Grocery']['name'] = "Grocery";
$cfg['Categories']['list']['Amazon.com']['Grocery']['node'] = "16310211";
$cfg['Categories']['list']['Amazon.com']['Grocery']['nodes']['16310211'] = Array(
	'16310301' =>  'Snacks, Cookies & Candy',
	'16310251' =>  'Breakfast Foods',
	'16310331' =>  'Baking Supplies',
	);
// Amazon.com: Health/Personal Care
$cfg['Categories']['list']['Amazon.com']['HealthPersonalCare']['name'] = "Health";
$cfg['Categories']['list']['Amazon.com']['HealthPersonalCare']['node'] = "3760931";
$cfg['Categories']['list']['Amazon.com']['HealthPersonalCare']['nodes']['3760931'] = Array(
	'3760941' =>  'Health Care',
	'3764441' =>  'Nutrition',
	'3775161' =>  'Medical Supplies',
	);
// Amazon.com: HomeGarden
$cfg['Categories']['list']['Amazon.com']['HomeGarden']['name'] = "Home & Garden";
$cfg['Categories']['list']['Amazon.com']['HomeGarden']['node'] = "1063498";
$cfg['Categories']['list']['Amazon.com']['HomeGarden']['nodes']['1063498'] = Array(
	'1057792' =>  'Bed & Bath',
	'510080'  =>  'Housewares',
	'1057794' =>  'Furniture & Decor',
	);
// Amazon.com: Industrial
$cfg['Categories']['list']['Amazon.com']['Industrial']['name'] = "Industrial & Science";
$cfg['Categories']['list']['Amazon.com']['Industrial']['node'] = "16310161";
$cfg['Categories']['list']['Amazon.com']['Industrial']['nodes']['16310161'] = Array(
	'16310191' =>  'Raw Materials',
	'16310171' =>  'Fasteners',
	'16310181' =>  'Mechanical Components',
	);
// Amazon.com: Jewelry
$cfg['Categories']['list']['Amazon.com']['Jewelry']['name'] = "Jewelry";
$cfg['Categories']['list']['Amazon.com']['Jewelry']['node'] = "3880591";
$cfg['Categories']['list']['Amazon.com']['Jewelry']['nodes']['3880591'] = Array(
	'3887251'	=>  'Rings',
	'3888811'	=>  'Watches',
	'16014541'=>  'Wedding',
	);
// Amazon.com: KindleStore
$cfg['Categories']['list']['Amazon.com']['KindleStore']['name'] = "Kindle eBooks";
$cfg['Categories']['list']['Amazon.com']['KindleStore']['node'] = "358606011";
$cfg['Categories']['list']['Amazon.com']['KindleStore']['nodes']['358606011'] = Array(
	'154606011'  =>  'Kindle eBooks',
	'241646011'  =>  'Kindle Magazines',
	'165389011'  =>  'Kindle Newspapers',
	);
// Amazon.com: Kitchen
$cfg['Categories']['list']['Amazon.com']['Kitchen']['name'] = "Kitchen";
$cfg['Categories']['list']['Amazon.com']['Kitchen']['node'] = "284507";
$cfg['Categories']['list']['Amazon.com']['Kitchen']['nodes']['284507'] = Array(
	'291358'  =>  'Brands',
	'289814'  =>  'Cookware',
	'13162311'=>  'Tableware',
	);
// Amazon.com: Magazines
$cfg['Categories']['list']['Amazon.com']['Magazines']['name'] = "Magazines";
$cfg['Categories']['list']['Amazon.com']['Magazines']['node'] = "599872";
$cfg['Categories']['list']['Amazon.com']['Magazines']['nodes']['599872'] = Array(
	'604876'  =>  'Titles, A-Z',
	'602352'  =>  'Men\'s Interest',
	'602372'  =>  'Women\'s Interest',
	);
// Amazon.com: Miscellaneous
$cfg['Categories']['list']['Amazon.com']['Miscellaneous']['name'] = "Miscellaneous";
$cfg['Categories']['list']['Amazon.com']['Miscellaneous']['node'] = "10304191";
$cfg['Categories']['list']['Amazon.com']['Miscellaneous']['nodes']['10304191'] = Array(
	'2478844011'  =>  'Games',
	'2478856011'  =>  'News & Weather',
	'2478860011'  =>  'Photography',
	);	
// Amazon.com: MobileApps
$cfg['Categories']['list']['Amazon.com']['MobileApps']['name'] = "Mobile Apps";
$cfg['Categories']['list']['Amazon.com']['MobileApps']['node'] = "2350150011";
$cfg['Categories']['list']['Amazon.com']['MobileApps']['nodes']['2350150011'] = Array(
	'2478844011'  =>  'Games',
	'2478856011'  =>  'News & Weather',
	'2478860011'  =>  'Photography',
	);	
// Amazon.com: MP3 Downloads
$cfg['Categories']['list']['Amazon.com']['MP3Downloads']['name'] = "MP3 Downloads";
$cfg['Categories']['list']['Amazon.com']['MP3Downloads']['node'] = "624868011";
$cfg['Categories']['list']['Amazon.com']['MP3Downloads']['nodes']['624868011'] = Array(
	'625092011' =>  'Pop',
	'625105011' =>  'R&B',
	'625129011' =>  'Rock',
	);
// Amazon.com: Music
$cfg['Categories']['list']['Amazon.com']['Music']['name'] = "Music";
$cfg['Categories']['list']['Amazon.com']['Music']['node'] = "301668";
$cfg['Categories']['list']['Amazon.com']['Music']['nodes']['301668'] = Array(
	'37' 		=>  'Pop',
	'40'		=>	'Rock',
	'42' 		=>  'Soundtracks',
	);
// Amazon.com: Musical Instruments
$cfg['Categories']['list']['Amazon.com']['MusicalInstruments']['name'] = "Musical Instruments";
$cfg['Categories']['list']['Amazon.com']['MusicalInstruments']['node'] = "11965861";
$cfg['Categories']['list']['Amazon.com']['MusicalInstruments']['nodes']['11965861'] = Array(
	'11970241' =>  'Drums & Percussion',
	'11971241' =>  'Guitars',
	'11970071' =>  'Pianos',
	);
// Amazon.com: Office Products
$cfg['Categories']['list']['Amazon.com']['OfficeProducts']['name'] = "Office Products";
$cfg['Categories']['list']['Amazon.com']['OfficeProducts']['node'] = "1084128";
$cfg['Categories']['list']['Amazon.com']['OfficeProducts']['nodes']['1084128'] = Array(
	'1086182'	=>  'Brands',
	'1069102'	=>  'Furniture', 
	'1069242'	=>  'Office Supplies',
	);
// Amazon.com: Outdoor Living
$cfg['Categories']['list']['Amazon.com']['OutdoorLiving']['name'] = "Outdoor Living";
$cfg['Categories']['list']['Amazon.com']['OutdoorLiving']['node'] = "286168";
$cfg['Categories']['list']['Amazon.com']['OutdoorLiving']['nodes']['286168'] = Array(
	'892986'  =>  'Camping',
	'553760'  =>  'Cooking',
	'553824'  =>  'Patio Furniture',
	);
// Amazon.com: Pet Supplies
$cfg['Categories']['list']['Amazon.com']['PetSupplies']['name'] = "Pet Supplies";
$cfg['Categories']['list']['Amazon.com']['PetSupplies']['node'] = "12923371";
$cfg['Categories']['list']['Amazon.com']['PetSupplies']['nodes']['12923371'] = Array(
	'518115011'	=>  'Collars & Leashes',
	'518178011'	=>  'Grooming',
	'518354011'	=>  'Toys',
	);
// Amazon.com: Photo & Camera
$cfg['Categories']['list']['Amazon.com']['Photo']['name'] = "Photo & Camera";
$cfg['Categories']['list']['Amazon.com']['Photo']['node'] = "502394";
$cfg['Categories']['list']['Amazon.com']['Photo']['nodes']['502394'] = Array(
	'493666'	=>  'Brands',
	'172421'	=>  'Camcorders',
	'281052'	=>  'Digital Cameras',
	);
// Amazon.com: Shoes
$cfg['Categories']['list']['Amazon.com']['Shoes']['name'] = "Shoes";
$cfg['Categories']['list']['Amazon.com']['Shoes']['node'] = "672124011";
$cfg['Categories']['list']['Amazon.com']['Shoes']['nodes']['672124011'] = Array(
	'679337011'  =>  'Womens',
	'679255011'  =>  'Mens',
	'684538011'  =>  'Accessories',
	);
// Amazon.com: Software
$cfg['Categories']['list']['Amazon.com']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.com']['Software']['node'] = "491286";
$cfg['Categories']['list']['Amazon.com']['Software']['nodes']['491286'] = Array(
	'409488'  =>  'Brands',
	'491286'  =>  'Categories',
	'300228'  =>  'Outlet',
	);
// Amazon.com: Sporting Goods
$cfg['Categories']['list']['Amazon.com']['SportingGoods']['name'] = "Sporting Goods";
$cfg['Categories']['list']['Amazon.com']['SportingGoods']['node'] = "3375301";
$cfg['Categories']['list']['Amazon.com']['SportingGoods']['nodes']['3375301'] = Array(
	'3394801'	=>  'Accessories',
	'3386071'	=>  'Fan Shop',
	'3392741'	=>  'Footwear',
	);
// Amazon.com: Tools & Hardware
$cfg['Categories']['list']['Amazon.com']['Tools']['name'] = "Tools & Hardware";
$cfg['Categories']['list']['Amazon.com']['Tools']['node'] = "468240";
$cfg['Categories']['list']['Amazon.com']['Tools']['nodes']['468240'] = Array(
	'228239'	=>  'Brands',
	'551238'	=>  'Hand Tools',
	'551236'	=>  'Power Tools',
	);
// Amazon.com: Toys
$cfg['Categories']['list']['Amazon.com']['Toys']['name'] = "Toys";
$cfg['Categories']['list']['Amazon.com']['Toys']['node'] = "165795011";
$cfg['Categories']['list']['Amazon.com']['Toys']['nodes']['165795011'] = Array(
	'165794011'		=>  'Age Ranges',
	'165993011'  	=>  'Action Figures',
    '166220011'		=>	'Games',
	);
// Amazon.com: VHS
$cfg['Categories']['list']['Amazon.com']['VHS']['name'] = "VHS";
$cfg['Categories']['list']['Amazon.com']['VHS']['node'] = "2650307011";
$cfg['Categories']['list']['Amazon.com']['VHS']['nodes']['2650307011'] = Array(
	
	);
// Amazon.com: Unbox
$cfg['Categories']['list']['Amazon.com']['UnboxVideo']['name'] = "Video On Demand";
$cfg['Categories']['list']['Amazon.com']['UnboxVideo']['node'] = "2625374011";
$cfg['Categories']['list']['Amazon.com']['UnboxVideo']['nodes']['2625374011'] = Array(
	'2649512011'  	=>  'Movies',
	'2649513011'  	=>  'TV',
	);
// Amazon.com: PC & Video Games
$cfg['Categories']['list']['Amazon.com']['VideoGames']['name'] = "PC & Video Games";
$cfg['Categories']['list']['Amazon.com']['VideoGames']['node'] = "11846801";
$cfg['Categories']['list']['Amazon.com']['VideoGames']['nodes']['11846801'] = Array(
	'229575'   =>  'PC Games',
	'14218901' =>  'Wii',
	'14220161' =>  'Xbox 360',
	'14210751' =>  'PlayStation 3',
	);
// Amazon.com: Watches
$cfg['Categories']['list']['Amazon.com']['Watches']['name'] = "Watches";
$cfg['Categories']['list']['Amazon.com']['Watches']['node'] = "378516011";
$cfg['Categories']['list']['Amazon.com']['Watches']['nodes']['378516011'] = Array(
	'378521011'	=>	'Casual Watches',
	'378523011'	=>	'Dress Watches',
	'378526011'	=>	'Sport Watches',
	);
// Amazon.com: Wireless
$cfg['Categories']['list']['Amazon.com']['Wireless']['name'] = "Wireless";
$cfg['Categories']['list']['Amazon.com']['Wireless']['node'] = "2335753011";
$cfg['Categories']['list']['Amazon.com']['Wireless']['nodes']['2335753011'] = Array(
	'2407747011'	=>	'Phones with Plans',
	'2407748011'	=>	'No-Contract Phones',
	'2407749011'	=>	'Unlocked Phones',
	);
// Amazon.com: Wireless
$cfg['Categories']['list']['Amazon.com']['WirelessAccessories']['name'] = "Wireless Accessories";
$cfg['Categories']['list']['Amazon.com']['WirelessAccessories']['node'] = "2407755011";
$cfg['Categories']['list']['Amazon.com']['WirelessAccessories']['nodes']['2407755011'] = Array(
	'2407760011'	=>	'Cases & Covers',
	'2407761011'	=>	'Chargers',
	'2407775011'	=>	'Headsets',
	);
			  
////////////////////////////
// Categories: Amazon.co.uk
// Amazon.co.uk: Apparel
$cfg['Categories']['list']['Amazon.co.uk']['Apparel']['name'] = "Apparel";
$cfg['Categories']['list']['Amazon.co.uk']['Apparel']['node'] = "83451031";
$cfg['Categories']['list']['Amazon.co.uk']['Apparel']['nodes']['83451031'] = Array(
	'116178031'	=>  'Shirts',
	'116180031'	=>  'Trousers & Jeans',
	'116183031'	=>  'Dresses',
	);
// Amazon.co.uk: Automotive
$cfg['Categories']['list']['Amazon.co.uk']['Automotive']['name'] = "Automotive";
$cfg['Categories']['list']['Amazon.co.uk']['Automotive']['node'] = "248878031";
$cfg['Categories']['list']['Amazon.co.uk']['Automotive']['nodes']['248878031'] = Array(
	'301308031'	=>  'Car Accessories',
	'301311031'	=>  'Motorbike Accessories & Parts',
	'301312031'	=>  'Tools, Maintenance & Care',
	);
// Amazon.co.uk: Baby
$cfg['Categories']['list']['Amazon.co.uk']['Baby']['name'] = "Baby";
$cfg['Categories']['list']['Amazon.co.uk']['Baby']['node'] = "60032031";
$cfg['Categories']['list']['Amazon.co.uk']['Baby']['nodes']['60032031'] = Array(
	'60036031'  =>  'Car Seats & Carriers',
	'60039031'  =>  'Bedding',
	'60038031'  =>  'Furniture',
	);
// Amazon.co.uk: Beauty
$cfg['Categories']['list']['Amazon.co.uk']['Beauty']['name'] = "Beauty";
$cfg['Categories']['list']['Amazon.co.uk']['Beauty']['node'] = "117333031";
$cfg['Categories']['list']['Amazon.co.uk']['Beauty']['nodes']['117333031'] = Array(
	'118423031'  =>  'Cosmetics',
	'118457031'  =>  'Fragrances',
	'118464031'  =>  'Skin Care',
	);
// Amazon.co.uk: Books
$cfg['Categories']['list']['Amazon.co.uk']['Books']['name'] = "Books";
$cfg['Categories']['list']['Amazon.co.uk']['Books']['node'] = "1025612";
$cfg['Categories']['list']['Amazon.co.uk']['Books']['nodes']['1025612'] = Array(
	'68' 		=>	'Business',
	'62' 		=>	'Fiction',
	'65' 		=>	'History',
	);
// Amazon.co.uk: DVD		  
$cfg['Categories']['list']['Amazon.co.uk']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.co.uk']['DVD']['node'] = "573406";
$cfg['Categories']['list']['Amazon.co.uk']['DVD']['nodes']['573406'] = Array(
	'501778'  =>  'Action',
	'501866'  =>  'Comedy',
	'501872'  =>  'Drama',
	);
// Amazon.co.uk: Electronics
$cfg['Categories']['list']['Amazon.co.uk']['Electronics']['name'] = "Electronics";
$cfg['Categories']['list']['Amazon.co.uk']['Electronics']['node'] = "560800";
$cfg['Categories']['list']['Amazon.co.uk']['Electronics']['nodes']['560800'] = Array(
	'389514011' =>  'GPS',
	'560834' 	=>  'Photography',
	'560858'  	=>  'Sound & Vision',
	);
// Amazon.co.uk: Grocery
$cfg['Categories']['list']['Amazon.co.uk']['Grocery']['name'] = "Grocery";
$cfg['Categories']['list']['Amazon.co.uk']['Grocery']['node'] = "344155031";
$cfg['Categories']['list']['Amazon.co.uk']['Grocery']['nodes']['344155031'] = Array(
	'358593031' =>  'Jams, Honey & Spreads',
	'358594031' =>  'Meat, Poultry & Sausages',
	'358605031' =>  'Sweets, Mints & Gum',
	);	
// Amazon.co.uk: Health/Personal Care
$cfg['Categories']['list']['Amazon.co.uk']['HealthPersonalCare']['name'] = "Health";
$cfg['Categories']['list']['Amazon.co.uk']['HealthPersonalCare']['node'] = "66280031";
$cfg['Categories']['list']['Amazon.co.uk']['HealthPersonalCare']['nodes']['66280031'] = Array(
	'66471031'=>  'Beauty',
	'66468031' =>  'Personal Care',
	'66467031'=>  'Health Care',
	);
// Amazon.co.uk: Home/Garden
$cfg['Categories']['list']['Amazon.co.uk']['HomeGarden']['name'] = "Home/Garden";
$cfg['Categories']['list']['Amazon.co.uk']['HomeGarden']['node'] = "3147411";
$cfg['Categories']['list']['Amazon.co.uk']['HomeGarden']['nodes']['3147411'] = Array(
	'79903031'=>  'DIY & Tools',
	'11052671'=>  'Garden & Outdoors',
	'11052681'=>  'Kitchen & Dining',
	);
// Amazon.co.uk: Home Improvement
$cfg['Categories']['list']['Amazon.co.uk']['HomeImprovement']['name'] = "Home Improvement";
$cfg['Categories']['list']['Amazon.co.uk']['HomeImprovement']['node'] = "10709121";
$cfg['Categories']['list']['Amazon.co.uk']['HomeImprovement']['nodes']['10709121'] = Array(
	'14279821'=>  'Artwork',
	'10745681'=>  'Furniture',
	'10709301'=>  'Lighting',
	);
// Amazon.co.uk: Jewellery
$cfg['Categories']['list']['Amazon.co.uk']['Jewelry']['name'] = "Jewellery";
$cfg['Categories']['list']['Amazon.co.uk']['Jewelry']['node'] = "193717031";
$cfg['Categories']['list']['Amazon.co.uk']['Jewelry']['nodes']['193717031'] = Array(
	'197366031'	=>  'Earrings',
	'197378031'	=>  'Neckwear',
	'197392031'	=>  'Rings',
	);
// Amazon.co.uk: KindleStore
$cfg['Categories']['list']['Amazon.co.uk']['KindleStore']['name'] = "Kindle eBooks";
$cfg['Categories']['list']['Amazon.co.uk']['KindleStore']['node'] = "341678031";
$cfg['Categories']['list']['Amazon.co.uk']['KindleStore']['nodes']['341678031'] = Array(
	'341689031'  =>  'Books',
	'341690031'  =>  'Magazines',
	'341691031'  =>  'Newspapers',
	);	
// Amazon.co.uk: Kitchen
$cfg['Categories']['list']['Amazon.co.uk']['Kitchen']['name'] = "Kitchen";
$cfg['Categories']['list']['Amazon.co.uk']['Kitchen']['node'] = "3147411";
$cfg['Categories']['list']['Amazon.co.uk']['Kitchen']['nodes']['3147411'] = Array(
	'10708921' =>  'Bakeware',
	'3147471'  =>  'Cookware',
	'10708551' =>  'Tableware',
	);
// Amazon.co.uk: Lighting
$cfg['Categories']['list']['Amazon.co.uk']['Lighting']['name'] = "Lighting";
$cfg['Categories']['list']['Amazon.co.uk']['Lighting']['node'] = "213078031";
$cfg['Categories']['list']['Amazon.co.uk']['Lighting']['nodes']['213078031'] = Array(
	'10709301'	=>  'Indoor Lighting',
	'10709361'	=>  'Outdoor Lighting',
	'227259031'	=>  'Light Bulbs',
	);			  
// Amazon.co.uk: MP3Downloads
$cfg['Categories']['list']['Amazon.co.uk']['MP3Downloads']['name'] = "MP3 Downloads";
$cfg['Categories']['list']['Amazon.co.uk']['MP3Downloads']['node'] = "77198031";
$cfg['Categories']['list']['Amazon.co.uk']['MP3Downloads']['nodes']['77198031'] = Array(
	'78166031'	=>  'Rock',
	'78132031' 	=>  'Pop',
	'78144031' 	=>  'R&B',
	'78180031' 	=>  'Soundtracks',
	);
// Amazon.co.uk: Music
$cfg['Categories']['list']['Amazon.co.uk']['Music']['name'] = "Music";
$cfg['Categories']['list']['Amazon.co.uk']['Music']['node'] = "520920";
$cfg['Categories']['list']['Amazon.co.uk']['Music']['nodes']['520920'] = Array(
	'231239'	=>  'Rock',
	'694208' 	=>  'Pop',
	'754576' 	=>  'R&B',
	'231249' 	=>  'Soundtracks',
	);
// Amazon.co.uk: Office Products
$cfg['Categories']['list']['Amazon.co.uk']['OfficeProducts']['name'] = "Office Products";
$cfg['Categories']['list']['Amazon.co.uk']['OfficeProducts']['node'] = "192414031";
$cfg['Categories']['list']['Amazon.co.uk']['OfficeProducts']['nodes']['192414031'] = Array(
	'197745031'	=>  'Office Paper Products',
	'197743031'	=>  'Office Supplies', 
	'197748031'	=>  'Pens & Pencils',
	);
// Amazon.co.uk: Outdoor Living
$cfg['Categories']['list']['Amazon.co.uk']['OutdoorLiving']['name'] = "Outdoor Living";
$cfg['Categories']['list']['Amazon.co.uk']['OutdoorLiving']['node'] = "10709021";
$cfg['Categories']['list']['Amazon.co.uk']['OutdoorLiving']['nodes']['10709021'] = Array(
	'11714121'  =>  'Barbecues',
	'11714171'  =>  'Garden Furniture',
	'11714761'  =>  'Tools',
	);
// Amazon.co.uk: Shoes
$cfg['Categories']['list']['Amazon.co.uk']['Shoes']['name'] = "Shoes";
$cfg['Categories']['list']['Amazon.co.uk']['Shoes']['node'] = "362350011";
$cfg['Categories']['list']['Amazon.co.uk']['Shoes']['nodes']['362350011'] = Array(
	'362354011'  =>  'Athletic & Outdoor',
	'362356011'  =>  'Shoes',
	'362355011'  =>  'Boots',
	);
// Amazon.co.uk: Software	  
$cfg['Categories']['list']['Amazon.co.uk']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.co.uk']['Software']['node'] = "1025614";
$cfg['Categories']['list']['Amazon.co.uk']['Software']['nodes']['1025614'] = Array(
	'600014'  =>  'Business',
	'600136'  =>  'Graphics',
	'600236'  =>  'Video',
	);
// Amazon.co.uk: SportingGoods
$cfg['Categories']['list']['Amazon.co.uk']['SportingGoods']['name'] = "Sports & Leisure";
$cfg['Categories']['list']['Amazon.co.uk']['SportingGoods']['node'] = "319530011";
$cfg['Categories']['list']['Amazon.co.uk']['SportingGoods']['nodes']['319530011'] = Array(
	'319535011'  =>  'Fitness',
	'324052011'  =>  'Running',
	'319537011'  =>  'Team Sports',
	);
// Amazon.co.uk: Tools
$cfg['Categories']['list']['Amazon.co.uk']['Tools']['name'] = "Tools";
$cfg['Categories']['list']['Amazon.co.uk']['Tools']['node'] = "84124031";
$cfg['Categories']['list']['Amazon.co.uk']['Tools']['nodes']['84124031'] = Array(
	'114414031'	=>  'Hand Tools',
    '114614031'	=>	'Power Tools',
	'13714471'	=>  'Automotive',
	);
// Amazon.co.uk: Toys
$cfg['Categories']['list']['Amazon.co.uk']['Toys']['name'] = "Toys";
$cfg['Categories']['list']['Amazon.co.uk']['Toys']['node'] = "595314";
$cfg['Categories']['list']['Amazon.co.uk']['Toys']['nodes']['595314'] = Array(
	'595316'  =>  'Action Figures',
	'470432'  =>  'Characters/Brands',
    '595314'  =>	'Toy Types',
	);
// Amazon.co.uk: VHS
$cfg['Categories']['list']['Amazon.co.uk']['VHS']['name'] = "VHS";
$cfg['Categories']['list']['Amazon.co.uk']['VHS']['node'] = "573400";
$cfg['Categories']['list']['Amazon.co.uk']['VHS']['nodes']['573400'] = Array(
	'283921'  =>  'Action',
	'283924'  =>  'Comedy',
	'283925'  =>  'Drama',
	);
// Amazon.co.uk: Video Games  
$cfg['Categories']['list']['Amazon.co.uk']['VideoGames']['name'] = "PC & Video Games";
$cfg['Categories']['list']['Amazon.co.uk']['VideoGames']['node'] = "1025616";
$cfg['Categories']['list']['Amazon.co.uk']['VideoGames']['nodes']['1025616'] = Array(
	'579870'  =>  'PC Games',
	'304916011'=>  'Xbox 360',
	'579906'  =>  'PS2',
	);
// Amazon.co.uk: Watches
$cfg['Categories']['list']['Amazon.co.uk']['Watches']['name'] = "Watches";
$cfg['Categories']['list']['Amazon.co.uk']['Watches']['node'] = "328229011";
$cfg['Categories']['list']['Amazon.co.uk']['Watches']['nodes']['328229011'] = Array(
	'199482031'	=>	'Wristwatches',
	'199483031'	=>	'Luxury Watches',
	'199484031'	=>	'Pocket & Fob Watches',
	);
			  
/////////////////////////		  				
// Categories: Amazon.ca
// Amazon.ca: Books
$cfg['Categories']['list']['Amazon.ca']['Books']['name'] = "Books";
$cfg['Categories']['list']['Amazon.ca']['Books']['node'] = "927726";
$cfg['Categories']['list']['Amazon.ca']['Books']['nodes']['927726'] = Array(
	'935522' 	=>	'Business',
	'927728' 	=>	'History',
	'955190' 	=>	'Romance',
	);
// Amazon.ca: DVD
$cfg['Categories']['list']['Amazon.ca']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.ca']['DVD']['node'] = "952768";
$cfg['Categories']['list']['Amazon.ca']['DVD']['nodes']['952768'] = Array(
	'966110'  =>  'Action',
	'953088'  =>  'Comedy',
	'953102'  =>  'Drama',
	);
// Amazon.ca: Electronics
$cfg['Categories']['list']['Amazon.ca']['Electronics']['name'] = "Electronics";
$cfg['Categories']['list']['Amazon.ca']['Electronics']['node'] = "677211011";
$cfg['Categories']['list']['Amazon.ca']['Electronics']['nodes']['677211011'] = Array(
	'677239011' =>  'Computers & PDAs',
	'677230011' =>  'Camera, Photo & Video',
	'677219011' =>  'MP3 & Media Players',
	);
// Amazon.ca: Kitchen
$cfg['Categories']['list']['Amazon.ca']['Kitchen']['name'] = "Kitchen";
$cfg['Categories']['list']['Amazon.ca']['Kitchen']['node'] = "2224068011";
$cfg['Categories']['list']['Amazon.ca']['Kitchen']['nodes']['2224068011'] = Array(
	'2224078011' =>  'Cookware & Baking',
	'2224122011' =>  'Small Appliances',
	'2224106011' =>  'Kitchen Utensils & Gadgets',
	);
// Amazon.ca: Music
$cfg['Categories']['list']['Amazon.ca']['Music']['name'] = "Music";
$cfg['Categories']['list']['Amazon.ca']['Music']['node'] = "962454";
$cfg['Categories']['list']['Amazon.ca']['Music']['nodes']['962454'] = Array(
	'962490'	=>  'Rock',
	'962486' 	=>  'Pop',
	'1034848' 	=>  'R&B',
	'962498' 	=>  'Soundtracks',
	);
// Amazon.ca: Software
$cfg['Categories']['list']['Amazon.ca']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.ca']['Software']['node'] = "3234171";
$cfg['Categories']['list']['Amazon.ca']['Software']['nodes']['3234171'] = Array(
	'3314471'  =>  'Business',
	'3316381'  =>  'Graphics',
	'3318701'  =>  'Video',
	);
// Amazon.ca: SportingGoods
$cfg['Categories']['list']['Amazon.ca']['SportingGoods']['name'] = "Sports & Outdoors";
$cfg['Categories']['list']['Amazon.ca']['SportingGoods']['node'] = "2242990011";
$cfg['Categories']['list']['Amazon.ca']['SportingGoods']['nodes']['2242990011'] = Array(
	'2406106011'  =>  'Cycling',
	'2406117011'  =>  'Golf',
	'2406136011'  =>  'Skiing',
	);	
// Amazon.ca: VHS
$cfg['Categories']['list']['Amazon.ca']['VHS']['name'] = "VHS";
$cfg['Categories']['list']['Amazon.ca']['VHS']['node'] = "962072";
$cfg['Categories']['list']['Amazon.ca']['VHS']['nodes']['962072'] = Array(
	'972682'  =>  'Action',
	'962128'  =>  'Comedy',
	'962130'  =>  'Drama',
	);
// Amazon.ca: PC & Video Games
$cfg['Categories']['list']['Amazon.ca']['VideoGames']['name'] = "PC & Video Games";
$cfg['Categories']['list']['Amazon.ca']['VideoGames']['node'] = "3234221";
$cfg['Categories']['list']['Amazon.ca']['VideoGames']['nodes']['3234221'] = Array(
	'3322951' =>  'PlayStation2',
	'3321791' =>  'PC Games',
	'3323581' =>  'Xbox',
	);

/////////////////////////
// Categories: Amazon.de
// Amazon.de: Automotive
$cfg['Categories']['list']['Amazon.de']['Automotive']['name'] = "Auto & Motorrad";
$cfg['Categories']['list']['Amazon.de']['Automotive']['node'] = "79899031";
$cfg['Categories']['list']['Amazon.de']['Automotive']['nodes']['79899031'] = Array(
	'1071738'    =>  'Car-Hifi',
	'82943031'   =>  'Hersteller-Accessoires',
	'236861011'  =>  'Navigation',
	);
// Amazon.de: Baby
$cfg['Categories']['list']['Amazon.de']['Baby']['name'] = "Baby";
$cfg['Categories']['list']['Amazon.de']['Baby']['node'] = "357577011";
$cfg['Categories']['list']['Amazon.de']['Baby']['nodes']['357577011'] = Array(
	'357584011'  =>  'Kinderwagen & Radanhänger',
	'357580011'  =>  'Babymöbel',
	'357578011'  =>  'Autositze & Babyschalen',
	);
// Amazon.de: Books
$cfg['Categories']['list']['Amazon.de']['Books']['name'] = "Bücher";
$cfg['Categories']['list']['Amazon.de']['Books']['node'] = "541686";
$cfg['Categories']['list']['Amazon.de']['Books']['nodes']['541686'] = Array(
	'403434' 	=>	'Business',
	'122'		=>	'Kochen',
	'124' 		=>	'Computer',
	);
// Amazon.de: Apparel
$cfg['Categories']['list']['Amazon.de']['Apparel']['name'] = "Bekleidung";
$cfg['Categories']['list']['Amazon.de']['Apparel']['node'] = "78689031";
$cfg['Categories']['list']['Amazon.de']['Apparel']['nodes']['78689031'] = Array(
	'78691031'	=>  'Shirts',
	'78704031'	=>  'Jeanshosen',
	'78740031'	=>  'Jacken',
	);
// Amazon.de: Lighting
$cfg['Categories']['list']['Amazon.de']['Lighting']['name'] = "Beleuchtung";
$cfg['Categories']['list']['Amazon.de']['Lighting']['node'] = "213084031";
$cfg['Categories']['list']['Amazon.de']['Lighting']['nodes']['213084031'] = Array(
	'3780981'	=>  'Innenbeleuchtung',
	'227261031'	=>  'Leuchtmittel',
	'227262031'	=>  'Taschenlampen',
	);	
// Amazon.de: OfficeProducts
$cfg['Categories']['list']['Amazon.de']['OfficeProducts']['name'] = "Bürobedarf";
$cfg['Categories']['list']['Amazon.de']['OfficeProducts']['node'] = "192417031";
$cfg['Categories']['list']['Amazon.de']['OfficeProducts']['nodes']['192417031'] = Array(
	'197751031'	=>  'Büromaterial',
	'197753031'	=>  'Papierprodukte',
	'197756031'	=>  'Schreibwaren',
	);
// Amazon.de: PC Hardware
$cfg['Categories']['list']['Amazon.de']['PCHardware']['name'] = "Computer";
$cfg['Categories']['list']['Amazon.de']['PCHardware']['node'] = "368179031";
$cfg['Categories']['list']['Amazon.de']['PCHardware']['nodes']['368179031'] = Array(
	'427954031'	=>  'Desktop-PCs',
	'427957031'	=>  'Notebooks',
	'429868031'	=>  'Monitore',
	);
// Amazon.de: DVD
$cfg['Categories']['list']['Amazon.de']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.de']['DVD']['node'] = "547664";
$cfg['Categories']['list']['Amazon.de']['DVD']['nodes']['547664'] = Array(
	'289093'  =>  'Action, Thriller & Horror',
	'290505'  =>  'Kinder & Familie',
	'290800'  =>  'Komödie & Drama',
	);
// Amazon.de: Electronics	  
$cfg['Categories']['list']['Amazon.de']['Electronics']['name'] = "Elektronik";
$cfg['Categories']['list']['Amazon.de']['Electronics']['node'] = "569604";
$cfg['Categories']['list']['Amazon.de']['Electronics']['nodes']['569604'] = Array(
	'700962'  =>  'Computer & Zubehör',
	'761254' 	=>  'Heimkino & Video',
	'571760'  =>  'Hifi & Audio',
	);
// Amazon.de: ForeignBooks
$cfg['Categories']['list']['Amazon.de']['ForeignBooks']['name'] = "English Books";
$cfg['Categories']['list']['Amazon.de']['ForeignBooks']['node'] = "54071011";
$cfg['Categories']['list']['Amazon.de']['ForeignBooks']['nodes']['54071011'] = Array(
	'58173011'  =>  'Business',
	'64085011'  =>  'Cooking',
	'62991011'  =>  'Computers',
	);
// Amazon.de: Video Games
$cfg['Categories']['list']['Amazon.de']['VideoGames']['name'] = "Games";
$cfg['Categories']['list']['Amazon.de']['VideoGames']['node'] = "541708";
$cfg['Categories']['list']['Amazon.de']['VideoGames']['nodes']['541708'] = Array(
	'301129' 	=>	'Computerspiele',
	'575708'  =>  'Xbox',
	'516838'  =>  'PlayStation 2',
	);
// Amazon.de: Health/Personal Care
$cfg['Categories']['list']['Amazon.de']['HealthPersonalCare']['name'] = "Gesundheit";
$cfg['Categories']['list']['Amazon.de']['HealthPersonalCare']['node'] = "64263031";
$cfg['Categories']['list']['Amazon.de']['HealthPersonalCare']['nodes']['64263031'] = Array(
	'64265031' =>  'Badausstattung',
	'64271031' =>  'Kosmetik',
	'64276031' =>  'Personenwaagen',
	);
// Amazon.de: Home/Garden
$cfg['Categories']['list']['Amazon.de']['HomeGarden']['name'] = "Haus/Garten";
$cfg['Categories']['list']['Amazon.de']['HomeGarden']['node'] = "10925241";
$cfg['Categories']['list']['Amazon.de']['HomeGarden']['nodes']['10925241'] = Array(
	'11047531' =>  'Gartendeko',
	'11048731' =>  'Grillen',
	'11048331' =>  'Rund um Tiere',
	);
// Amazon.de: Tools
$cfg['Categories']['list']['Amazon.de']['Tools']['name'] = "Heimwerken";
$cfg['Categories']['list']['Amazon.de']['Tools']['node'] = "10925051";
$cfg['Categories']['list']['Amazon.de']['Tools']['nodes']['10925051'] = Array(
	'10961041' =>  'Eisenwaren',
	'10961081' =>  'Elektrowerkzeug',
	'10961661' =>  'Handwerkzeug',
	);
// Amazon.de: Photo & Camera
$cfg['Categories']['list']['Amazon.de']['Photo']['name'] = "Kamera/Foto";
$cfg['Categories']['list']['Amazon.de']['Photo']['node'] = "571860";
$cfg['Categories']['list']['Amazon.de']['Photo']['nodes']['571860'] = Array(
	'273647011'	=>  'Camcorder',
	'901968'	=>  'Diaprojektoren',
	'1115610'	=>  'Ferngläser',
	);
// Amazon.de: KindleStore
$cfg['Categories']['list']['Amazon.de']['KindleStore']['name'] = "Kindle eBooks";
$cfg['Categories']['list']['Amazon.de']['KindleStore']['node'] = "530485031";
$cfg['Categories']['list']['Amazon.de']['KindleStore']['nodes']['530485031'] = Array(
	'530886031'  =>  'Kindle eBooks',
	'530887031'  =>  'Kindle Zeitschriften',
	'530888031'  =>  'Kindle Zeitungen',
	);
// Amazon.de: Kitchen
$cfg['Categories']['list']['Amazon.de']['Kitchen']['name'] = "Küche";
$cfg['Categories']['list']['Amazon.de']['Kitchen']['node'] = "3169011";
$cfg['Categories']['list']['Amazon.de']['Kitchen']['nodes']['3169011'] = Array(
	'3169321'  =>  'Elektrische Küchengeräte',
	'3169211'  =>  'Haushaltsgeräte',
	'3312261'  =>  'Wohnen & Lifestyle',
	);
// Amazon.de: Grocery
$cfg['Categories']['list']['Amazon.de']['Grocery']['name'] = "Lebensmittel & Getränke";
$cfg['Categories']['list']['Amazon.de']['Grocery']['node'] = "340847031";
$cfg['Categories']['list']['Amazon.de']['Grocery']['nodes']['340847031'] = Array(
	'358557031'  =>  'Brot & Backwaren',
	'358560031'  =>  'Fleisch, Geflügel & Wurstwaren',
	'358567031'  =>  'Kaffee, Tee & Kakao',
	'358568031'  =>  'Knabberartikel',
	);
// Amazon.de: MP3Downloads
$cfg['Categories']['list']['Amazon.de']['MP3Downloads']['name'] = "MP3-Downloads";
$cfg['Categories']['list']['Amazon.de']['MP3Downloads']['node'] = "180529031";
$cfg['Categories']['list']['Amazon.de']['MP3Downloads']['nodes']['180529031'] = Array(
	'180680031'	 =>  'Pop',
	'180696031'	 =>	 'Rock',
	'180690031'	 =>  'R&B & Soul',
	);
// Amazon.de: Music
$cfg['Categories']['list']['Amazon.de']['Music']['name'] = "Musik";
$cfg['Categories']['list']['Amazon.de']['Music']['node'] = "542676";
$cfg['Categories']['list']['Amazon.de']['Music']['nodes']['542676'] = Array(
	'264875' 	 =>  'Pop',
	'264886'	 =>	 'Rock',
	'255895' 	 =>  'R&B',
	'264918' 	 =>  'Soundtracks',
	);
// Amazon.de: MusicalInstruments
$cfg['Categories']['list']['Amazon.de']['MusicalInstruments']['name'] = "Musikinstrumente";
$cfg['Categories']['list']['Amazon.de']['MusicalInstruments']['node'] = "340850031";
$cfg['Categories']['list']['Amazon.de']['MusicalInstruments']['nodes']['340850031'] = Array(
	'412356031'  =>  'DJ- & VJ-Equipment',
	'412420031'	 =>	 'Gitarren & Equipment',
	'406577031'  =>  'Piano & Keyboard',
	);	
// Amazon.de: Outdoor Living
$cfg['Categories']['list']['Amazon.de']['OutdoorLiving']['name'] = "Outdoor/Freizeit";
$cfg['Categories']['list']['Amazon.de']['OutdoorLiving']['node'] = "11048231";
$cfg['Categories']['list']['Amazon.de']['OutdoorLiving']['nodes']['11048231'] = Array(
	'11048301'  =>  'Camping-Ausrüstung',
	'369346011' =>  'Feuerzeuge',
	'11048261'  =>  'Taschen',
	);
// Amazon.de: Beauty
$cfg['Categories']['list']['Amazon.de']['Beauty']['name'] = "Parfüm/Kosmetik";
$cfg['Categories']['list']['Amazon.de']['Beauty']['node'] = "84231031";
$cfg['Categories']['list']['Amazon.de']['Beauty']['nodes']['84231031'] = Array(
	'122877031'  =>  'Düfte',
	'122880031'  =>  'Make-up',
	'122878031'  =>  'Hautpflege',
	);
// Amazon.de: Shoes
$cfg['Categories']['list']['Amazon.de']['Shoes']['name'] = "Schuhe";
$cfg['Categories']['list']['Amazon.de']['Shoes']['node'] = "355006011";
$cfg['Categories']['list']['Amazon.de']['Shoes']['nodes']['355006011'] = Array(
	'361190011'  =>  'Babyschuhe',
	'361182011'  =>  'Sneaker',
	'361179011'  =>  'Pumps',
	);
// Amazon.de: Jewelry
$cfg['Categories']['list']['Amazon.de']['Jewelry']['name'] = "Schmuck";
$cfg['Categories']['list']['Amazon.de']['Jewelry']['node'] = "327473011";
$cfg['Categories']['list']['Amazon.de']['Jewelry']['nodes']['327473011'] = Array(
	'342098011' =>  'Armbänder & Armreifen',
	'161700031' =>  'Charms',
	'342093011' =>  'Ringe',
	);
// Amazon.de: Software
$cfg['Categories']['list']['Amazon.de']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.de']['Software']['node'] = "542064";
$cfg['Categories']['list']['Amazon.de']['Software']['nodes']['542064'] = Array(
	'12759211' =>  'Antivirensoftware',
	'12761221' =>  'Digitalfotografie',
	'408290'   =>  'Kinder & Familie',
	);
// Amazon.de: Sporting Goods
$cfg['Categories']['list']['Amazon.de']['SportingGoods']['name'] = "Sport/Freizeit";
$cfg['Categories']['list']['Amazon.de']['SportingGoods']['node'] = "16435121";
$cfg['Categories']['list']['Amazon.de']['SportingGoods']['nodes']['16435121'] = Array(
	'16435181' =>  'Fußball',
	'16435171' =>  'Fitness',
	'391713011' =>  'Wintersport',
	);
// Amazon.de: Toys
$cfg['Categories']['list']['Amazon.de']['Toys']['name'] = "Spielwaren";
$cfg['Categories']['list']['Amazon.de']['Toys']['node'] = "12950661";
$cfg['Categories']['list']['Amazon.de']['Toys']['nodes']['12950661'] = Array(
	'12956501' =>  'Spiele',
	'13039241' =>  'Puzzles',
    '13040381' =>	 'Nach Alter',
	);
// Amazon.de: Watches
$cfg['Categories']['list']['Amazon.de']['Watches']['name'] = "Uhren";
$cfg['Categories']['list']['Amazon.de']['Watches']['node'] = "193708031";
$cfg['Categories']['list']['Amazon.de']['Watches']['nodes']['193708031'] = Array(
	'198795031'	=>  'Armbanduhren',
	'198796031'	=>  'Luxusuhren',
	'198797031'	=>  'Taschenuhren',
	);
// Amazon.de: VHS
$cfg['Categories']['list']['Amazon.de']['VHS']['name'] = "Video";
$cfg['Categories']['list']['Amazon.de']['VHS']['node'] = "547082";
$cfg['Categories']['list']['Amazon.de']['VHS']['nodes']['547082'] = Array(
	'284262'  =>  'Action, Thriller & Science Fiction',
	'284264'  =>  'Kinder & Familie',
	'284263'  =>  'Komödie & Drama',
	);
// Amazon.de: Magazines
$cfg['Categories']['list']['Amazon.de']['Magazines']['name'] = "Zeitschriften";
$cfg['Categories']['list']['Amazon.de']['Magazines']['node'] = "1161660";
$cfg['Categories']['list']['Amazon.de']['Magazines']['nodes']['1161660'] = Array(
	'1198626'  =>  'Sport',
	'1198616'  =>  'Computer',
	'1198620'  =>  'Familie',
	);

/////////////////////////    
// Categories: Amazon.fr
// Amazon.fr: Beauty
$cfg['Categories']['list']['Amazon.fr']['Beauty']['name'] = "Beauté & Parfum";
$cfg['Categories']['list']['Amazon.fr']['Beauty']['node'] = "197859031";
$cfg['Categories']['list']['Amazon.fr']['Beauty']['nodes']['197859031'] = Array(
	'210965031' =>	'Parfums',
	'210972031'	=>	'Maquillage',
	'211005031' =>	'Manucure & Pédicure',
	);
// Amazon.fr: Baby
$cfg['Categories']['list']['Amazon.fr']['Baby']['name'] = "Bébés et Puériculture";
$cfg['Categories']['list']['Amazon.fr']['Baby']['node'] = "206618031";
$cfg['Categories']['list']['Amazon.fr']['Baby']['nodes']['206618031'] = Array(
	'214759031' =>	'Vêtements',
	'214797031'	=>	'Eveil',
	'214866031' =>	'Poussettes & Remorques Vélo',
	);
// Amazon.fr: Jewelry
$cfg['Categories']['list']['Amazon.fr']['Jewelry']['name'] = "Bijoux";
$cfg['Categories']['list']['Amazon.fr']['Jewelry']['node'] = "193711031";
$cfg['Categories']['list']['Amazon.fr']['Jewelry']['nodes']['193711031'] = Array(
	'197025031'	=>  'Bijoux de corps',
	'197028031'	=>  'Bracelets',
	'197031031'	=>  'Pendentifs',
	);
// Amazon.fr: Shoes
$cfg['Categories']['list']['Amazon.fr']['Shoes']['name'] = "Chaussures";
$cfg['Categories']['list']['Amazon.fr']['Shoes']['node'] = "248815031";
$cfg['Categories']['list']['Amazon.fr']['Shoes']['nodes']['248815031'] = Array(
	'302497031'	=>	'Femmes',
	'302498031'	=>	'Hommes',
	'302499031'	=>	'Enfants',
	);
// Amazon.fr: Kitchen
$cfg['Categories']['list']['Amazon.fr']['Kitchen']['name'] = "Cuisine & Maison";
$cfg['Categories']['list']['Amazon.fr']['Kitchen']['node'] = "57686031";
$cfg['Categories']['list']['Amazon.fr']['Kitchen']['nodes']['57686031'] = Array(
	'57687031'  =>  'Cuisine',
	'57688031'  =>  'Soin du corps',
	'57690031'  =>  'Jardin',
	);
// Amazon.fr: DVD
$cfg['Categories']['list']['Amazon.fr']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.fr']['DVD']['node'] = "235554011";
$cfg['Categories']['list']['Amazon.fr']['DVD']['nodes']['235554011'] = Array(
	'409394' 	=>	'Action & Aventure',
	'409432'	=>	'Comedie',
	'238397011' 	=>	'Romance',
	);
// Amazon.fr: Lighting
$cfg['Categories']['list']['Amazon.fr']['Lighting']['name'] = "Luminaires et Eclairage";
$cfg['Categories']['list']['Amazon.fr']['Lighting']['node'] = "213081031";
$cfg['Categories']['list']['Amazon.fr']['Lighting']['nodes']['213081031'] = Array(
	'227255031'	=>	'Luminaires Extérieur',
	'68994031' 	=>	'Luminaires Intérieur',
	'227257031'	=>	'Ampoules',
	);	
// Amazon.fr: ForeignBooks
$cfg['Categories']['list']['Amazon.fr']['ForeignBooks']['name'] = "English Books";
$cfg['Categories']['list']['Amazon.fr']['ForeignBooks']['node'] = "69633011";
$cfg['Categories']['list']['Amazon.fr']['ForeignBooks']['nodes']['69633011'] = Array(
	'73735011' 	=>	'Business & Investing',
	'80710011'	=>	'History',
	'84598011' 	=>	'Nonfiction',
	);
// Amazon.fr: OfficeProducts
$cfg['Categories']['list']['Amazon.fr']['OfficeProducts']['name'] = "Fournitures de Bureau";
$cfg['Categories']['list']['Amazon.fr']['OfficeProducts']['node'] = "192420031";
$cfg['Categories']['list']['Amazon.fr']['OfficeProducts']['nodes']['192420031'] = Array(
	'197762031'	=>  'Accessoires électroniques',
	'197759031'	=>	'Petites fournitures',
	'197761031'	=>  'Papeterie',
	);
// Amazon.fr: PCHardware
$cfg['Categories']['list']['Amazon.fr']['PCHardware']['name'] = "Informatique";
$cfg['Categories']['list']['Amazon.fr']['PCHardware']['node'] = "340859031";
$cfg['Categories']['list']['Amazon.fr']['PCHardware']['nodes']['340859031'] = Array(
	'340859031'	=>  'Produits',
	'427942031'	=>  'Accessoires',
	'429876031'	=>  'Claviers, Souris et Tablettes',
	);	
// Amazon.fr: MusicalInstruments
$cfg['Categories']['list']['Amazon.fr']['MusicalInstruments']['name'] = "Instruments de musique";
$cfg['Categories']['list']['Amazon.fr']['MusicalInstruments']['node'] = "340862031";
$cfg['Categories']['list']['Amazon.fr']['MusicalInstruments']['nodes']['340862031'] = Array(
	'406580031'	=>  'Guitares et Equipements',
	'406581031'	=>  'Basses et Equipement',
	'406582031'	=>  'Pianos et Claviers',
	);					  
// Amazon.fr: Toys
$cfg['Categories']['list']['Amazon.fr']['Toys']['name'] = "Jeux et Jouets";
$cfg['Categories']['list']['Amazon.fr']['Toys']['node'] = "322088011";
$cfg['Categories']['list']['Amazon.fr']['Toys']['nodes']['322088011'] = Array(
	'328515011'	=>  'Jeux électroniques',
	'328701011'	=>	'Radio commandes',
	'328233011'	=> 'Figurines',
	);			  
// Amazon.fr: Video Games
$cfg['Categories']['list']['Amazon.fr']['VideoGames']['name'] = "Jeux Vidéo";
$cfg['Categories']['list']['Amazon.fr']['VideoGames']['node'] = "235571011";
$cfg['Categories']['list']['Amazon.fr']['VideoGames']['nodes']['235571011'] = Array(
	'893192' 	=>	'GameCube',
	'548018'	=>	'PlayStation 2',
	'15860651' 	=>	'Xbox 360',
			  );
// Amazon.fr: Electronics	  
$cfg['Categories']['list']['Amazon.fr']['Electronics']['name'] = "L'électronique";
$cfg['Categories']['list']['Amazon.fr']['Electronics']['node'] = "235560011";
$cfg['Categories']['list']['Amazon.fr']['Electronics']['nodes']['235560011'] = Array(
	'13910741' 	=>	'Consommables & Accessoires',
	'13910691'	=>	'Photo & Video',
	'13910711' 	=>	'Telephonie',
	);
// Amazon.fr: Books
$cfg['Categories']['list']['Amazon.fr']['Books']['name'] = "Livres";
$cfg['Categories']['list']['Amazon.fr']['Books']['node'] = "235564011";
$cfg['Categories']['list']['Amazon.fr']['Books']['nodes']['235564011'] = Array(
	'301144' 	=>	'Art, Musique et Cinema',
	'302050'	=>	'Cuisine et Vins',
	'301132' 	=>	'Litterature',
	);
// Amazon.fr: Software
$cfg['Categories']['list']['Amazon.fr']['Software']['name'] = "Logiciels";
$cfg['Categories']['list']['Amazon.fr']['Software']['node'] = "235570011";
$cfg['Categories']['list']['Amazon.fr']['Software']['nodes']['235570011'] = Array(
	'3795781' =>	'Antivirus & Securite',
	'547982'  =>	'Bureautique & Utilitaires',
	'547984'  =>	'Graphisme & Multimedia',
	);
// Amazon.fr: Watches
$cfg['Categories']['list']['Amazon.fr']['Watches']['name'] = "Montres";
$cfg['Categories']['list']['Amazon.fr']['Watches']['node'] = "60937031";
$cfg['Categories']['list']['Amazon.fr']['Watches']['nodes']['60937031'] = Array(
	'62619031'	=>  'Montres bracelet',
	'199638031'	=>  'Montres de Luxe',
	'62620031'	=>  'Accessoires',
	);
// Amazon.fr: Music
$cfg['Categories']['list']['Amazon.fr']['Music']['name'] = "Musique";
$cfg['Categories']['list']['Amazon.fr']['Music']['node'] = "235565011";
$cfg['Categories']['list']['Amazon.fr']['Music']['nodes']['235565011'] = Array(
	'301174' 	=>	'Classique',
	'301166'	=>	'Pop Rock',
	'301168' 	=>	'Techno',
	);
// Amazon.fr: HealthPersonalCare
$cfg['Categories']['list']['Amazon.fr']['HealthPersonalCare']['name'] = "Santé & Corps";
$cfg['Categories']['list']['Amazon.fr']['HealthPersonalCare']['node'] = "197862031";
$cfg['Categories']['list']['Amazon.fr']['HealthPersonalCare']['nodes']['197862031'] = Array(
	'212036031' =>	'Nutrition & Diététique',
	'211040031'	=>	'Hygiène, Soins & Bien-être',
	'212189031' =>	'Premiers soins & Equipements médicaux',
	);
// Amazon.fr: SportingGoods
$cfg['Categories']['list']['Amazon.fr']['SportingGoods']['name'] = "Sports et Loisirs";
$cfg['Categories']['list']['Amazon.fr']['SportingGoods']['node'] = "325615031";
$cfg['Categories']['list']['Amazon.fr']['SportingGoods']['nodes']['325615031'] = Array(
	'339892031' =>	'Football',
	'340091031'	=>	'Vêtements de sport',
	'339983031' =>	'Multisport',
	);	
// Amazon.fr: MP3Downloads
$cfg['Categories']['list']['Amazon.fr']['MP3Downloads']['name'] = "Téléchargements MP3";
$cfg['Categories']['list']['Amazon.fr']['MP3Downloads']['node'] = "206442031";
$cfg['Categories']['list']['Amazon.fr']['MP3Downloads']['nodes']['206442031'] = Array(
	'211521031' =>	'Electro',
	'211594031'	=>	'Pop',
	'211610031' =>	'Rock',
	);
// Amazon.fr: Apparel
$cfg['Categories']['list']['Amazon.fr']['Apparel']['name'] = "Vêtements";
$cfg['Categories']['list']['Amazon.fr']['Apparel']['node'] = "340856031";
$cfg['Categories']['list']['Amazon.fr']['Apparel']['nodes']['340856031'] = Array(
	'436559031' =>	'Femme',
	'436560031'	=>	'Homme',
	'436563031'	=>	'Bébé',
	);		  
// Amazon.fr: VHS
$cfg['Categories']['list']['Amazon.fr']['VHS']['name'] = "Vidéo";
$cfg['Categories']['list']['Amazon.fr']['VHS']['node'] = "235555011";
$cfg['Categories']['list']['Amazon.fr']['VHS']['nodes']['235555011'] = Array(
	'301177' 	=>	'Action & Aventure',
	'301180'	=>	'Comedie',
	'301179' 	=>	'Drame',
	);
			  
///////////////////////////  
// Categories: Amazon.co.jp
// Amazon.co.jp: Apparel
$cfg['Categories']['list']['Amazon.co.jp']['Apparel']['name'] = "&#34915;&#26381;";
$cfg['Categories']['list']['Amazon.co.jp']['Apparel']['node'] = "361298011";
$cfg['Categories']['list']['Amazon.co.jp']['Apparel']['nodes']['361298011'] = Array(
	'2133302051'=>	'&#12513;&#12531;&#12474;',
	'2133303051'=>	'&#12524;&#12487;&#12451;&#12540;&#12473;',
	'345991011' =>	'&#12505;&#12499;&#12540;&#26381;',
	);
// Amazon.co.jp: Beauty
$cfg['Categories']['list']['Amazon.co.jp']['Beauty']['name'] = "&#32654;&#12375;&#12373;";
$cfg['Categories']['list']['Amazon.co.jp']['Beauty']['node'] = "202770011";
$cfg['Categories']['list']['Amazon.co.jp']['Beauty']['nodes']['202770011'] = Array(
	'170039011' =>	'&#12501;&#12455;&#12452;&#12473;&#65286;&#12508;&#12487;&#12451;&#12465;&#12450;',
	'169642011'	=>	'&#12496;&#12473;&#12539;&#12465;&#12450;&#29992;&#21697;',
	'169911011' =>	'&#32654;&#12375;&#12373;',
	);
// Amazon.co.jp: Books
$cfg['Categories']['list']['Amazon.co.jp']['Books']['name'] = "&#26360;&#31821;";
$cfg['Categories']['list']['Amazon.co.jp']['Books']['node'] = "202188011";
$cfg['Categories']['list']['Amazon.co.jp']['Books']['nodes']['202188011'] = Array(
	'466284' 	=>	'&#25991;&#23398;&#12539;&#35413;&#35542;',
	'3148931'	=>	'&#28459;&#30011;&#12539;&#12450;&#12491;&#12513;&#12539;BL',
	'466280' 	=>	'&#25945;&#32946;&#12539;&#23398;&#21442;&#12539;&#21463;&#39443;',
	);
// Amazon.co.jp: DVD
$cfg['Categories']['list']['Amazon.co.jp']['DVD']['name'] = "DVD&#12522;&#12540;";
$cfg['Categories']['list']['Amazon.co.jp']['DVD']['node'] = "202766011";
$cfg['Categories']['list']['Amazon.co.jp']['DVD']['nodes']['202766011'] = Array(
	'562016' 	=>	'&#22806;&#22269;&#26144;&#30011;',
	'562014'	=>	'&#26085;&#26412;&#26144;&#30011;',
	'562020' 	=>	'&#12450;&#12491;&#12513;',
	);	
// Amazon.co.jp: Electronics
$cfg['Categories']['list']['Amazon.co.jp']['Electronics']['name'] = "&#12456;&#12524;&#12463;&#12488;&#12525;&#12491;&#12463;&#12473;";
$cfg['Categories']['list']['Amazon.co.jp']['Electronics']['node'] = "202762011";
$cfg['Categories']['list']['Amazon.co.jp']['Electronics']['nodes']['202762011'] = Array(
	'16462091' 	=>	'&#12459;&#12513;&#12521;&#12539;&#12487;&#12472;&#12479;&#12523;&#12459;&#12513;&#12521;',
	'3371401'	=>	'&#38651;&#23376;&#36766;&#26360;&#12539;PDA',
	'16462081' 	=>	'&#12458;&#12540;&#12487;&#12451;&#12458;',
	);
// Amazon.co.jp: Grocery
$cfg['Categories']['list']['Amazon.co.jp']['Grocery']['name'] = "&#39135;&#26009;&#21697;";
$cfg['Categories']['list']['Amazon.co.jp']['Grocery']['node'] = "57240051";
$cfg['Categories']['list']['Amazon.co.jp']['Grocery']['nodes']['57240051'] = Array(
	'70903051' 	=>	'&#39135;&#21697;',
	'71442051'	=>	'&#12489;&#12522;&#12531;&#12463;',
	'71588051'	=>	'&#12362;&#37202;',
	'71700051' 	=>	'&#39135;&#21697;&#12462;&#12501;&#12488;&#12473;&#12488;&#12450;',
	);	
// Amazon.co.jp: HealthPersonalCare
$cfg['Categories']['list']['Amazon.co.jp']['HealthPersonalCare']['name'] = "&#20581;&#24247;";
$cfg['Categories']['list']['Amazon.co.jp']['HealthPersonalCare']['node'] = "202770011";
$cfg['Categories']['list']['Amazon.co.jp']['HealthPersonalCare']['nodes']['202770011'] = Array(
	'170039011' =>	'&#12501;&#12455;&#12452;&#12473;&#65286;&#12508;&#12487;&#12451;&#12465;&#12450;',
	'169976011'	=>	'&#12480;&#12452;&#12456;&#12483;&#12488;',
	'169911011' =>	'&#12504;&#12523;&#12473;&#12465;&#12450;',
	);			
// Amazon.co.jp: HomeImprovement
$cfg['Categories']['list']['Amazon.co.jp']['HomeImprovement']['name'] = "&#12507;&#12540;&#12512;&#25913;&#21892;";
$cfg['Categories']['list']['Amazon.co.jp']['HomeImprovement']['node'] = "202761011";
$cfg['Categories']['list']['Amazon.co.jp']['HomeImprovement']['nodes']['202761011'] = Array(
	'13938481' 	=>	'&#12461;&#12483;&#12481;&#12531;&#65286;&#12486;&#12540;&#12502;&#12523;&#12454;&#12455;&#12450;',
	'13938531'	=>	'&#12452;&#12531;&#12486;&#12522;&#12450;&#12539;&#21454;&#32013;&#12539;&#23517;&#20855;',
	'13945231' 	=>	'&#12460;&#12540;&#12487;&#12531;',
	);	
// Amazon.co.jp: Jewelry
$cfg['Categories']['list']['Amazon.co.jp']['Jewelry']['name'] = "&#29577;&#39166;&#12426;";
$cfg['Categories']['list']['Amazon.co.jp']['Jewelry']['node'] = "86422051";
$cfg['Categories']['list']['Amazon.co.jp']['Jewelry']['nodes']['86422051'] = Array(
	'86228051' 	=>	'&#12493;&#12483;&#12463;&#12524;&#12473;&#65286;&#12506;&#12531;&#12480;&#12531;&#12488;',
	'86233051'	=>	'&#12522;&#12531;&#12464;',
	'86246051' 	=>	'&#12513;&#12531;&#12474;&#12450;&#12463;&#12475;&#12469;&#12522;&#12540;',
	);	
// Amazon.co.jp: Kitchen
$cfg['Categories']['list']['Amazon.co.jp']['Kitchen']['name'] = "&#21488;&#25152;";
$cfg['Categories']['list']['Amazon.co.jp']['Kitchen']['node'] = "202761011";
$cfg['Categories']['list']['Amazon.co.jp']['Kitchen']['nodes']['202761011'] = Array(
	'13938481' 	=>	'&#12461;&#12483;&#12481;&#12531;&#65286;&#12486;&#12540;&#12502;&#12523;&#12454;&#12455;&#12450;',
	'13938531'	=>	'&#12452;&#12531;&#12486;&#12522;&#12450;&#12539;&#21454;&#32013;&#12539;&#23517;&#20855;',
	'124048011' =>	'&#29983;&#27963;&#23478;&#38651;',
	);
// Amazon.co.jp: MP3Downloads
$cfg['Categories']['list']['Amazon.co.jp']['MP3Downloads']['name'] = "MP3&#12480;&#12454;&#12531;&#12525;&#12540;&#12489;";
$cfg['Categories']['list']['Amazon.co.jp']['MP3Downloads']['node'] = "2129334051";
$cfg['Categories']['list']['Amazon.co.jp']['MP3Downloads']['nodes']['2129334051'] = Array(
	'2129337051' 	=>	'&#12450;&#12523;&#12496;&#12512;',
	'2129338051' 	=>	'&#26354;',
	);	
// Amazon.co.jp: Music
$cfg['Categories']['list']['Amazon.co.jp']['Music']['name'] = "&#38899;&#27005;";
$cfg['Categories']['list']['Amazon.co.jp']['Music']['node'] = "202765011";
$cfg['Categories']['list']['Amazon.co.jp']['Music']['nodes']['202765011'] = Array(
	'569170' 	=>	'J-POP',
	'569290'	=>	'&#12509;&#12483;&#12503;&#12473;',
	'569318' 	=>	'&#12477;&#12454;&#12523;&#12539;R&B',
	'569292' 	=>	'&#12525;&#12483;&#12463;',
	);
// Amazon.co.jp: OfficeProducts
$cfg['Categories']['list']['Amazon.co.jp']['OfficeProducts']['name'] = "Office&#35069;&#21697;";
$cfg['Categories']['list']['Amazon.co.jp']['OfficeProducts']['node'] = "89680051";
$cfg['Categories']['list']['Amazon.co.jp']['OfficeProducts']['nodes']['89680051'] = Array(
	'89085051' 	=>	'&#12494;&#12540;&#12488;&#12539;&#32025;&#35069;&#21697;',
	'89083051'	=>	'&#20107;&#21209;&#29992;&#21697;',
	'89088051' 	=>	'&#31558;&#35352;&#20855;',
	);
// Amazon.co.jp: Shoes
$cfg['Categories']['list']['Amazon.co.jp']['Shoes']['name'] = "&#38772;";
$cfg['Categories']['list']['Amazon.co.jp']['Shoes']['node'] = "2016927051";
$cfg['Categories']['list']['Amazon.co.jp']['Shoes']['nodes']['2016927051'] = Array(
	'2221079051'=>	'&#12513;&#12531;&#12474;',
	'2221080051'=>	'&#12524;&#12487;&#12451;&#12540;&#12473;',
	'2226307051'=>	'&#12461;&#12483;&#12474;&#12539;&#12505;&#12499;&#12540;',
	);
// Amazon.co.jp: Software
$cfg['Categories']['list']['Amazon.co.jp']['Software']['name'] = "&#12477;&#12501;&#12488;";
$cfg['Categories']['list']['Amazon.co.jp']['Software']['node'] = "202764011";
$cfg['Categories']['list']['Amazon.co.jp']['Software']['nodes']['202764011'] = Array(
	'1040116' 	=>	'&#12454;&#12452;&#12523;&#12473;&#23550;&#31574;&#12539;&#12475;&#12461;&#12517;&#12522;&#12486;&#12451;',
	'637644'	=>	'&#12499;&#12472;&#12493;&#12473;&#12539;&#12458;&#12501;&#12451;&#12473;',
	'637652' 	=>	'&#12487;&#12470;&#12452;&#12531;&#12539;&#12464;&#12521;&#12501;&#12451;&#12483;&#12463;',
	);
// Amazon.co.jp: SportingGoods
$cfg['Categories']['list']['Amazon.co.jp']['SportingGoods']['name'] = "&#12473;&#12509;&#12540;&#12484;&#29992;&#21697;";
$cfg['Categories']['list']['Amazon.co.jp']['SportingGoods']['node'] = "202769011";
$cfg['Categories']['list']['Amazon.co.jp']['SportingGoods']['nodes']['202769011'] = Array(
	'14315501' 	=>	'&#12501;&#12451;&#12483;&#12488;&#12493;&#12473;&#12539;&#12488;&#12524;&#12540;&#12491;&#12531;&#12464;',
	'14315411'	=>	'&#12450;&#12454;&#12488;&#12489;&#12450;',
	'14315441' 	=>	'&#12468;&#12523;&#12501;',
	);
// Amazon.co.jp: Toys
$cfg['Categories']['list']['Amazon.co.jp']['Toys']['name'] = "&#29609;&#20855;";
$cfg['Categories']['list']['Amazon.co.jp']['Toys']['node'] = "202768011";
$cfg['Categories']['list']['Amazon.co.jp']['Toys']['nodes']['202768011'] = Array(
	'13321861' 	=>	'&#12507;&#12499;&#12540;',
	'13321751'	=>	'&#12501;&#12449;&#12483;&#12471;&#12519;&#12531;&#12539;&#12450;&#12463;&#12475;&#12469;&#12522;',
	'13321741' 	=>	'&#12396;&#12356;&#12368;&#12427;&#12415;',
	);
// Amazon.co.jp: VHS
$cfg['Categories']['list']['Amazon.co.jp']['VHS']['name'] = "VHS&#29256;";
$cfg['Categories']['list']['Amazon.co.jp']['VHS']['node'] = "202767011";
$cfg['Categories']['list']['Amazon.co.jp']['VHS']['nodes']['202767011'] = Array(
	'564546' 	=>	'Import (&#36664;&#20837;&#29256;)',
	'561990'	=>	'&#12450;&#12491;&#12513;',
	'2112001051'=>	'&#12524;&#12540;&#12505;&#12523;&#21029;',
	);
// Amazon.co.jp: VideoGames
$cfg['Categories']['list']['Amazon.co.jp']['VideoGames']['name'] = "&#12499;&#12487;&#12458;&#12466;&#12540;&#12512;";
$cfg['Categories']['list']['Amazon.co.jp']['VideoGames']['node'] = "202763011";
$cfg['Categories']['list']['Amazon.co.jp']['VideoGames']['nodes']['202763011'] = Array(
	'15782591' 	=>	'&#12503;&#12524;&#12452;&#12473;&#12486;&#12540;&#12471;&#12519;&#12531;3',
	'15783231' 	=>	'Xbox 360',
	'193662011'	=>	'Wii',
	'1192242' 	=>	'PC&#12466;&#12540;&#12512;',
	);
// Amazon.co.jp: Watches
$cfg['Categories']['list']['Amazon.co.jp']['Watches']['name'] = "&#26178;&#35336;";
$cfg['Categories']['list']['Amazon.co.jp']['Watches']['node'] = "333336011";
$cfg['Categories']['list']['Amazon.co.jp']['Watches']['nodes']['333336011'] = Array(
	'333010011' =>	'&#12524;&#12487;&#12451;&#12540;&#12473; &#33109;&#26178;&#35336;',
	'333009011'	=>	'&#12513;&#12531;&#12474; &#33109;&#26178;&#35336;',
	'2016222051'=>	'&#12461;&#12483;&#12474;&#33109;&#26178;&#35336;',
	);

/////////////////////////    
// Categories: Amazon.it

// Amazon.it: Kitchen
$cfg['Categories']['list']['Amazon.it']['Kitchen']['name'] = "Casa e cucina";
$cfg['Categories']['list']['Amazon.it']['Kitchen']['node'] = "524016031";
$cfg['Categories']['list']['Amazon.it']['Kitchen']['nodes']['524016031'] = Array(
	'731676031'	=>	'Decorazioni per interni',
	'652615031'	=>	'Stoviglie',
	'731677031'	=>	'Tessili per la casa',
	);
// Amazon.it: DVD
$cfg['Categories']['list']['Amazon.it']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.it']['DVD']['node'] = "412607031";
$cfg['Categories']['list']['Amazon.it']['DVD']['nodes']['412607031'] = Array(
	'489064031' =>	'Commedie',
	'489066031'	=>	'Drammatici',
	'435482031'	=>	'Serie TV',
	);
// Amazon.it: Electronics	  
$cfg['Categories']['list']['Amazon.it']['Electronics']['name'] = "Elettronica";
$cfg['Categories']['list']['Amazon.it']['Electronics']['node'] = "412610031";
$cfg['Categories']['list']['Amazon.it']['Electronics']['nodes']['412610031'] = Array(
	'435505031' =>	'Foto e videocamere',
	'473601031'	=>	'Informatica',
	'473238031'	=>	'Telefonia',
	);
// Amazon.it: ForeignBooks
$cfg['Categories']['list']['Amazon.it']['ForeignBooks']['name'] = "English Books";
$cfg['Categories']['list']['Amazon.it']['ForeignBooks']['node'] = "433843031";
$cfg['Categories']['list']['Amazon.it']['ForeignBooks']['nodes']['433843031'] = Array(
	'509265031'	=>	'Humour',
	'509215031'	=>	'Narrativa',
	'509220031'	=>	'Romanzi rosa',
	);
// Amazon.it: Garden
$cfg['Categories']['list']['Amazon.it']['Garden']['name'] = "Giardino";
$cfg['Categories']['list']['Amazon.it']['Garden']['node'] = "635017031";
$cfg['Categories']['list']['Amazon.it']['Garden']['nodes']['635017031'] = Array(
	'731468031' =>	'Arredamento da giardino',
	'731467031'	=>	'Decorazioni per il giardino',
	'731469031' =>	'Utensili per il giardinaggio',
	);
// Amazon.it: Toys
$cfg['Categories']['list']['Amazon.it']['Toys']['name'] = "Giocattoli";
$cfg['Categories']['list']['Amazon.it']['Toys']['node'] = "523998031";
$cfg['Categories']['list']['Amazon.it']['Toys']['nodes']['523998031'] = Array(
	'632667031' =>	'Bambole e accessori',
	'632623031'	=>	'Costruzioni',
	'632649031' =>	'Modellini e veicoli',
	);	
// Amazon.it: Books
$cfg['Categories']['list']['Amazon.it']['Books']['name'] = "Libri";
$cfg['Categories']['list']['Amazon.it']['Books']['node'] = "411664031";
$cfg['Categories']['list']['Amazon.it']['Books']['nodes']['411664031'] = Array(
	'508820031'	=>	'Humour',
	'508770031' =>	'Narrativa',
	'508775031'	=>	'Romanzi rosa',
	);
// Amazon.it: Music
$cfg['Categories']['list']['Amazon.it']['Music']['name'] = "Musica";
$cfg['Categories']['list']['Amazon.it']['Music']['node'] = "412601031";
$cfg['Categories']['list']['Amazon.it']['Music']['nodes']['412601031'] = Array(
	'489722031' =>	'Dance ed Elettronica',
	'489784031'	=>	'Pop',
	'489814031' =>	'Rock',
	);
// Amazon.it: Watches
$cfg['Categories']['list']['Amazon.it']['Watches']['name'] = "Orologi";
$cfg['Categories']['list']['Amazon.it']['Watches']['node'] = "524010031";
$cfg['Categories']['list']['Amazon.it']['Watches']['nodes']['524010031'] = Array(
	'601913031' =>	'Orologi da polso',
	'601912031'	=>	'Orologi da tasca',
	'601911031'	=>	'Orologi di lusso',
	);
// Amazon.it: Shoes
$cfg['Categories']['list']['Amazon.it']['Shoes']['name'] = "Scarpe e borse";
$cfg['Categories']['list']['Amazon.it']['Shoes']['node'] = "524007031";
$cfg['Categories']['list']['Amazon.it']['Shoes']['nodes']['524007031'] = Array(
	'700516031' =>	'Borse',
	'700578031'	=>	'Scarpe',
	'700542031' =>	'Valigeria e accessori viaggio',
	);
// Amazon.it: Software
$cfg['Categories']['list']['Amazon.it']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.it']['Software']['node'] = "412613031";
$cfg['Categories']['list']['Amazon.it']['Software']['nodes']['412613031'] = Array(
	'486461031' =>	'Computer Security & Privacy',
	'486549031'	=>	'Foto, media e design',
	'486541031' =>	'Sistemi operativi',
	);
// Amazon.it: Video Games
$cfg['Categories']['list']['Amazon.it']['VideoGames']['name'] = "Videogiochi";
$cfg['Categories']['list']['Amazon.it']['VideoGames']['node'] = "412604031";
$cfg['Categories']['list']['Amazon.it']['VideoGames']['nodes']['412604031'] = Array(
	'435495031' =>	'Giochi per PC e Mac',
	'435490031'	=>	'PlayStation 3',
	'435492031'	=>	'Wii',
	'435491031'	=>	'Xbox 360',
	);


/////////////////////////    
// Categories: Amazon.cn
	
// Amazon.cn: Apparel
$cfg['Categories']['list']['Amazon.cn']['Apparel']['name'] = "服装";
$cfg['Categories']['list']['Amazon.cn']['Apparel']['node'] = "2016157051";
$cfg['Categories']['list']['Amazon.cn']['Apparel']['nodes']['2016157051'] = Array(
	'2152154051' => '女装',
	'2152155051' => '男装',
	'2152156051' => '女童服装'
	);	
// Amazon.cn: Appliances
$cfg['Categories']['list']['Amazon.cn']['Appliances']['name'] = "家电";
$cfg['Categories']['list']['Amazon.cn']['Appliances']['node'] = "80208071";
$cfg['Categories']['list']['Amazon.cn']['Appliances']['nodes']['80208071'] = Array(
	'81948071' => '冰箱',
	'81949071' => '冰柜',
	'2121147051' => '洗衣机\烘干机'
	);	
// Amazon.cn: Automotive
$cfg['Categories']['list']['Amazon.cn']['Automotive']['name'] = "汽车";
$cfg['Categories']['list']['Amazon.cn']['Automotive']['node'] = "1947900051";
$cfg['Categories']['list']['Amazon.cn']['Automotive']['nodes']['1947900051'] = Array(
	'2127789051' => 'GPS导航\配件',
	'2127790051' => '车载影音',
	'1947902051' => '内部饰品\用品\设备'
	);	
// Amazon.cn: Baby
$cfg['Categories']['list']['Amazon.cn']['Baby']['name'] = "婴儿";
$cfg['Categories']['list']['Amazon.cn']['Baby']['node'] = "42693071";
$cfg['Categories']['list']['Amazon.cn']['Baby']['nodes']['42693071'] = Array(
	'79139071' => '婴幼儿尿裤',
	'79146071' => '婴儿护理',
	'79182071' => '安全防护'
	);	
// Amazon.cn: Beauty
$cfg['Categories']['list']['Amazon.cn']['Beauty']['name'] = "美容";
$cfg['Categories']['list']['Amazon.cn']['Beauty']['node'] = "746777051";
$cfg['Categories']['list']['Amazon.cn']['Beauty']['nodes']['746777051'] = Array(
	'746781051' => '香水\香氛',
	'746782051' => '面部护理',
	'747007051' => '眼部护理'
	);	
// Amazon.cn: Books
$cfg['Categories']['list']['Amazon.cn']['Books']['name'] = "书籍";
$cfg['Categories']['list']['Amazon.cn']['Books']['node'] = "658391051";
$cfg['Categories']['list']['Amazon.cn']['Books']['nodes']['658391051'] = Array(
	'658393051' => '小说',
	'658394051' => '文学',
	'658395051' => '艺术'
	);	
// Amazon.cn: Electronics
$cfg['Categories']['list']['Amazon.cn']['Electronics']['name'] = "电子产品";
$cfg['Categories']['list']['Amazon.cn']['Electronics']['node'] = "2016117051";
$cfg['Categories']['list']['Amazon.cn']['Electronics']['nodes']['2016117051'] = Array(
	'664978051' => '手机／通讯',
	'755653051' => '摄影／摄像',
	'760233051' => '数码影音'
	);	
// Amazon.cn: Grocery
$cfg['Categories']['list']['Amazon.cn']['Grocery']['name'] = "杂货";
$cfg['Categories']['list']['Amazon.cn']['Grocery']['node'] = "2127216051";
$cfg['Categories']['list']['Amazon.cn']['Grocery']['nodes']['2127216051'] = Array(
	'2141094051' => '饮料',
	'2140457051' => '茶',
	'43234071' => '酒'
	);	
// Amazon.cn: Health
$cfg['Categories']['list']['Amazon.cn']['HealthPersonalCare']['name'] = "健康";
$cfg['Categories']['list']['Amazon.cn']['HealthPersonalCare']['node'] = "852804051";
$cfg['Categories']['list']['Amazon.cn']['HealthPersonalCare']['nodes']['852804051'] = Array(
	'853744051' => '美体塑身',
	'836322051' => '成人用品',
	'2133896051' => '隐形眼镜'
	);	
// Amazon.cn: HomeGarden
$cfg['Categories']['list']['Amazon.cn']['Home']['name'] = "首页";
$cfg['Categories']['list']['Amazon.cn']['Home']['node'] = "2016127051";
$cfg['Categories']['list']['Amazon.cn']['Home']['nodes']['2016127051'] = Array(
	'813108051' => '厨具',
	'814224051' => '小家电',
	'831780051' => '家居'
	);
// Amazon.cn: HomeImprovement
$cfg['Categories']['list']['Amazon.cn']['HomeImprovement']['name'] = "家装";
$cfg['Categories']['list']['Amazon.cn']['HomeImprovement']['node'] = "1952921051";
$cfg['Categories']['list']['Amazon.cn']['HomeImprovement']['nodes']['1952921051'] = Array(
	'1952934051' => '建筑材料',
	'1952925051' => '电气',
	'1952923051' => '五金'
	);	
// Amazon.cn: Jewelry
$cfg['Categories']['list']['Amazon.cn']['Jewelry']['name'] = "珠宝";
$cfg['Categories']['list']['Amazon.cn']['Jewelry']['node'] = "816483051";
$cfg['Categories']['list']['Amazon.cn']['Jewelry']['nodes']['816483051'] = Array(
	'816602051' => '项链\吊坠',
	'816603051' => '戒指',
	'816604051' => '手链\手镯'
	);	
// Amazon.cn: Music
$cfg['Categories']['list']['Amazon.cn']['Music']['name'] = "音乐";
$cfg['Categories']['list']['Amazon.cn']['Music']['node'] = "754387051";
$cfg['Categories']['list']['Amazon.cn']['Music']['nodes']['754387051'] = Array(
	'754389051' => '流行音乐',
	'754391051' => '古典',
	'754393051' => '休闲音乐'
	);	
// Amazon.cn: OfficeProducts
$cfg['Categories']['list']['Amazon.cn']['OfficeProducts']['name'] = "办公用品";
$cfg['Categories']['list']['Amazon.cn']['OfficeProducts']['node'] = "2127222051";
$cfg['Categories']['list']['Amazon.cn']['OfficeProducts']['nodes']['2127222051'] = Array(
	'2142103051' => '办公设备',
	'2142225051' => '日常办公用品',
	'2142127051' => '办公耗材'
	);
// Amazon.cn: Photography
$cfg['Categories']['list']['Amazon.cn']['Photo']['name'] = "摄影";
$cfg['Categories']['list']['Amazon.cn']['Photo']['node'] = "755653051";
$cfg['Categories']['list']['Amazon.cn']['Photo']['nodes']['755653051'] = Array(
	'755654051' => '数码照相机',
	'755655051' => '配件\镜头\周边',
	'755657051' => '数码摄像机'
	);	
// Amazon.cn: Shoes
$cfg['Categories']['list']['Amazon.cn']['Shoes']['name'] = "鞋";
$cfg['Categories']['list']['Amazon.cn']['Shoes']['node'] = "2029190051";
$cfg['Categories']['list']['Amazon.cn']['Shoes']['nodes']['2029190051'] = Array(
	'2112003051' => '女鞋',
	'2112046051' => '男鞋',
	'2112084051' => '童鞋'
	);	
// Amazon.cn: Software
$cfg['Categories']['list']['Amazon.cn']['Software']['name'] = "软件";
$cfg['Categories']['list']['Amazon.cn']['Software']['node'] = "863873051";
$cfg['Categories']['list']['Amazon.cn']['Software']['nodes']['863873051'] = Array(
	'2157035051' => '计算机安全',
	'863912051' => '操作系统',
	'863913051' => '办公软件'
	);	
// Amazon.cn: SportingGoods
$cfg['Categories']['list']['Amazon.cn']['SportingGoods']['name'] = "体育用品";
$cfg['Categories']['list']['Amazon.cn']['SportingGoods']['node'] = "836313051";
$cfg['Categories']['list']['Amazon.cn']['SportingGoods']['nodes']['836313051'] = Array(
	'836334051' => '乒乓球',
	'836330051' => '羽毛球',
	'836333051' => '网球'
	);	
// Amazon.cn: Toys
$cfg['Categories']['list']['Amazon.cn']['Toys']['name'] = "玩具";
$cfg['Categories']['list']['Amazon.cn']['Toys']['node'] = "647071051";
$cfg['Categories']['list']['Amazon.cn']['Toys']['nodes']['647071051'] = Array(
	'1982054051' => '婴幼玩具',
	'2039913051' => '儿童家具',
	'1982057051' => '电动玩具'
	);	
// Amazon.cn: Video
$cfg['Categories']['list']['Amazon.cn']['Video']['name'] = "视频";
$cfg['Categories']['list']['Amazon.cn']['Video']['node'] = "2016137051";
$cfg['Categories']['list']['Amazon.cn']['Video']['nodes']['2016137051'] = Array(
	'811074051' => '影视',
	'897771051' => '教育音像',
	);	
// Amazon.cn: VideoGames
$cfg['Categories']['list']['Amazon.cn']['VideoGames']['name'] = "视频游戏";
$cfg['Categories']['list']['Amazon.cn']['VideoGames']['node'] = "897416051";
$cfg['Categories']['list']['Amazon.cn']['VideoGames']['nodes']['897416051'] = Array(
	'897470051' => '角色扮演游戏',
	'897474051' => '动作_冒险_射击游戏',
	'897473051' => '策略游戏'
	);	
// Amazon.cn: Watches
$cfg['Categories']['list']['Amazon.cn']['Watches']['name'] = "手表";
$cfg['Categories']['list']['Amazon.cn']['Watches']['node'] = "1953165051";
$cfg['Categories']['list']['Amazon.cn']['Watches']['nodes']['1953165051'] = Array(
	'2040033051' => '腕表',
	'816492051' => '钟',
	'1982068051' => '儿童钟表'
	);	


/////////////////////////    
// Categories: Amazon.es
	
// Amazon.es: Books
$cfg['Categories']['list']['Amazon.es']['Books']['name'] = "Libros";
$cfg['Categories']['list']['Amazon.es']['Books']['node'] = "599365031";
$cfg['Categories']['list']['Amazon.es']['Books']['nodes']['599365031'] = Array(
	'902600031' => 'Historia',
	'902674031' => 'Literatura y ficción',
	'902702031' => 'Religión'
	);	
// Amazon.es: DVD
$cfg['Categories']['list']['Amazon.es']['DVD']['name'] = "DVD";
$cfg['Categories']['list']['Amazon.es']['DVD']['node'] = "599380031";
$cfg['Categories']['list']['Amazon.es']['DVD']['nodes']['599380031'] = Array(
	'916701031' => 'Películas',
	'665293031' => 'TV'
	);	
// Amazon.es: Electronics
$cfg['Categories']['list']['Amazon.es']['Electronics']['name'] = "Electrónica";
$cfg['Categories']['list']['Amazon.es']['Electronics']['node'] = "667050031";
$cfg['Categories']['list']['Amazon.es']['Electronics']['nodes']['667050031'] = Array(
	'937753031' => 'Accesorios',
	'937912031' => 'Componentes',
	'938008031' => 'Portátiles'
	);	
// Amazon.es: ForeignBooks
$cfg['Categories']['list']['Amazon.es']['ForeignBooks']['name'] = "Libros extranjeros";
$cfg['Categories']['list']['Amazon.es']['ForeignBooks']['node'] = "599368031";
$cfg['Categories']['list']['Amazon.es']['ForeignBooks']['nodes']['599368031'] = Array(
	'903393031' => 'Historia',
	'903467031' => 'Literatura y ficción',
	'903495031' => 'Religión'
	);
// Amazon.es: Kitchen
$cfg['Categories']['list']['Amazon.es']['Kitchen']['name'] = "Cocina";
$cfg['Categories']['list']['Amazon.es']['Kitchen']['node'] = "599392031";
$cfg['Categories']['list']['Amazon.es']['Kitchen']['nodes']['599392031'] = Array(
	'675728031' => 'Pequeño Electrodoméstico'
	);	
// Amazon.es: Music
$cfg['Categories']['list']['Amazon.es']['Music']['name'] = "Música";
$cfg['Categories']['list']['Amazon.es']['Music']['node'] = "599374031";
$cfg['Categories']['list']['Amazon.es']['Music']['nodes']['599374031'] = Array(
	'917395031' => 'Flamenco y folclore español',
	'917456031' => 'Pop',
	'917489031' => 'Rock'
	);
// Amazon.es: Software
$cfg['Categories']['list']['Amazon.es']['Software']['name'] = "Software";
$cfg['Categories']['list']['Amazon.es']['Software']['node'] = "599377031";
$cfg['Categories']['list']['Amazon.es']['Software']['nodes']['599377031'] = Array(
	'665284031' => 'Foto, multimedia y diseño',
	'912845031' => 'Programación y desarrollo web',
	'665497031' => 'Sistemas operativos'
	);		
// Amazon.es: Toys
$cfg['Categories']['list']['Amazon.es']['Toys']['name'] = "Juguetes";
$cfg['Categories']['list']['Amazon.es']['Toys']['node'] = "599386031";
$cfg['Categories']['list']['Amazon.es']['Toys']['nodes']['599386031'] = Array(
	'943800031' => 'Juguetes'
	);	
// Amazon.es: VideoGames
$cfg['Categories']['list']['Amazon.es']['VideoGames']['name'] = "Juegos video";
$cfg['Categories']['list']['Amazon.es']['VideoGames']['node'] = "599383031";
$cfg['Categories']['list']['Amazon.es']['VideoGames']['nodes']['599383031'] = Array(
	'664652031' => 'PlayStation 3',
	'664654031' => 'Wii',
	'664653031' => 'Xbox 360'
	);	
// Amazon.es: Watches
$cfg['Categories']['list']['Amazon.es']['Watches']['name'] = "Relojes";
$cfg['Categories']['list']['Amazon.es']['Watches']['node'] = "599389031";
$cfg['Categories']['list']['Amazon.es']['Watches']['nodes']['599389031'] = Array(
	'951037031' => 'Relojes',
	);	
	
	
// CategoryBox
$cfg['CategoryBox']['section'] = "4";
$cfg['CategoryBox']['type'] = "box";
$cfg['CategoryBox']['display']['list'] = Array('Yes', 'No');
$cfg['CategoryBox']['display']['default'] = "Yes";
$cfg['CategoryBox']['location']['list'] = Array('L', 'R');
$cfg['CategoryBox']['location']['default'] = "L";
$cfg['CategoryBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'C' => 'Cart', 'CP' => 'Custom Pages', 'SA' => 'Search All');
$cfg['CategoryBox']['order']['default'] = "";
$cfg['CategoryBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['CategoryBox']['bordersize']['default'] = "1";
$cfg['CategoryBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['CategoryBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['CategoryBox']['label'] = "Categories";
$cfg['CategoryBox']['help'] = "Browsable list of categories you configured above. To not display this box set Display equal to No. For Location: L=Left, R=Right";
			  
// CategoryIcons
$cfg['CategoryIcons']['section'] = "4";
$cfg['CategoryIcons']['list'] = Array('Yes', 'No');
$cfg['CategoryIcons']['default'] = "No";
$cfg['CategoryIcons']['type'] = "radio";
$cfg['CategoryIcons']['help'] = "Whether or not to display the small category icons on category pages. The icon files must be named<br>'icon_{Your Category ID}.gif' to appear properly.";

// CategoryDescriptions
$cfg['CategoryDescriptions']['section'] = "4";
$cfg['CategoryDescriptions']['type'] = "descr";
$cfg['CategoryDescriptions']['help'] = "If provided, this description will be displayed at the top of the first page for that Category. <b>Note:</b> Available for all but the URL category type. To delete a description, remove the text/HTML and resave.";

// CategoryPrices
$cfg['CategoryPrices']['section'] = "4";
$cfg['CategoryPrices']['type'] = "prices";
$cfg['CategoryPrices']['help'] = "Optionally define minimum and maximum prices at Category level (e.g. 24.99). No currency signs or commas. Overrides <b>Minimum Price</b> and <b>Maximum Price</b> settings in Merchant section for categories where they are defined. Leave blank to display all prices. <b>Note:</b> Not available for the ASIN List, ASIN File, Blended or URL category types. To delete prices, remove them and resave.";

// CustomPages
$cfg['CustomPages']['section'] = "25";
$cfg['CustomPages']['type'] = "custompages";
$cfg['CustomPages']['order']['default'] = "";
$cfg['CustomPages']['help'] = "<b>INSTRUCTIONS:</b> This is where you setup your own custom pages (e.g. Contact Us, About Us, or anything else). You can link to these pages from inside or outside of your store. They are displayed with your store look and feel. They can contain any content whether it be Raw HTML, RSS Feeds or an external HTML/PHP File. To delete a Custom Page, set Page Type to Delete and resave your settings.<br><br>To link to a page you've created use the following format:<br><b>http://www.yourdomain.com/shop.php?a=[Page ID]</b><br><span style=\"font-size:smaller; font-weight:normal;\">(see the SEO section of our online documentation for mod_rewrite instructions)</span><br><br><b>Page Type:</b><br>Select the Page Type (Raw HTML, HTML/PHP File or RSS Feed)<br><br><b>Page ID:</b><br>Enter a unqiue ID for the page (e.g. books, 123, etc).<br><br><b>Title:</b><br>Enter the Title of the page<br><br><b>Meta Keywords:</b><br>Enter the Meta Keywords for the page<br><br><b>Meta Description:</b><br>Enter the Meta Description for the page<br><br><b>Cache:</b><br>Check/uncheck box to toggle caching of the page (for pages that should change with each load, uncheck this box)<br><br><b>Tab:</b><br>Check/uncheck box if you want this page displayed as a Tab<br><br><b>NoFollow:</b><br>If Page Type is RSS, check this box if you want the RSS links to include the rel='nofollow' directive.<br><br><b>Order:</b><br>When Tab is checked, this will control the order it displays with relation to your regular store Categories<br><br><b>Page Content:</b><br>If the Page Type you selected was Raw HTML, you would paste the HTML in the Page Content section below. Or for a Page Type of HTML/PHP File, you would enter the server path or URL to the file/script in the Page Content section. <b>Note:</b> File paths are better and will load faster. On some servers you may need to use the URL. If the file is in the same location as your shop file, you might be able to simply enter the file name (e.g. yourfile.html, yourscript.php).<br><br><br>";

// CustomBoxes
$cfg['CustomBoxes']['section'] = "6";
$cfg['CustomBoxes']['type'] = "customboxes";
$cfg['CustomBoxes']['display']['list'] = Array('Yes', 'No', 'DELETE');
$cfg['CustomBoxes']['display']['default'] = "Yes";
$cfg['CustomBoxes']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['CustomBoxes']['bordersize']['default'] = "1";
$cfg['CustomBoxes']['bordercolor']['default'] = "#CCCCCC";
$cfg['CustomBoxes']['bgcolor']['default'] = "#FFFFFF";
$cfg['CustomBoxes']['location']['list'] = Array('L', 'R', 'PT', 'PT2', 'PB', 'PB2', 'BT', 'BB', 'I1', 'I2', 'I3', 'I4', 'I5', 'I6', 'I7', 'C1', 'C2', 'C3');
$cfg['CustomBoxes']['location']['default'] = "L";
$cfg['CustomBoxes']['firstpg']['list'] = Array('1st'=>'');
$cfg['CustomBoxes']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'C' => 'Shopping Cart', 'CP' => 'Custom Pages', 'SA' => 'Search All', '404' => '404 Pages');
$cfg['CustomBoxes']['order']['default'] = "";
$cfg['CustomBoxes']['help'] = "<b>INSTRUCTIONS:</b> This is where you setup content areas for display within your store (we call them boxes). They can contain any content from Raw HTML, to RSS Feeds, to an external HTML/PHP File (e.g. Ad Content, Featured Items, Newsletter Form, etc.). To delete a Custom Box, set Display to Delete and resave your settings.<br><br><b>Admin Label:</b><br>This first dark grey input box is for labeling the box within the admin. It is only visible to you in the admin and won't be seen in your store. <br><br><b>Display:</b><br>Select whether you want the box displayed. If you set to No your box settings will still be saved.<br><br><b>Box ID:</b><br>Optional. This ID can be referenced in CSS and the page array.<br><br><b>Label:</b><br>Enter the Label of the box to be visible in your store (optional)<br><br><b>Border Color:</b><br>Enter the Border Color of the box<br><br><b>Border Size:</b><br>Select the Border Size around the box (in pixels)<br><br><b>Background Color:</b><br>Enter the Background Color of the box<br><br><b>Location:</b><br>Custom Boxes can be positioned in various locations on a page. L=Left, R=Right, PT=Page Top, PB=Page Bottom, BT=Body Top, BB=Body Bottom, I[x]=Item Related Locations and C[x]=Category Related Locations. <a href=\"aom/images/locations.gif\" target=\"_blank\">See locations</a><br><br><b>Display Pages:</b><br>Specify which pages you want the box displayed on<br><br><b>1st Page Only:</b><br>Check this box if you want the custom box to appear only on the first page of a category (not on subsequent pages within the category or on subcategory pages, etc.).<br><br><b>NoFollow:</b><br>If Box Type is RSS, check this box if you want the RSS links to include the rel='nofollow' directive.<br><br><b>Display Rules:</b><br>Fine-tune conditions for when this Custom Box will be displayed. Leave both the green and red box blank to display the box on all applicable pages. If the green box is populated, the Custom Box will display only on these pages. If the red box is populated, the Custom Box will display on all pages except those specified. For the Category section use Category IDs (c). For the Subcategory section use Browse Nodes (n). For the Item section use ASINs (i). For the Custom Pages section use Page IDs. All values should be separated by a comma.<br><br><b>Box Content:</b><br>If the Box Type you selected was Raw HTML, you would paste the HTML in the Box Content section below. Or for a Box Type of HTML/PHP File, you would enter the server path or URL to the file/script in the Box Content section. <b>Note:</b> File paths are better and will load faster. On some servers you may need to use the URL. If the file is in the same location as your shop file, you might be able to simply enter the file name (e.g. yourfile.html, yourscript.php).<br><br><br>";

// Subcategories
$cfg['Subcategories']['section'] = "29";
$cfg['Subcategories']['type'] = "subcategories";
$cfg['Subcategories']['help'] = "<b>INSTRUCTIONS:</b> Optional. Below, you can add your own Subcategories in addition or in place of the automatic Amazon Subcategories.<br><br>
<b>Subcategory ID:</b><br>Enter your own unique Subcategory ID (e.g. sub123, 444, etc.)<br><br><b>Subcategory Name:</b><br>Enter the Names for each<br><br><b>Subcategory Type:</b><br>
There are 5 types of subcategories to choose from...<br>
<ul>
<li><b>Node:</b> This is a subcategory based on an Amazon browse node.</li>
<li><b>Blended:</b> This is a subcategory based on a specific keyword which will give results across multiple Amazon Categories.</li>
<li><b>ASIN List:</b> This is a subcategory based on a ASINs (items) of your choice (comma separated in the Content box).</li>
<li><b>ASIN File:</b> This is a subcategory based on a ASINs (items) of your choice (comma separated inside a separate file) where the file name is entered in the Content box.</li>
<li><b>URL:</b> This is a subcategory that simply points to any URL you specify which would be entered in the Content box</li>
</ul>
<b>Category:</b><br>Select the main Category from your store which the Subcategory will be associated with.<br><br><b>Parent Node:</b><br>This is the browse node that will trigger the display of the custom Subcategory link. So the Subcategory will be a child of this Parent Node. It is only applicable when the parent Category is a Regular (Node) category.<br><br><b>Subcategory Node:</b><br>Required for Node subcategories as it determines which items will be displayed inside your custom Subcategory. This browse node can then become the Parent Node for Node subcategories underneath it.";

if (!DEFINED("BRANDED"))
	$cfg['Subcategories']['help'] .= " <b>Note:</b> To find Amazon browse nodes visit our sister website: <b><a href=\"http://www.findbrowsenodes.com\" target=\"_blank\">FindBrowseNodes.com</a></b>";

$cfg['Subcategories']['help'] .= "<br><br><b>Subcategory Content:</b><br>Depending on the Subcategory Type selected, this field will require different information. When you select the Subcategory Type, you'll see instructions inside the Content box as to what you need to enter there. For the Node subcategory type the Content box would be for an optional keyword to refine results inside the Subcategory.<br><br><b>Order:</b><br>Select the Display Order (1 will be displayed first and so on)<br><br><b>Notes:</b><br>";

if (!DEFINED("BRANDED"))
	$cfg['Subcategories']['help'] .= "&#149; For additional information about Subcategory setup, see our <a href=\"http://www.associate-o-matic.com/docs/doc_cp_subcategories.html\" target=\"_blank\">documentation</a> page.<br>";

$cfg['Subcategories']['help'] .= "&#149; To add Subcategories enter the number you want to add below and click the Go button. To delete a category, select DELETE from the Category drop-down menu and click Save All Settings<br><br>";

// SubcategoryBox
$cfg['SubcategoryBox']['section'] = "29";
$cfg['SubcategoryBox']['type'] = "box";
$cfg['SubcategoryBox']['display']['list'] = Array('Yes', 'No');
$cfg['SubcategoryBox']['display']['default'] = "Yes";
$cfg['SubcategoryBox']['location']['list'] = Array('L', 'R', 'BT', 'BB');
$cfg['SubcategoryBox']['location']['default'] = "L";
$cfg['SubcategoryBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'SA' => 'Search All');
$cfg['SubcategoryBox']['order']['default'] = "";
$cfg['SubcategoryBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['SubcategoryBox']['bordersize']['default'] = "1";
$cfg['SubcategoryBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['SubcategoryBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['SubcategoryBox']['label'] = "Subcategories";
$cfg['SubcategoryBox']['help'] = "Browsable list of subcategory links with results conforming to your <b>Filter</b> and <b>Node Filter</b> (if specified). For Location: L=Left, R=Right, BT=Body Top and BB=Body Bottom.";

// SubcategoryDescriptions
$cfg['SubcategoryDescriptions']['section'] = "29";
$cfg['SubcategoryDescriptions']['type'] = "descr_sub";
$cfg['SubcategoryDescriptions']['help'] = "If provided, this description will be displayed at the top of the first page for that Subcategory. <b>Note:</b> Available for all but the URL subcategory type. To delete a description, remove the text/HTML and resave.";

// SubcategoryPreference
$cfg['SubcategoryPreference']['section'] = "29";
$cfg['SubcategoryPreference']['list'] = Array('ao' => 'Only Amazon Subcategories',
										      'co' => 'Only Custom Subcategories',
										      'bi' => 'Both (Listed Together)',
										      'be' => 'Both (Either/Or)',
										      );
$cfg['SubcategoryPreference']['type'] = "complexmenu";
$cfg['SubcategoryPreference']['help'] = "This setting controls which Subcategory links are displayed in the Subcategory Box above.<br><br><b>Only Amazon Subcategories:</b><br>Only Amazon's default Subcategories will be displayed.<br><br><b>Only Custom Subcategories:</b><br>Only your custom Subcategories will be displayed.<br><br><b>Both (Listed Together):</b><br>When available, both Amazon and your custom Subcategories will be displayed together.<br><br><b>Both (Either/Or):</b><br>If your custom Subcategories are applicable to the current store page, they will be displayed. Otherwise any available Amazon Subcategories will be displayed.<br><br>";
$cfg['SubcategoryPreference']['default'] = "bi";

// SubcategoryColumns
$cfg['SubcategoryColumns']['section'] = "29";
$cfg['SubcategoryColumns']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8');
$cfg['SubcategoryColumns']['type'] = "simplemenu";
$cfg['SubcategoryColumns']['help'] = "If the Subcategory Box location above is set to BT or BB, this is the number of columns that will be used to display the Subcategories.";
$cfg['SubcategoryColumns']['default'] = "4";

// RelatedCategoryBox
$cfg['RelatedCategoryBox']['section'] = "31";
$cfg['RelatedCategoryBox']['type'] = "box";
$cfg['RelatedCategoryBox']['display']['list'] = Array('Yes', 'No');
$cfg['RelatedCategoryBox']['display']['default'] = "Yes";
$cfg['RelatedCategoryBox']['location']['list'] = Array('L', 'R');
$cfg['RelatedCategoryBox']['location']['default'] = "L";
$cfg['RelatedCategoryBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'SA' => 'Search All');
$cfg['RelatedCategoryBox']['order']['default'] = "";
$cfg['RelatedCategoryBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['RelatedCategoryBox']['bordersize']['default'] = "1";
$cfg['RelatedCategoryBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['RelatedCategoryBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['RelatedCategoryBox']['label'] = "Related Categories";
$cfg['RelatedCategoryBox']['help'] = "Browsable list of related category links with results conforming to your <b>Filter</b> and <b>Node Filter</b> (if specified). For Location: L=Left, R=Right";

// RelatedCategoryBoxNodes
$cfg['RelatedCategoryBoxNodes']['section'] = "31";
$cfg['RelatedCategoryBoxNodes']['list'] = Array('All', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['RelatedCategoryBoxNodes']['type'] = "simplemenu";
$cfg['RelatedCategoryBoxNodes']['help'] = "Controls the number of related category links (nodes) to display. <b>Note:</b> The number of parent links displayed is controlled by the <b>Related Category Box Parent</b> setting below.";
$cfg['RelatedCategoryBoxNodes']['default'] = "All";

// RelatedCategoryBoxParent
$cfg['RelatedCategoryBoxParent']['section'] = "31";
$cfg['RelatedCategoryBoxParent']['list'] = Array('All', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['RelatedCategoryBoxParent']['type'] = "simplemenu";
$cfg['RelatedCategoryBoxParent']['help'] = "Controls the number of levels deep of related category link parent nodes to display. <b>Note:</b> These are the links with the up arrows.";
$cfg['RelatedCategoryBoxParent']['default'] = "4";

// NarrowByBrandBox
$cfg['NarrowByBrandBox']['section'] = "31";
$cfg['NarrowByBrandBox']['type'] = "box";
$cfg['NarrowByBrandBox']['display']['list'] = Array('Yes', 'No');
$cfg['NarrowByBrandBox']['display']['default'] = "Yes";
$cfg['NarrowByBrandBox']['location']['list'] = Array('L', 'R');
$cfg['NarrowByBrandBox']['location']['default'] = "L";
$cfg['NarrowByBrandBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories');
$cfg['NarrowByBrandBox']['order']['default'] = "";
$cfg['NarrowByBrandBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['NarrowByBrandBox']['bordersize']['default'] = "1";
$cfg['NarrowByBrandBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['NarrowByBrandBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['NarrowByBrandBox']['label'] = "Narrow By Brand";
$cfg['NarrowByBrandBox']['help'] = "Currently only available for Amazon.com (US) locale. Browsable list of Brand links to narrow down Category and Subcategory listings. Can be used in conjunction with Narrow By Price box. For Location: L=Left, R=Right";

// NarrowByPriceBox
$cfg['NarrowByPriceBox']['section'] = "31";
$cfg['NarrowByPriceBox']['type'] = "box";
$cfg['NarrowByPriceBox']['display']['list'] = Array('Yes', 'No');
$cfg['NarrowByPriceBox']['display']['default'] = "Yes";
$cfg['NarrowByPriceBox']['location']['list'] = Array('L', 'R');
$cfg['NarrowByPriceBox']['location']['default'] = "L";
$cfg['NarrowByPriceBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories');
$cfg['NarrowByPriceBox']['order']['default'] = "";
$cfg['NarrowByPriceBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['NarrowByPriceBox']['bordersize']['default'] = "1";
$cfg['NarrowByPriceBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['NarrowByPriceBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['NarrowByPriceBox']['label'] = "Narrow By Price";
$cfg['NarrowByPriceBox']['help'] = "Currently only available for Amazon.com (US) locale. Browsable list of Price links to narrow down Category and Subcategory listings. Can be used in conjunction with Narrow By Brand box. For Location: L=Left, R=Right";

// NewReleaseBox
$cfg['NewReleaseBox']['section'] = "31";
$cfg['NewReleaseBox']['type'] = "box";
$cfg['NewReleaseBox']['display']['list'] = Array('Yes', 'No');
$cfg['NewReleaseBox']['display']['default'] = "Yes";
$cfg['NewReleaseBox']['location']['list'] = Array('L', 'R');
$cfg['NewReleaseBox']['location']['default'] = "L";
$cfg['NewReleaseBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'SA' => 'Search All');
$cfg['NewReleaseBox']['order']['default'] = "";
$cfg['NewReleaseBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['NewReleaseBox']['bordersize']['default'] = "1";
$cfg['NewReleaseBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['NewReleaseBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['NewReleaseBox']['label'] = "New Releases";
$cfg['NewReleaseBox']['count']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['NewReleaseBox']['count']['default'] = "10";
$cfg['NewReleaseBox']['photos']['list'] = Array('Yes', 'No');
$cfg['NewReleaseBox']['photos']['default'] = "Yes";
$cfg['NewReleaseBox']['help'] = "List of newly released item links (US locale only). <b>Note:</b> This list is based on the browse node only... not your Site Default Keyword or category-level keywords though results will conform to your <b>Filter</b> (if specified). For Location: L=Left, R=Right";

// BestsellerBox
$cfg['BestsellerBox']['section'] = "31";
$cfg['BestsellerBox']['type'] = "box";
$cfg['BestsellerBox']['display']['list'] = Array('Yes', 'No');
$cfg['BestsellerBox']['display']['default'] = "Yes";
$cfg['BestsellerBox']['location']['list'] = Array('L', 'R');
$cfg['BestsellerBox']['location']['default'] = "L";
$cfg['BestsellerBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'SA' => 'Search All');
$cfg['BestsellerBox']['order']['default'] = "";
$cfg['BestsellerBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['BestsellerBox']['bordersize']['default'] = "1";
$cfg['BestsellerBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['BestsellerBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['BestsellerBox']['label'] = "Bestsellers";
$cfg['BestsellerBox']['count']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['BestsellerBox']['count']['default'] = "10";
$cfg['BestsellerBox']['photos']['list'] = Array('Yes', 'No');
$cfg['BestsellerBox']['photos']['default'] = "Yes";
$cfg['BestsellerBox']['help'] = "List of bestselling item links. <b>Note:</b> This list is based on the browse node only... not your Site Default Keyword or category-level keywords though results will conform to your <b>Filter</b> (if specified). For Location: L=Left, R=Right";

// MostGiftedBox
$cfg['MostGiftedBox']['section'] = "31";
$cfg['MostGiftedBox']['type'] = "box";
$cfg['MostGiftedBox']['display']['list'] = Array('Yes', 'No');
$cfg['MostGiftedBox']['display']['default'] = "No";
$cfg['MostGiftedBox']['location']['list'] = Array('L', 'R');
$cfg['MostGiftedBox']['location']['default'] = "L";
$cfg['MostGiftedBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'SA' => 'Search All');
$cfg['MostGiftedBox']['order']['default'] = "";
$cfg['MostGiftedBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['MostGiftedBox']['bordersize']['default'] = "1";
$cfg['MostGiftedBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['MostGiftedBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['MostGiftedBox']['label'] = "Most Gifted";
$cfg['MostGiftedBox']['count']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['MostGiftedBox']['count']['default'] = "10";
$cfg['MostGiftedBox']['photos']['list'] = Array('Yes', 'No');
$cfg['MostGiftedBox']['photos']['default'] = "Yes";
$cfg['MostGiftedBox']['help'] = "List of most-gifted item links. <b>Note:</b> This list is based on the browse node only... not your Site Default Keyword or category-level keywords though results will conform to your <b>Filter</b> (if specified). For Location: L=Left, R=Right";

// MostWishedForBox
$cfg['MostWishedForBox']['section'] = "31";
$cfg['MostWishedForBox']['type'] = "box";
$cfg['MostWishedForBox']['display']['list'] = Array('Yes', 'No');
$cfg['MostWishedForBox']['display']['default'] = "No";
$cfg['MostWishedForBox']['location']['list'] = Array('L', 'R');
$cfg['MostWishedForBox']['location']['default'] = "L";
$cfg['MostWishedForBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'SA' => 'Search All');
$cfg['MostWishedForBox']['order']['default'] = "";
$cfg['MostWishedForBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['MostWishedForBox']['bordersize']['default'] = "1";
$cfg['MostWishedForBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['MostWishedForBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['MostWishedForBox']['label'] = "Most Wished For";
$cfg['MostWishedForBox']['count']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['MostWishedForBox']['count']['default'] = "10";
$cfg['MostWishedForBox']['photos']['list'] = Array('Yes', 'No');
$cfg['MostWishedForBox']['photos']['default'] = "Yes";
$cfg['MostWishedForBox']['help'] = "List of most-wished-for item links (US locale only). <b>Note:</b> This list is based on the browse node only... not your Site Default Keyword or category-level keywords though results will conform to your <b>Filter</b> (if specified). For Location: L=Left, R=Right";

// Mp3ClipsBox
$cfg['Mp3ClipsBox']['section'] = "31";
$cfg['Mp3ClipsBox']['type'] = "box";
$cfg['Mp3ClipsBox']['display']['list'] = Array('Yes', 'No');
$cfg['Mp3ClipsBox']['display']['default'] = "No";
$cfg['Mp3ClipsBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['Mp3ClipsBox']['bordersize']['default'] = "0";
$cfg['Mp3ClipsBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['Mp3ClipsBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['Mp3ClipsBox']['location']['list'] = Array('I1', 'I2', 'I3', 'I4', 'I5', 'I6', 'I7');
$cfg['Mp3ClipsBox']['location']['default'] = "I4";
$cfg['Mp3ClipsBox']['displaypages']['list'] = Array('I' => 'Items');
$cfg['Mp3ClipsBox']['playersize']['list'] = Array('120x90', '234x60', '125x125', '120x300', '160x300', '250x250', '336x280');
$cfg['Mp3ClipsBox']['playersize']['default'] = "250x250";
$cfg['Mp3ClipsBox']['order']['default'] = "";
$cfg['Mp3ClipsBox']['help'] = "Displays the Amazon MP3 Clips Widget on your Item pages (only the MP3 Downloads category). It is automatically customized with your Amazon Associate ID. <a href=\"aom/images/locations.gif\" target=\"_blank\">See box location options</a><br>";

// InformationBox
$cfg['InformationBox']['section'] = "31";
$cfg['InformationBox']['type'] = "box";
$cfg['InformationBox']['display']['list'] = Array('Yes', 'No');
$cfg['InformationBox']['display']['default'] = "No";
$cfg['InformationBox']['location']['list'] = Array('L', 'R');
$cfg['InformationBox']['location']['default'] = "R";
$cfg['InformationBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'C' => 'Cart', 'CP' => 'Custom Pages', 'SA' => 'Search All');
$cfg['InformationBox']['order']['default'] = "";
$cfg['InformationBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['InformationBox']['bordersize']['default'] = "1";
$cfg['InformationBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['InformationBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['InformationBox']['label'] = "Information";
$cfg['InformationBox']['target']['list'] = Array('_self', '_top', '_blank', '_parent');
$cfg['InformationBox']['url'] = "";
$cfg['InformationBox']['help'] = "Create a box with auto-generated links to any URLs you specify whether inside or outside your store (i.e. About page, Contact page, etc). To not display this box set Display equal to No. For Location: L=Left, R=Right";

// SiteName
$cfg['SiteName']['section'] = "1";
$cfg['SiteName']['type'] = "text";
$cfg['SiteName']['help'] = "Enter your site name";
$cfg['SiteName']['default'] = "";
$cfg['SiteName']['required'] = TRUE;

// SiteDescription
$cfg['SiteDescription']['section'] = "1";
$cfg['SiteDescription']['type'] = "text";
$cfg['SiteDescription']['help'] = "Enter a description for your site (can be used in the Meta Description section)";
$cfg['SiteDescription']['default'] = "";
$cfg['SiteDescription']['required'] = TRUE;

// SiteKeywords
$cfg['SiteKeywords']['section'] = "1";
$cfg['SiteKeywords']['type'] = "textarea";
$cfg['SiteKeywords']['help'] = "Enter 20-30 keywords/phrases describing your website, separated by commas (can be used in the Meta Keywords section below)";
$cfg['SiteKeywords']['default'] = "";
$cfg['SiteKeywords']['required'] = TRUE;

// SiteDefaultKeyword
$cfg['SiteDefaultKeyword']['section'] = "1";
$cfg['SiteDefaultKeyword']['type'] = "text";
$cfg['SiteDefaultKeyword']['help'] = "Optional. Enter a short, default keyword/phrase for your site (e.g. <b>Star Wars</b>, <b>Mountain Biking</b>, etc.). This would be the general topic of your site used in search and browse results. Leave blank if you are opening a general 'mall' type store. <b>Note:</b> Test each store category you setup below to be sure results are returned. The more general the search term you use, the more likely Amazon will return results. You can also fine-tune default keywords at Category level as well.";


// SiteSlogan
$cfg['SiteSlogan']['section'] = "1";
$cfg['SiteSlogan']['type'] = "text";
$cfg['SiteSlogan']['help'] = "Enter a selling slogan (can be added to your page Title)";

// SiteHeader
$cfg['SiteHeader']['section'] = "1";
$cfg['SiteHeader']['type'] = "text";
$cfg['SiteHeader']['help'] = "Optional. Enter the URL to your header HTML file or PHP script (i.e. http://www.yoursite.com/header.html). <b>Note:</b> On some servers you may need to enter the path to the file instead of the URL. If the header file is in the same location as your shop file, you might be able to simply enter the file name (e.g. header.html). Also, do not enter HTML directly in this field.";

// SiteFooter
$cfg['SiteFooter']['section'] = "1";
$cfg['SiteFooter']['type'] = "text";
$cfg['SiteFooter']['help'] = "Optional. Enter the URL to your footer HTML file or PHP script (i.e. http://www.yoursite.com/footer.html). <b>Note:</b> On some servers you may need to enter the path to the file instead of the URL. If the footer file is in the same location as your shop file, you might be able to simply enter the file name (e.g. footer.html). Also, do not enter HTML directly in this field.";

// SiteDocType
$cfg['SiteDocType']['section'] = "1";
$cfg['SiteDocType']['type'] = "textarea";
$cfg['SiteDocType']['help'] = "If supplied, the doctype entered will override the default which is:<br>&lt;!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\"&gt; <b>Note:</b> The Rounded tab style relies on the default doctype.";

// SiteHead
$cfg['SiteHead']['section'] = "1";
$cfg['SiteHead']['type'] = "textarea";
$cfg['SiteHead']['help'] = "If supplied, this additional content will be added to the hidden HEAD area of all pages. This can be useful for such things as JavaScript and extra Meta Tags. <b>Note:</b> This content will only be displayed if Site Header is unpopulated.";

// SiteTrafficCode
$cfg['SiteTrafficCode']['section'] = "1";
$cfg['SiteTrafficCode']['type'] = "textarea";
$cfg['SiteTrafficCode']['help'] = "This is where you can paste code from any third-party site traffic tracking programs (e.g. Google Analytics).";

// SiteDisclaimer
$cfg['SiteDisclaimer']['section'] = "1";
$cfg['SiteDisclaimer']['type'] = "textarea";
$cfg['SiteDisclaimer']['help'] = "To display Amazon's required, default disclaimer (listed below) leave the default value of {DISCLAIMER}. This will display the appropriate disclaimer for the locale. You can also add any other disclaimer HTML above or below it. Similarly, you can create a Custom Box with your disclaimer HTML and control where it is located on the page.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.com'] = "<br><b>Required Disclaimer for Amazon.com:</b><br>CERTAIN CONTENT THAT APPEARS ON THIS SITE COMES FROM AMAZON SERVICES LLC. THIS CONTENT IS PROVIDED ‘AS IS’ AND IS SUBJECT TO CHANGE OR REMOVAL AT ANY TIME.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.co.uk'] = "<br><b>Required Disclaimer for Amazon.co.uk:</b><br>CERTAIN CONTENT THAT APPEARS ON THIS SITE COMES FROM AMAZON EU S.à.r.l. THIS CONTENT IS PROVIDED ‘AS IS’ AND IS SUBJECT TO CHANGE OR REMOVAL AT ANY TIME.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.ca'] = "<br><b>Required Disclaimer for Amazon.ca:</b><br>CERTAIN CONTENT THAT APPEARS ON THIS SITE COMES FROM AMAZON.CA INC. THIS CONTENT IS PROVIDED ‘AS IS’ AND IS SUBJECT TO CHANGE OR REMOVAL AT ANY TIME.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.de'] = "<br><b>Required Disclaimer for Amazon.de:</b><br>GEWISSE INHALTE, DIE AUF DIESER WEBSITE ERSCHEINEN, STAMMEN VON AMAZON EU SARL. DIESE INHALTE WERDEN SO, WIE SIE SIND ZUR VERFÜGUNG GESTELLT UND KÖNNEN JEDERZEIT GEÄNDERT ODER ENTFERNT WERDEN.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.fr'] = "<br><b>Required Disclaimer for Amazon.fr:</b><br>CERTAINS ÉLÉMENTS DE CONTENU APPARAISSANT SUR CE SITE VIENNENT DE AMAZON EU S.à.r.l. CE CONTENU EST FOURNI « TEL QUEL » ET PEUT À TOUT MOMENT FAIRE L'OBJET DE MODIFICATIONS OU DE RETRAITS.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.co.jp'] = "<br><b>Required Disclaimer for Amazon.co.jp:</b><br>&#26412;&#12450;&#12503;&#12522;&#12465;&#12540;&#12471;&#12519;&#12531;&#20869;&#12414;&#12383;&#12399;&#26412;&#12469;&#12452;&#12488;&#19978;&#12398;&#36969;&#29992;&#12354;&#12427;&#26041;]&#12391;&#34920;&#31034;&#12373;&#12428;&#12427;&#12467;&#12531;&#12486;&#12531;&#12484;&#12398;&#19968;&#37096;&#12399;&#12289;&#12450;&#12510;&#12478;&#12531;&#12472;&#12515;&#12497;&#12531;&#26666;&#24335;&#20250;&#31038;&#12414;&#12383;&#12399;&#12381;&#12398;&#38306;&#36899;&#20250;&#31038;&#12395;&#12424;&#12426;&#25552;&#20379;&#12373;&#12428;&#12383;&#12418;&#12398;&#12391;&#12377;&#12290;&#12363;&#12363;&#12427;&#12467;&#12531;&#12486;&#12531;&#12484;&#12399;&#12289;&#12362;&#23458;&#27096;&#12395;&#12300;&#29694;&#29366;&#26377;&#23039;&#12301;&#12391;&#25552;&#20379;&#12373;&#12428;&#12390;&#12362;&#12426;&#12289;&#38543;&#26178;&#22793;&#26356;&#12414;&#12383;&#12399;&#21066;&#38500;&#12373;&#12428;&#12427;&#22580;&#21512;&#12364;&#12354;&#12426;&#12414;&#12377;&#12290;";
$cfg['SiteDisclaimer']['help_locale']['Amazon.it'] = "<br><b>Required Disclaimer for Amazon.it:</b><br>CERTAIN CONTENT THAT APPEARS ON THIS SITE COMES FROM AMAZON EU S.à r.l. THIS CONTENT IS PROVIDED ‘AS IS’ AND IS SUBJECT TO CHANGE OR REMOVAL AT ANY TIME.";
$cfg['SiteDisclaimer']['help_locale']['Amazon.cn'] = "<br><b>Required Disclaimer for Amazon.cn:</b><br>本网站上的若干内容来自北京世纪卓越信息技术有限公司。这些内容是按“现状”提供的，并可随时变更或移除。";
$cfg['SiteDisclaimer']['default'] = "{DISCLAIMER}";

// Debugger
$cfg['Debugger']['section'] = "1";
$cfg['Debugger']['list'] = Array('On', 'Off');
$cfg['Debugger']['type'] = "radio";
$cfg['Debugger']['help'] = "When set to <b>On</b>, onscreen server error reporting is enabled. Should be used for troubleshooting purposes only while setting up your store. Once your store is live, this should be set to <b>Off</b>.";
$cfg['Debugger']['default'] = "Off";

// PoweredBy
$cfg['PoweredBy']['section'] = "1";
$cfg['PoweredBy']['type'] = "textarea";
$cfg['PoweredBy']['help'] = "This controls the Powered By link area. Whatever you enter here will replace the current Powered By link generated by Associate-O-Matic.<br><br>Additionally, you can join the <a href=\"http://www.clixgalore.com/AffSelectProgram.aspx?AdvProgID=3791\" target=\"_blank\"><b>Associate-O-Matic Affiliate Program</b></a> (hosted by clixGalore) and earn referral fees for software sales by placing special affiliate HTML in this area or elsewhere in your store.";
$cfg['PoweredBy']['help_trial'] = "This controls the Powered By link area. Whatever you enter here will replace the current Powered By link generated by Associate-O-Matic.";
$cfg['PoweredBy']['default'] = "";
$cfg['PoweredBy']['required'] = false;

// Filter
$cfg['Filter']['section'] = "26";
$cfg['Filter']['type'] = "text";
$cfg['Filter']['help'] = "If provided, these words will be filtered from the Subcategory, Related Category, New Release and Bestseller Boxes, etc. Enter keywords/phrases separated by a comma -  not case sensitive (e.g. sex, blue, whatever). <b>Note:</b> Partial words cause the whole word/phrase to be filtered (e.g. \"a\" would filter all words containing the letter \"a\" for example \"f<b>a</b>rm\", \"s<b>a</b>nta\" and etc)";

// NodeFilter
$cfg['NodeFilter']['section'] = "26";
$cfg['NodeFilter']['type'] = "text";
$cfg['NodeFilter']['help'] = "If provided, these specific nodes will be filtered from the Subcategory and Related Category Boxes as well as Breadcrumb location paths. Enter nodes separated by a comma.";

// ItemFilter
$cfg['ItemFilter']['section'] = "26";
$cfg['ItemFilter']['type'] = "text";
$cfg['ItemFilter']['help'] = "If provided, any items with a title that contains any of these words will be filtered from searches and browsing. Enter values separated by a comma. <b>Note:</b> Items can also be filtered by ASIN number.";

// MerchantFilter
$cfg['MerchantFilter']['section'] = "26";
$cfg['MerchantFilter']['type'] = "text";
$cfg['MerchantFilter']['help'] = "If provided, <b>offers</b> from this merchant will be filtered. Enter values separated by a comma. <b>Note:</b> Use the name of the Merchant, not the ID.";

// IpFilter
$cfg['IpFilter']['section'] = "26";
$cfg['IpFilter']['type'] = "text";
$cfg['IpFilter']['help'] = "If provided, visitors from these IP addresses will not be able to view your store. Enter IP(s) separated by a comma (e.g. 111.222.333.444).<br><b>Note:</b> For wildcard IP values use an asterisk (e.g. 111.222.333.*).";

// ImageFilter
$cfg['ImageFilter']['section'] = "26";
$cfg['ImageFilter']['list'] = Array('Yes', 'No');
$cfg['ImageFilter']['type'] = "radio";
$cfg['ImageFilter']['help'] = "Whether or not to display items that do not have photos";
$cfg['ImageFilter']['default'] = "Yes";

// MovieFilter
$cfg['MovieFilter']['section'] = "26";
$cfg['MovieFilter']['locale'] = TRUE;
$cfg['MovieFilter']['list']['Amazon.com'] 	= Array('Unrated', 'NR', 'R', 'PG-13', 'PG', 'G');
$cfg['MovieFilter']['list']['Amazon.co.uk'] 	= Array();
$cfg['MovieFilter']['list']['Amazon.ca'] 	= Array('Unrated', 'NR', 'R', 'PG-13', 'PG', 'G', 'Family Viewing');
$cfg['MovieFilter']['list']['Amazon.de'] 	= Array();//Array('16', '12', '6');
$cfg['MovieFilter']['list']['Amazon.fr'] 	= Array('18', '16', '12', 'PG');
$cfg['MovieFilter']['list']['Amazon.co.jp'] 	= Array();//Array('16', '12', '6');
$cfg['MovieFilter']['list']['Amazon.it'] 	= Array();
$cfg['MovieFilter']['list']['Amazon.cn'] 	= Array();
$cfg['MovieFilter']['list']['Amazon.es'] 	= Array();
$cfg['MovieFilter']['cols'] = 8;
$cfg['MovieFilter']['type'] = "checkboxes";
$cfg['MovieFilter']['help'] = "Check only those movie ratings you want displayed in your store (uncheck those you want filtered). Applies to DVDs, VHS and Unbox Video.<br><b>Note:</b> Not currently available for UK, DE, JP, IT and CN stores.";

// ReviewSort
$cfg['ReviewSort']['section'] = "32";
$cfg['ReviewSort']['list'] = Array(
	'-SubmissionDate'	=> 'Submission Date (Newer to Older)',
	'SubmissionDate'	=> 'Submission Date (Older to Newer)',
	'-OverallRating'	=> 'Overall Rating (High to Low)',
	'OverallRating'		=> 'Overall Rating (Low to High)',
	'-HelpfulVotes'		=> 'Helpful Votes (High to Low)',
	'HelpfulVotes'		=> 'Helpful Votes (Low to High)',
	'-Rank'				=> 'Helpful Reviews (Most to Least)',
	'Rank'				=> 'Helpful Reviews (Least to Most)',
	);
$cfg['ReviewSort']['type'] = "complexmenu";
$cfg['ReviewSort']['help'] = "Specifies the order in which Customer Reviews are sorted";
$cfg['ReviewSort']['default'] = "-OverallRating";

// ErrorSearch
$cfg['ErrorSearch']['section'] = "16";
$cfg['ErrorSearch']['type'] = "textarea";
$cfg['ErrorSearch']['help'] = "If provided this error message (any HTML or text) will be displayed instead of the standard Amazon error when there are no search results.";

// ErrorItemNotAvailable
$cfg['ErrorItemNotAvailable']['section'] = "16";
$cfg['ErrorItemNotAvailable']['type'] = "textarea";
$cfg['ErrorItemNotAvailable']['help'] = "If provided this error message (any HTML or text) will be displayed in cases where an item is no longer available. Otherwise the default message will appear... 'This Item Is No Longer Available'.";

// ErrorNoData
$cfg['ErrorNoData']['section'] = "16";
$cfg['ErrorNoData']['type'] = "textarea";
$cfg['ErrorNoData']['help'] = "If provided this error message (any HTML or text) will be displayed in cases where no data is returned from Amazon. Otherwise the default message will appear... 'The server is busy. Please refresh this page in a moment.'. If you are not getting data returned from Amazon and it happens everytime, then it is most likely related to a server configuration issue on your side. From time to time, Amazon's servers might be busy or slow. If this causes data to not be returned, this would be another case where this error message would be displayed. <b>Note:</b> If this error occurs and you have page caching enabled, the page in question will not be cached which is good. It will be cached only when data is successfully returned from Amazon.";

// ErrorCart
$cfg['ErrorCart']['section'] = "16";
$cfg['ErrorCart']['type'] = "textarea";
$cfg['ErrorCart']['help'] = "If provided this error message (any HTML or text) will be displayed underneath the standard \"Your shopping cart is empty\" message (e.g. For example if someone doesn't have cookies enabled or their cart has expired).";

// ErrorApiLimit
$cfg['ErrorApiLimit']['section'] = "16";
$cfg['ErrorApiLimit']['type'] = "textarea";
$cfg['ErrorApiLimit']['help'] = "If provided this error message (any HTML or text) will be displayed in cases where you have reached the Amazon API limit.<br>For more information about their API limits read the <a href=\"https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html\" target=\"_blank\">Amazon's Efficiency Guidelines</a>.";

// ErrorApiLimitFile
$cfg['ErrorApiLimitFile']['section'] = "16";
$cfg['ErrorApiLimitFile']['type'] = "text";
$cfg['ErrorApiLimitFile']['help'] = "If provided, the URL/filename/PHP script you enter here will be included in cases where you have reached the Amazon API limit.<br>For more information about their API limites read <a href=\"https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html\" target=\"_blank\">Amazon's Efficiency Guidelines</a>.";

// ErrorHttp404
$cfg['ErrorHttp404']['section'] = "16";
$cfg['ErrorHttp404']['type'] = "text";
$cfg['ErrorHttp404']['help'] = "By default, when a page is no longer found in your store (e.g. old category or item pages) users are redirected to your home page. If provided, the URL you enter here will be used as the HTTP 404 Error Page (Page Not Found) for your store.";

// TextFont
$cfg['TextFont']['section'] = "2";
$cfg['TextFont']['list'] = Array(
	'Arial, sans-serif',
	'Times New Roman, serif',
	'Verdana, sans-serif',
	'Tahoma, sans-serif',
	'Courier New, monospace',
	'Comic Sans, cursive',
	'Impact, fantasy',
	);
$cfg['TextFont']['type'] = "simplemenu";
$cfg['TextFont']['help'] = "Select the font for your site";
$cfg['TextFont']['default'] = "Arial, sans-serif";
$cfg['TextFont']['required'] = TRUE;

// TextSize
$cfg['TextSize']['section'] = "2";
$cfg['TextSize']['list'] = Array(
	'xx-small',
	'x-small',
	'small',
	'medium',
	'large',
	'x-large',							 
	'xx-large',
	'10px',
	'12px',
	'14px',
	'16px',
	'18px',
	);
$cfg['TextSize']['type'] = "simplemenu";
$cfg['TextSize']['help'] = "Select the size of your site text<br><span style=\"font-size: xx-small\">xx-small</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: x-small\">x-small</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: small\">small</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: medium\">medium</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: large\">large</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: x-large\">x-large</span>&nbsp;&nbsp;&nbsp;<span style=\"font-size: xx-large\">xx-large</span>";
$cfg['TextSize']['default'] = "small";
$cfg['TextSize']['required'] = TRUE;

// TextColor
$cfg['TextColor']['section'] = "2";
$cfg['TextColor']['type'] = "color";
$cfg['TextColor']['help'] = "Choose the site text color";
$cfg['TextColor']['default'] = "#000000";
$cfg['TextColor']['required'] = TRUE;

// TextHighlightColor
$cfg['TextHighlightColor']['section'] = "2";
$cfg['TextHighlightColor']['type'] = "color";
$cfg['TextHighlightColor']['help'] = "Choose the text color for highlighted areas such as 'Eligible for Super Saver Shipping', 'New Release', etc...";
$cfg['TextHighlightColor']['default'] = "#990000";
$cfg['TextHighlightColor']['required'] = TRUE;

// TextDarkColor
$cfg['TextDarkColor']['section'] = "2";
$cfg['TextDarkColor']['type'] = "color";
$cfg['TextDarkColor']['help'] = "Choose the text color for the tabs, search bar, breadcrumbs etc. This color would be used on light backgrounds versus the <b>Text Light Color</b> which is used on dark backgrounds.";
$cfg['TextDarkColor']['default'] = "#000000";
$cfg['TextDarkColor']['required'] = TRUE;

// TextLightColor
$cfg['TextLightColor']['section'] = "2";
$cfg['TextLightColor']['type'] = "color";
$cfg['TextLightColor']['help'] = "Choose the text color for the tabs, search bar, breadcrumbs etc. This color would be used on dark backgrounds versus the <b>Text Dark Color</b> which is used on light backgrounds.";
$cfg['TextLightColor']['default'] = "#FFFFFF";
$cfg['TextLightColor']['required'] = TRUE;

// ImageSizeHome
$cfg['ImageSizeHome']['section'] = "9";
$cfg['ImageSizeHome']['list'] = Array(
	'Small',
	'Tiny',
	'Medium',
	'Large',
	);
$cfg['ImageSizeHome']['type'] = "simplemenu";
$cfg['ImageSizeHome']['help'] = "Select the item image size to display on the Home page. If you want to force images to a specific width and/or height specify those. Otherwise leave blank for images to display their normal size.";
$cfg['ImageSizeHome']['dimensions'] = TRUE;
$cfg['ImageSizeHome']['default'] = "Small";

// ImageSizeCategory
$cfg['ImageSizeCategory']['section'] = "9";
$cfg['ImageSizeCategory']['list'] = Array(
	'Small',
	'Tiny',
	'Medium',
	'Large',
	);
$cfg['ImageSizeCategory']['type'] = "simplemenu";
$cfg['ImageSizeCategory']['help'] = "Select the item image size to display on the Category and Subcategory pages. If you want to force images to a specific width and/or height specify those. Otherwise leave blank for images to display their normal size.";
$cfg['ImageSizeCategory']['dimensions'] = TRUE;
$cfg['ImageSizeCategory']['default'] = "Medium";

// ImageSizeItem
$cfg['ImageSizeItem']['section'] = "9";
$cfg['ImageSizeItem']['list'] = Array(
	'Small',
	'Tiny',
	'Medium',
	'Large',
	);
$cfg['ImageSizeItem']['type'] = "simplemenu";
$cfg['ImageSizeItem']['help'] = "Select the item image size to display on the Item detail pages. If you want to force images to a specific width and/or height specify those. Otherwise leave blank for images to display their normal size.";
$cfg['ImageSizeItem']['dimensions'] = TRUE;
$cfg['ImageSizeItem']['default'] = "Medium";

// ImageZoom
$cfg['ImageZoom']['section'] = "9";
$cfg['ImageZoom']['list'] = Array(
	'lightbox1' => 'Lightbox (Style 1)',
	'lightbox2' => 'Lightbox (Style 2)',
	'lightbox3' => 'Lightbox (Style 3)',
	'lightbox4' => 'Lightbox (Style 4)',
	'lightbox5' => 'Lightbox (Style 5)',
	'popup' 	=> 'Popup Window',
	);
$cfg['ImageZoom']['type'] = "zoom";
$cfg['ImageZoom']['help'] = "Select the style of window to use when someone views an enlarged version of a product photo.";
$cfg['ImageZoom']['default'] = "lightbox1";

// ImageOverride
$cfg['ImageOverride']['section'] = "9";
$cfg['ImageOverride']['list'] = Array('On', 'Off');
$cfg['ImageOverride']['type'] = "radio";
$cfg['ImageOverride']['help'] = "When set to <b>On</b>, Amazon product images will not be displayed on Item pages. This is useful if you are wanting to setup your own image display format using a Custom Box and our API (e.g. lightbox).";
$cfg['ImageOverride']['default'] = "Off";

// AspectRatio
$cfg['AspectRatio']['section'] = "9";
$cfg['AspectRatio']['list'] = Array('On', 'Off');
$cfg['AspectRatio']['type'] = "radio";
$cfg['AspectRatio']['help'] = "When an image <b>Width</b> is set above and not the <b>Height</b> (or vice versa), this will ensure the aspect ratio remains intact so the image does not appear distorted.";
$cfg['AspectRatio']['default'] = "On";

// ColorScheme
$cfg['ColorScheme']['section'] = "10";
$cfg['ColorScheme']['type'] = "colorscheme";
$cfg['ColorScheme']['help'] = "Choose a color scheme for your site. You can change individual colors after applying a color scheme.<br><a href=\"http://www.associate-o-matic.com/colorschemes/\" target=\"_blank\"><b>Download more color schemes</b></a><br><br>";
//$cfg['ColorScheme']['default'] = "aom_classic";
$cfg['ColorScheme']['required'] = TRUE;

// MainColor
$cfg['MainColor']['section'] = "10";
$cfg['MainColor']['type'] = "color";
$cfg['MainColor']['help'] = "Choose the main color for your site";
$cfg['MainColor']['default'] = "#0289C1";
$cfg['MainColor']['required'] = TRUE;

// AccentColor
$cfg['AccentColor']['section'] = "10";
$cfg['AccentColor']['type'] = "color";
$cfg['AccentColor']['help'] = "Choose the accent color for your site";
$cfg['AccentColor']['default'] = "#77C1DD";
$cfg['AccentColor']['required'] = TRUE;

// BgColor
$cfg['BgColor']['section'] = "10";
$cfg['BgColor']['type'] = "color";
$cfg['BgColor']['help'] = "Choose the background color for your site";
$cfg['BgColor']['default'] = "#EAEAEA";
$cfg['BgColor']['required'] = TRUE;

// BodyBorderColor
$cfg['BodyBorderColor']['section'] = "10";
$cfg['BodyBorderColor']['type'] = "color";
$cfg['BodyBorderColor']['help'] = "Choose the body border color. In previous versions it used the <b>Main Color</b> value.";
$cfg['BodyBorderColor']['default'] = "#CCCCCC";

// BodyBgColor
$cfg['BodyBgColor']['section'] = "10";
$cfg['BodyBgColor']['type'] = "color";
$cfg['BodyBgColor']['help'] = "Choose the body background color";
$cfg['BodyBgColor']['default'] = "#FFFFFF";
$cfg['BodyBgColor']['required'] = TRUE;

// LineColor
$cfg['LineColor']['section'] = "10";
$cfg['LineColor']['type'] = "color";
$cfg['LineColor']['help'] = "Choose the color of separator lines. In previous versions, this was always the same as the <b>Main Color</b>. If you would rather these lines don't appear, set this color the same as your <b>Bg Color</b>.";
$cfg['LineColor']['default'] = "#EAEAEA";
$cfg['LineColor']['required'] = TRUE;

// LinkColor
$cfg['LinkColor']['section'] = "10";
$cfg['LinkColor']['type'] = "color";
$cfg['LinkColor']['help'] = "Choose the color of links";
$cfg['LinkColor']['default'] = "#0000EE";
$cfg['LinkColor']['required'] = TRUE;

// LinkHoverColor
$cfg['LinkHoverColor']['section'] = "10";
$cfg['LinkHoverColor']['type'] = "color";
$cfg['LinkHoverColor']['help'] = "Choose the color of links hovered over";
$cfg['LinkHoverColor']['default'] = "#6666FF";

// LinkVisitedColor
$cfg['LinkVisitedColor']['section'] = "10";
$cfg['LinkVisitedColor']['type'] = "color";
$cfg['LinkVisitedColor']['help'] = "Choose the color of links visited";
$cfg['LinkVisitedColor']['default'] = "#551A8B";

// SiteCss
$cfg['SiteCss']['section'] = "28";
$cfg['SiteCss']['type'] = "text";
$cfg['SiteCss']['help'] = "Enter the URL or path to your own CSS file (i.e. http://www.yoursite.com/styles.css) to further customize your store beyond the control panel.";

// CssOverride
$cfg['CssOverride']['section'] = "28";
$cfg['CssOverride']['list'] = Array('Yes', 'No');
$cfg['CssOverride']['type'] = "radio";
$cfg['CssOverride']['help'] = "Whether you want to override the default CSS definitions. <b>Note:</b> If set to Yes, it is assumed you have setup your own CSS file above with style definitions similar to those found in the default theme.";
$cfg['CssOverride']['default'] = "No";

// Logo
$cfg['Logo']['section'] = "9";
$cfg['Logo']['type'] = "image";
$cfg['Logo']['help'] = "Enter the URL (http://www.yourdomain.com/logo.gif) to your logo or masthead graphic";

// TextLogo
$cfg['TextLogo']['section'] = "9";
$cfg['TextLogo']['type'] = "textlogo";
$cfg['TextLogo']['help'] = "If you don't have a Logo graphic for the above setting use this setting to create a simple text-based 'logo'. Specify the text, font, size, weight, color. If nothing else it can act as a placeholder until you have a graphical logo.";
$cfg['TextLogo']['font']['list'] = Array('Arial, sans-serif', 'Times New Roman, serif', 'Verdana, sans-serif', 'Tahoma, sans-serif', 'Courier New, monospace', 'Comic Sans, cursive', 'Impact, fantasy');
$cfg['TextLogo']['font']['default'] = "Arial, sans-serif";
$cfg['TextLogo']['size']['list'] = Array('xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', '10px', '20px', '30px', '40px', '50px', '60px', '70px', '80px', '90px');
$cfg['TextLogo']['size']['default'] = "xx-large";
$cfg['TextLogo']['weight']['list'] = Array('bold', 'normal', '100', '200', '300', '400', '500', '600', '700', '800', '900');
$cfg['TextLogo']['weight']['default'] = "bold";
$cfg['TextLogo']['color']['default'] = "#000000";

// LogoAlignment
$cfg['LogoAlignment']['section'] = "9";
$cfg['LogoAlignment']['list'] = Array('Left', 'Center', 'Right');
$cfg['LogoAlignment']['type'] = "simplemenu";
$cfg['LogoAlignment']['help'] = "This sets the horizontal alignment of your graphical or text logo from above";
$cfg['LogoAlignment']['default'] = "Left";

// Images
$cfg['Images']['section'] = "9";
$cfg['Images']['type'] = "images";
$cfg['Images']['help'] = "View the buttons and icon images currently available for use in your store (inside the /aom/themes/[your theme]/images directory). You can replace any of these graphics with your own graphics. Simply save the new graphic with the same name as the graphic you want to replace and upload it to your server.";

// SearchBtnImage
$cfg['SearchBtnImage']['section'] = "9";
$cfg['SearchBtnImage']['type'] = "image";
$cfg['SearchBtnImage']['help'] = "Enter the URL (http://www.yourdomain.com/search_btn.gif) to use for the search button (otherwise uses regular HTML button)";

// BestsellerImage
$cfg['BestsellerImage']['salesrank'] = "100"; // customizable - items with a sales rank of this value or lower will be deemed bestsellers
$cfg['BestsellerImage']['section'] = "9";
$cfg['BestsellerImage']['type'] = "image";
$cfg['BestsellerImage']['help'] = "Enter the URL (http://www.yourdomain.com/bestseller.gif) to use for the bestselling items (any item in the top {$cfg['BestsellerImage']['salesrank']} sales rank on Amazon)";

// NewReleaseImage
$cfg['NewReleaseImage']['days'] = "30"; // customizable - items released within this many days back will be deemed new releases
$cfg['NewReleaseImage']['section'] = "9";
$cfg['NewReleaseImage']['type'] = "image";
$cfg['NewReleaseImage']['help'] = "Enter the URL (http://www.yourdomain.com/newrelease.gif) to use for the newly released items (any item released within the last {$cfg['NewReleaseImage']['days']} days on Amazon)";

// BgImage
$cfg['BgImage']['section'] = "9";
$cfg['BgImage']['type'] = "image";
$cfg['BgImage']['help'] = "Enter the URL (http://www.yourdomain.com/background.gif) to your background graphic (if any)";

// TileBgImage
$cfg['TileBgImage']['section'] = "9";
$cfg['TileBgImage']['list'] = Array('Yes', 'No');
$cfg['TileBgImage']['type'] = "radio";
$cfg['TileBgImage']['help'] = "Whether or not to tile the background image (if specified above)";
$cfg['TileBgImage']['default'] = "No";

// Alignment
$cfg['Alignment']['section'] = "27";
$cfg['Alignment']['list'] = Array('Left', 'Center', 'Right');
$cfg['Alignment']['type'] = "simplemenu";
$cfg['Alignment']['help'] = "Select the alignment of your store within the browser window";
$cfg['Alignment']['default'] = "Center";

// Width
$cfg['Width']['section'] = "27";
$cfg['Width']['type'] = "number";
$cfg['Width']['help'] = "Enter the overall width of your store. It can be a percentage (e.g. 100%) or a pixel width integer (e.g. 750). <b>Note:</b> Your store pages may still stretch beyond this width depending on the size of images you specify and the location of custom content boxes.";
$cfg['Width']['default'] = "99%";
$cfg['Width']['required'] = TRUE;

// ColumnWidthLeft
$cfg['ColumnWidthLeft']['section'] = "27";
$cfg['ColumnWidthLeft']['type'] = "number";
$cfg['ColumnWidthLeft']['help'] = "Enter a width (integer) for left side navigation column (default 160 pixels)";
$cfg['ColumnWidthLeft']['default'] = "160";
$cfg['ColumnWidthLeft']['required'] = TRUE;

// ColumnWidthRight
$cfg['ColumnWidthRight']['section'] = "27";
$cfg['ColumnWidthRight']['type'] = "number";
$cfg['ColumnWidthRight']['help'] = "Enter a width (integer) for right side navigation column (default 160 pixels)";
$cfg['ColumnWidthRight']['default'] = "160";
$cfg['ColumnWidthRight']['required'] = TRUE;

// Merchant
$cfg['Merchant']['section'] = "24";
$cfg['Merchant']['list'] = Array('All', 'Amazon');
$cfg['Merchant']['type'] = "simplemenu";
$cfg['Merchant']['help'] = "This setting controls which merchant offers are featured on Category, Subcategory and Item pages.<br><br><b>All:</b><br>Recommended. All merchant offerings will be accessible (including Amazon and other merchants). You can fine-tune which item gets featured by using the <b>Merchant Preference</b> setting below. This option also gives you access to marketplace offers (when you set the <b>Display Marketplace Links</b> setting below to Yes).<br><br><b>Amazon:</b><br>On Category, Subcategory and Item pages, Amazon items will be featured. This option also gives you access to marketplace offers (when you set <b>Display Marketplace Links</b> to Yes). <b>Note:</b> Certain categories will be sparse if you select this option (e.g. Apparel, Jewelry, etc.) as Amazon relies on other merchants in most cases to supply these items.<br><br>";
$cfg['Merchant']['default'] = "All";

// MerchantItems
$cfg['MerchantItems']['section'] = "24";
$cfg['MerchantItems']['list'] = Array('All', 'New', 'Used', 'Refurbished', 'Collectible');
$cfg['MerchantItems']['type'] = "radio";
$cfg['MerchantItems']['help'] = "This setting controls the types of Items that will be featured on Category, Subcategory and Item pages. <b>Note</b> You can override this setting at Category level.";
$cfg['MerchantItems']['required'] = TRUE;
$cfg['MerchantItems']['default'] = "All";

// MerchantPreference
$cfg['MerchantPreference']['section'] = "24";
$cfg['MerchantPreference']['list'] = Array(
	'lowest_new' => 'Lowest Priced New Offer',
	'lowest_used' => 'Lowest Priced Used Offer',
	'lowest_collectible' => 'Lowest Priced Collectible Offer',
	'lowest_refurbished' => 'Lowest Priced Refurbished Offer',
	'amazon' => 'Amazon Offer (When Available)',
	);
$cfg['MerchantPreference']['type'] = "complexmenu";
$cfg['MerchantPreference']['help'] = "This setting controls the merchant offer preference of the Buy buttons on Category, Subcategory and Item pages. If the preferred offer isn't available, the lowest priced offer from the next Item type will be used in this order: New, Used, Collectible, Refurbished (depending on which <b>Marketplace Items</b> you select below).";
$cfg['MerchantPreference']['default'] = "lowest_new";

// MerchantCount
$cfg['MerchantCount']['section'] = "24";
$cfg['MerchantCount']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15');
$cfg['MerchantCount']['type'] = "simplemenu";
$cfg['MerchantCount']['help'] = "On Item pages with selectable options such as Color, Size, etc., this setting is the maximum number of merchants you want offers displayed from.";
$cfg['MerchantCount']['default'] = "5";

// DisplayMarketplaceLinks
$cfg['DisplayMarketplaceLinks']['section'] = "24";
$cfg['DisplayMarketplaceLinks']['list'] = Array('Yes', 'No');
$cfg['DisplayMarketplaceLinks']['type'] = "radio";
$cfg['DisplayMarketplaceLinks']['help'] = "Whether you want to display the New/Used/Collectible/Refurbished links on Category, Subcategory and Item pages. The marketplace is where Item listings from Amazon and third-party merchants are offered. <b>Note:</b> Setting this to No greatly reduces item offers available in your store.";
$cfg['DisplayMarketplaceLinks']['default'] = "Yes";

// MarketplaceItems
$cfg['MarketplaceItems']['section'] = "24";
$cfg['MarketplaceItems']['list'] = Array('New', 'Used', 'Refurbished', 'Collectible');
$cfg['MarketplaceItems']['type'] = "checkboxes";
$cfg['MarketplaceItems']['help'] = "These are the types of Items that will be available on marketplace listing pages.";
$cfg['MarketplaceItems']['required'] = TRUE;

// MinimumPrice
$cfg['MinimumPrice']['section'] = "24";
$cfg['MinimumPrice']['type'] = "currency";
$cfg['MinimumPrice']['help'] = "Enter the <b>Minimum Price</b> you want for items displayed on Category and Subcategory pages (e.g. 24.99). No currency signs or commas. Leave blank for no Minimum Price.";

// MaximumPrice
$cfg['MaximumPrice']['section'] = "24";
$cfg['MaximumPrice']['type'] = "currency";
$cfg['MaximumPrice']['help'] = "Enter the <b>Maximum Price</b> you want for items displayed on Category and Subcategory pages (e.g. 1500.00). No currency signs or commas. Leave blank for no Maximum Price.";

// CategoryColumns
$cfg['CategoryColumns']['enhanced'] = TRUE;
$cfg['CategoryColumns']['section'] = "27";
$cfg['CategoryColumns']['list'] = Array('1', '2', '3', '4', '5');
$cfg['CategoryColumns']['type'] = "simplemenu";
$cfg['CategoryColumns']['help'] = "This is the number of columns used on applicable Category and Subcategory pages";
$cfg['CategoryColumns']['default'] = "2";

// BodyBorderSize
$cfg['BodyBorderSize']['section'] = "27";
$cfg['BodyBorderSize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BodyBorderSize']['type'] = "simplemenu";
$cfg['BodyBorderSize']['help'] = "Select the border size in pixels for the body content area. In previous versions this was always set at 1. Set it to 0 if you don't want to display the border.";
$cfg['BodyBorderSize']['default'] = "0";

// BodySpacingVertical
$cfg['BodySpacingVertical']['section'] = "27";
$cfg['BodySpacingVertical']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BodySpacingVertical']['type'] = "simplemenu";
$cfg['BodySpacingVertical']['help'] = "Select the vertical spacing in pixels above the body section";
$cfg['BodySpacingVertical']['default'] = "10";

// BodySpacingHorizontal
$cfg['BodySpacingHorizontal']['section'] = "27";
$cfg['BodySpacingHorizontal']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BodySpacingHorizontal']['type'] = "simplemenu";
$cfg['BodySpacingHorizontal']['help'] = "Select the horizontal spacing in pixels between the body and left/right navigation";
$cfg['BodySpacingHorizontal']['default'] = "10";

// BodyPadding
$cfg['BodyPadding']['section'] = "27";
$cfg['BodyPadding']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BodyPadding']['type'] = "simplemenu";
$cfg['BodyPadding']['help'] = "Select the padding in pixels for the body section";
$cfg['BodyPadding']['default'] = "8";

// BoxSpacingVertical
$cfg['BoxSpacingVertical']['section'] = "27";
$cfg['BoxSpacingVertical']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BoxSpacingVertical']['type'] = "simplemenu";
$cfg['BoxSpacingVertical']['help'] = "Select the vertical spacing in pixels between boxes (e.g. category box, custom content boxes, etc)";
$cfg['BoxSpacingVertical']['default'] = "10";

// BoxSpacingHorizontal
$cfg['BoxSpacingHorizontal']['section'] = "27";
$cfg['BoxSpacingHorizontal']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['BoxSpacingHorizontal']['type'] = "simplemenu";
$cfg['BoxSpacingHorizontal']['help'] = "Select the horzontal spacing in pixels between the outside edge of boxes (e.g. category box, custom content boxes, etc)";
$cfg['BoxSpacingHorizontal']['default'] = "10";

// LineSize
$cfg['LineSize']['section'] = "27";
$cfg['LineSize']['list'] = Array('1', '2', '3', '4');
$cfg['LineSize']['type'] = "simplemenu";
$cfg['LineSize']['help'] = "In various places, separator lines are used to make it easier for the eye to break apart different sections. Select the size of these lines. In previous versions this was always set at 1.";
$cfg['LineSize']['default'] = "2";

// LineType
$cfg['LineType']['section'] = "27";
$cfg['LineType']['list'] = Array('dotted', 'dashed', 'solid');
$cfg['LineType']['type'] = "simplemenu";
$cfg['LineType']['help'] = "In various places, separator lines are used to make it easier for the eye to break apart different sections. Select the type of lines you want to use. In previous versions this was always set to dotted.";
$cfg['LineType']['default'] = "dashed";

// BreadcrumbSeparator
$cfg['BreadcrumbSeparator']['section'] = "27";
$cfg['BreadcrumbSeparator']['type'] = "complexmenu";
$cfg['BreadcrumbSeparator']['list'] = Array(
	'ra' => '&raquo;',
	'a' => '&gt;',
	':' => ':',
	'::' => '::',
	'~' => '~',
	'/' => '/',
	);
$cfg['BreadcrumbSeparator']['help'] = "Used to separate breadcrumb links";
$cfg['BreadcrumbSeparator']['default'] = "ra";

// Bullet
$cfg['Bullet']['section'] = "27";
$cfg['Bullet']['type'] = "textinput";
$cfg['Bullet']['help'] = "Enter the bullet HTML to use in box listings (e.g. characters or even image references)";
$cfg['Bullet']['default'] = "&#8226;";

// Corners
$cfg['Corners']['section'] = "27";
$cfg['Corners']['type'] = "complexmenu";
$cfg['Corners']['list'] = Array('s' => 'Squared', 'r' => 'Rounded');
$cfg['Corners']['help'] = "Whether to use Squared or Rounded corners for box and body elements.";
$cfg['Corners']['default'] = "r";

// DisplayTabs
$cfg['DisplayTabs']['section'] = "17";
$cfg['DisplayTabs']['list'] = Array('Yes', 'No');
$cfg['DisplayTabs']['type'] = "radio";
$cfg['DisplayTabs']['help'] = "Whether you want to display the category Tabs";
$cfg['DisplayTabs']['default'] = "Yes";

// DisplayHomeTab
$cfg['DisplayHomeTab']['section'] = "17";
$cfg['DisplayHomeTab']['list'] = Array('Yes', 'No');
$cfg['DisplayHomeTab']['type'] = "radio";
$cfg['DisplayHomeTab']['help'] = "Whether you want to display the Home tab";
$cfg['DisplayHomeTab']['default'] = "Yes";

// TabStyle
$cfg['TabStyle']['section'] = "17";
$cfg['TabStyle']['list'] = Array(
	'style_01' => 'Rounded',
	'style_02' => 'Square',
	'style_00' => 'Custom',
	);
$cfg['TabStyle']['type'] = "complexmenu";
$cfg['TabStyle']['help'] = "This is the style of the category Tabs. <b>Note:</b> You can further customize the look and feel within the CSS file cfg.css.php. The Custom style is completely controlled in this way.";
$cfg['TabStyle']['default'] = "style_01";

// TabBorderColor
$cfg['TabBorderColor']['section'] = "17";
$cfg['TabBorderColor']['type'] = "color";
$cfg['TabBorderColor']['help'] = "Choose the tab border color";
$cfg['TabBorderColor']['default'] = "#000000";
$cfg['TabBorderColor']['required'] = TRUE;

// TabSpacing
$cfg['TabSpacing']['section'] = "17";
$cfg['TabSpacing']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15');
$cfg['TabSpacing']['type'] = "simplemenu";
$cfg['TabSpacing']['help'] = "This is the horizontal spacing (in pixels) between each category Tab";
$cfg['TabSpacing']['default'] = "0";

/*
// TabsPerRow
$cfg['TabsPerRow']['section'] = "17";
$cfg['TabsPerRow']['list'] = Array('Dynamic', '20', '19', '18', '17', '16', '15', '14', '13', '12', '11', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1');
$cfg['TabsPerRow']['type'] = "simplemenu";
$cfg['TabsPerRow']['help'] = "This is the number of category Tabs to display per row. If Dynamic is selected, then the number of rows will be determined by the width of the browser window.";
$cfg['TabsPerRow']['default'] = "Dynamic";
*/

// DisplayAmazonRefs
$cfg['DisplayAmazonRefs']['section'] = "14";
$cfg['DisplayAmazonRefs']['list'] = Array('Yes', 'No');
$cfg['DisplayAmazonRefs']['type'] = "radio";
$cfg['DisplayAmazonRefs']['help'] = "Whether you want to display references to Amazon within your store pages, where applicable";
$cfg['DisplayAmazonRefs']['default'] = "Yes";

// DisplaySearchBar
$cfg['DisplaySearchBar']['section'] = "14";
$cfg['DisplaySearchBar']['list'] = Array('Yes', 'No');
$cfg['DisplaySearchBar']['type'] = "radio";
$cfg['DisplaySearchBar']['help'] = "Whether you want to display the search bar which includes the search box and links to Advanced Search, View Cart and Checkout. <b>Note:</b> If you set this to No, you will need to create your own links to the Advanced Search, View Cart and Checkout pages.";
$cfg['DisplaySearchBar']['default'] = "Yes";

// DisplaySearchAllOption
$cfg['DisplaySearchAllOption']['section'] = "13";
$cfg['DisplaySearchAllOption']['list'] = Array('Yes', 'No');
$cfg['DisplaySearchAllOption']['type'] = "radio";
$cfg['DisplaySearchAllOption']['help'] = "Whether you want to display the 'All Products' option in the search bar drop down box. If set to no, your first category will be the default. <b>Note:</b> This can be useful in situations where your store categories are under one Amazon category (vertical) and the 'All Products' results are combined.";
$cfg['DisplaySearchAllOption']['default'] = "Yes";

// DisplaySitemapLink
$cfg['DisplaySitemapLink']['section'] = "14";
$cfg['DisplaySitemapLink']['list'] = Array('Yes', 'No');
$cfg['DisplaySitemapLink']['type'] = "radio";
$cfg['DisplaySitemapLink']['help'] = "Whether you want to display the 'Sitemap' link. <b>Note:</b> The sitemap is a page which features links to the main pages of your site (e.g. Categories, Custom Pages, etc.).";
$cfg['DisplaySitemapLink']['default'] = "Yes";

// DisplayCheckoutLink
$cfg['DisplayCheckoutLink']['section'] = "14";
$cfg['DisplayCheckoutLink']['list'] = Array('Yes', 'No');
$cfg['DisplayCheckoutLink']['type'] = "radio";
$cfg['DisplayCheckoutLink']['help'] = "Whether you want to display the 'Checkout' link. If set to no, there will still be a Checkout button on the View Cart page.";
$cfg['DisplayCheckoutLink']['default'] = "Yes";

// DisplayViewCartLink
$cfg['DisplayViewCartLink']['section'] = "14";
$cfg['DisplayViewCartLink']['list'] = Array('Yes', 'No');
$cfg['DisplayViewCartLink']['type'] = "radio";
$cfg['DisplayViewCartLink']['help'] = "Whether you want to display the 'View Cart' link. If set to no, you will need to create your own link to the View Cart page.";
$cfg['DisplayViewCartLink']['default'] = "Yes";

// DisplaySortBy
$cfg['DisplaySortBy']['section'] = "14";
$cfg['DisplaySortBy']['list'] = Array('Yes', 'No');
$cfg['DisplaySortBy']['type'] = "radio";
$cfg['DisplaySortBy']['help'] = "Whether you want to display the Sort By selection menu on Category and Subcategory pages.";
$cfg['DisplaySortBy']['default'] = "Yes";

// DisplayCrossSellLinks
$cfg['DisplayCrossSellLinks']['section'] = "14";
$cfg['DisplayCrossSellLinks']['list'] = Array('Yes', 'No');
$cfg['DisplayCrossSellLinks']['type'] = "radio";
$cfg['DisplayCrossSellLinks']['help'] = "Whether you want to display the Cross Selling Links such as authors, actors, etc (where available, these would be found on individual item pages)";
$cfg['DisplayCrossSellLinks']['default'] = "Yes";

// DisplaySimilarItems
$cfg['DisplaySimilarItems']['section'] = "14";
$cfg['DisplaySimilarItems']['list'] = Array('Yes', 'No');
$cfg['DisplaySimilarItems']['type'] = "radio";
$cfg['DisplaySimilarItems']['help'] = "Whether you want to display links to Similar Items (where available, these would be listed on individual item pages)";
$cfg['DisplaySimilarItems']['default'] = "Yes";

// DisplayAccessories
$cfg['DisplayAccessories']['section'] = "14";
$cfg['DisplayAccessories']['list'] = Array('Yes', 'No');
$cfg['DisplayAccessories']['type'] = "radio";
$cfg['DisplayAccessories']['help'] = "Whether you want to display links to Accessories (where available, these would be listed on individual item pages)";
$cfg['DisplayAccessories']['default'] = "Yes";

// DisplayCollections
$cfg['DisplayCollections']['section'] = "14";
$cfg['DisplayCollections']['list'] = Array('Yes', 'No');
$cfg['DisplayCollections']['type'] = "radio";
$cfg['DisplayCollections']['help'] = "Whether you want to display Collections on item pages (e.g. this would be things that come in sets such as dishes, furniture, clothing etc.";
$cfg['DisplayCollections']['default'] = "Yes";

// DisplayAlternateVersions
$cfg['DisplayAlternateVersions']['section'] = "14";
$cfg['DisplayAlternateVersions']['list'] = Array('Yes', 'No');
$cfg['DisplayAlternateVersions']['type'] = "radio";
$cfg['DisplayAlternateVersions']['help'] = "Whether you want to display links to the Alternate Versions of books (e.g. Audio, Hardback, etc - where available, these would be listed on individual item pages)";
$cfg['DisplayAlternateVersions']['default'] = "Yes";

// DisplayPromotions
$cfg['DisplayPromotions']['section'] = "14";
$cfg['DisplayPromotions']['list'] = Array('Yes', 'No');
$cfg['DisplayPromotions']['type'] = "radio";
$cfg['DisplayPromotions']['help'] = "Whether you want to display Promotions/Coupons/Rebate information on item pages";
$cfg['DisplayPromotions']['default'] = "Yes";

// DisplayFeatures
$cfg['DisplayFeatures']['section'] = "14";
$cfg['DisplayFeatures']['list'] = Array('Yes', 'No');
$cfg['DisplayFeatures']['type'] = "radio";
$cfg['DisplayFeatures']['help'] = "Whether you want to display Features on the item detail pages";
$cfg['DisplayFeatures']['default'] = "Yes";

// DisplayEditorialReviews
$cfg['DisplayEditorialReviews']['section'] = "32";
$cfg['DisplayEditorialReviews']['list'] = Array('Yes', 'No');
$cfg['DisplayEditorialReviews']['type'] = "radio";
$cfg['DisplayEditorialReviews']['help'] = "Whether you want to display Editorial Reviews on the item detail pages";
$cfg['DisplayEditorialReviews']['default'] = "Yes";

// DisplayCustomerReviews
$cfg['DisplayCustomerReviews']['section'] = "32";
$cfg['DisplayCustomerReviews']['list'] = Array('Yes', 'No');
$cfg['DisplayCustomerReviews']['type'] = "radio";
$cfg['DisplayCustomerReviews']['help'] = "Whether you want to display Customer Reviews on the item detail pages";
$cfg['DisplayCustomerReviews']['default'] = "Yes";

// ReviewBoxWidth
$cfg['ReviewBoxWidth']['section'] = "32";
$cfg['ReviewBoxWidth']['type'] = "number";
$cfg['ReviewBoxWidth']['help'] = "Enter a width (integer) for the Customer Reviews box (default 100%)";
$cfg['ReviewBoxWidth']['default'] = "100%";
$cfg['ReviewBoxWidth']['required'] = TRUE;

// ReviewBoxHeight
$cfg['ReviewBoxHeight']['section'] = "32";
$cfg['ReviewBoxHeight']['type'] = "number";
$cfg['ReviewBoxHeight']['help'] = "Enter a height (integer) for the Customer Reviews box (default 550 pixels)";
$cfg['ReviewBoxHeight']['default'] = "550";
$cfg['ReviewBoxHeight']['required'] = TRUE;

// DisplayWishlistLink
$cfg['DisplayWishlistLink']['section'] = "14";
$cfg['DisplayWishlistLink']['list'] = Array('Yes', 'No');
$cfg['DisplayWishlistLink']['type'] = "radio";
$cfg['DisplayWishlistLink']['help'] = "Whether you want to display a Wishlist link on the item detail pages. This link allows a visitor to add the item to their Amazon Wishlist. <b>Note:</b> This is an external link to Amazon's site. The link contains your Amazon Associate ID and will open in a new brower window.";
$cfg['DisplayWishlistLink']['default'] = "No";

// DisplayWeddingRegistryLink
$cfg['DisplayWeddingRegistryLink']['section'] = "14";
$cfg['DisplayWeddingRegistryLink']['list'] = Array('Yes', 'No');
$cfg['DisplayWeddingRegistryLink']['type'] = "radio";
$cfg['DisplayWeddingRegistryLink']['help'] = "Whether you want to display a Wedding Registry link on the item detail pages. This link allows a visitor to add the item to their Amazon Wedding Registry. <b>Note:</b> This is an external link to Amazon's site. The link contains your Amazon Associate ID and will open in a new brower window.";
$cfg['DisplayWeddingRegistryLink']['default'] = "No";

// DisplayBabyRegistryLink
$cfg['DisplayBabyRegistryLink']['section'] = "14";
$cfg['DisplayBabyRegistryLink']['list'] = Array('Yes', 'No');
$cfg['DisplayBabyRegistryLink']['type'] = "radio";
$cfg['DisplayBabyRegistryLink']['help'] = "Whether you want to display a Baby Registry link on the item detail pages. This link allows a visitor to add the item to their Amazon Baby Registry. <b>Note:</b> This is an external link to Amazon's site. The link contains your Amazon Associate ID and will open in a new brower window.";
$cfg['DisplayBabyRegistryLink']['default'] = "No";

// DisplayTellAFriendLink
$cfg['DisplayTellAFriendLink']['section'] = "14";
$cfg['DisplayTellAFriendLink']['list'] = Array('Yes', 'No');
$cfg['DisplayTellAFriendLink']['type'] = "radio";
$cfg['DisplayTellAFriendLink']['help'] = "Whether you want to display a Tell A Freind link on the item detail pages. This link allows a visitor tell their friends about an Amazon item. <b>Note:</b> This is an external link to Amazon's site. The link contains your Amazon Associate ID and will open in a new brower window.";
$cfg['DisplayTellAFriendLink']['default'] = "No";

// DisplaySoldBy
$cfg['DisplaySoldBy']['section'] = "14";
$cfg['DisplaySoldBy']['list'] = Array('Yes', 'No');
$cfg['DisplaySoldBy']['type'] = "radio";
$cfg['DisplaySoldBy']['help'] = "Whether you want to display the item Seller (if known) on the item detail pages.";
$cfg['DisplaySoldBy']['default'] = "Yes";

// DisplayInStock
$cfg['DisplayInStock']['section'] = "14";
$cfg['DisplayInStock']['list'] = Array('Yes', 'No');
$cfg['DisplayInStock']['type'] = "radio";
$cfg['DisplayInStock']['help'] = "Whether you want to display the 'In Stock' message next to buy buttons.";
$cfg['DisplayInStock']['default'] = "Yes";

// DisplayBreadcrumbs
$cfg['DisplayBreadcrumbs']['section'] = "14";
$cfg['DisplayBreadcrumbs']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayBreadcrumbs']['type'] = "checkboxes";
$cfg['DisplayBreadcrumbs']['help'] = "Select the page types on which to display the Category and Subcategory location 'breadcrumb' trail";
$cfg['DisplayBreadcrumbs']['key'] = TRUE;

// DisplayListPrice
$cfg['DisplayListPrice']['section'] = "14";
$cfg['DisplayListPrice']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayListPrice']['type'] = "checkboxes";
$cfg['DisplayListPrice']['help'] = "Select the page types on which to display List Prices (e.g. List Price...)";
$cfg['DisplayListPrice']['key'] = TRUE;

// DisplaySavingsPrice
$cfg['DisplaySavingsPrice']['section'] = "14";
$cfg['DisplaySavingsPrice']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplaySavingsPrice']['type'] = "checkboxes";
$cfg['DisplaySavingsPrice']['help'] = "Select the page types on which to display Savings Prices (e.g. You Save...)";
$cfg['DisplaySavingsPrice']['key'] = TRUE;

// DisplaySalePrice
$cfg['DisplaySalePrice']['section'] = "14";
$cfg['DisplaySalePrice']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplaySalePrice']['type'] = "checkboxes";
$cfg['DisplaySalePrice']['help'] = "Select the page types on which to display Sale Prices (e.g. On sale from...)";
$cfg['DisplaySalePrice']['key'] = TRUE;

// DisplayAsins
$cfg['DisplayAsins']['section'] = "14";
$cfg['DisplayAsins']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayAsins']['type'] = "checkboxes";
$cfg['DisplayAsins']['help'] = "Select the page types on which to display ASIN numbers (Amazon Item IDs)";
$cfg['DisplayAsins']['key'] = TRUE;

// DisplaySalesRank
$cfg['DisplaySalesRank']['section'] = "14";
$cfg['DisplaySalesRank']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplaySalesRank']['type'] = "checkboxes";
$cfg['DisplaySalesRank']['help'] = "Select the page types on which to display item Sales Rank";
$cfg['DisplaySalesRank']['key'] = TRUE;

// DisplayAvailability
$cfg['DisplayAvailability']['section'] = "14";
$cfg['DisplayAvailability']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayAvailability']['type'] = "checkboxes";
$cfg['DisplayAvailability']['help'] = "Select the page types on which to display item Availability";
$cfg['DisplayAvailability']['key'] = TRUE;

// DisplayCategory
$cfg['DisplayCategory']['section'] = "14";
$cfg['DisplayCategory']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayCategory']['type'] = "checkboxes";
$cfg['DisplayCategory']['help'] = "Select the page types on which to display item Category detail (e.g. Category: Books)";
$cfg['DisplayCategory']['key'] = TRUE;

// DisplayDate
$cfg['DisplayDate']['section'] = "14";
$cfg['DisplayDate']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayDate']['type'] = "checkboxes";
$cfg['DisplayDate']['help'] = "Select the page types on which to display item Release/Publication dates";
$cfg['DisplayDate']['key'] = TRUE;

// DisplayShipping
$cfg['DisplayShipping']['section'] = "14";
$cfg['DisplayShipping']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayShipping']['type'] = "checkboxes";
$cfg['DisplayShipping']['help'] = "Select the page types on which to display item Shipping details";
$cfg['DisplayShipping']['key'] = TRUE;

// DisplayConditionNote
$cfg['DisplayConditionNote']['section'] = "14";
$cfg['DisplayConditionNote']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items');
$cfg['DisplayConditionNote']['type'] = "checkboxes";
$cfg['DisplayConditionNote']['help'] = "Select the page types on which to display item Condition notes";
$cfg['DisplayConditionNote']['key'] = TRUE;

// TitleHome
$cfg['TitleHome']['section'] = "11";
$cfg['TitleHome']['type'] = "text";
$cfg['TitleHome']['help'] = "This is the Title format used on the homepage. Leave as is for the default (e.g. {SITE_NAME}: {SITE_SLOGAN}{PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['TitleHome']['default'] = "{SITE_NAME}: {SITE_SLOGAN}{PAGE}";
$cfg['TitleHome']['required'] = TRUE;

// TitleSearchAll
$cfg['TitleSearchAll']['section'] = "11";
$cfg['TitleSearchAll']['type'] = "text";
$cfg['TitleSearchAll']['help'] = "This is the Title format used when searching all categories. Leave as is for the default (e.g. {SITE_NAME}: {KEYWORD}{PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['TitleSearchAll']['default'] = "{SITE_NAME}: {KEYWORD}{PAGE}";
$cfg['TitleSearchAll']['required'] = TRUE;

// TitleSearch
$cfg['TitleSearch']['section'] = "11";
$cfg['TitleSearch']['type'] = "text";
$cfg['TitleSearch']['help'] = "This is the Title format used when searching a single category. Leave as is for the default (e.g. {SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME} {KEYWORD} {PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;(uses value returned by Amazon)<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['TitleSearch']['default'] = "{SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME} {KEYWORD} {PAGE}";
$cfg['TitleSearch']['required'] = TRUE;

// TitleCategory
$cfg['TitleCategory']['section'] = "11";
$cfg['TitleCategory']['type'] = "text";
$cfg['TitleCategory']['help'] = "This is the Title format used on category pages. Leave as is for the default (e.g. {SITE_NAME}: {CATEGORY_NAME}{PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['TitleCategory']['default'] = "{SITE_NAME}: {CATEGORY_NAME}{PAGE}";
$cfg['TitleCategory']['required'] = TRUE;

// TitleSubcategory
$cfg['TitleSubcategory']['section'] = "11";
$cfg['TitleSubcategory']['type'] = "text";
$cfg['TitleSubcategory']['help'] = "This is the Title format used on subcategory pages. Leave as is for the default (e.g. {SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME}{PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;(uses value returned by Amazon)<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['TitleSubcategory']['default'] = "{SITE_NAME}: {CATEGORY_NAME}: {SUBCATEGORY_NAME}{PAGE}";
$cfg['TitleSubcategory']['required'] = TRUE;

// TitleItem
$cfg['TitleItem']['section'] = "11";
$cfg['TitleItem']['type'] = "text";
$cfg['TitleItem']['help'] = "This is the Title format used on item pages. Leave as is for the default (e.g. {SITE_NAME}: {CATEGORY_NAME}: {ITEM_NAME} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ITEM_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number<br><br>";
$cfg['TitleItem']['default'] = "{SITE_NAME}: {CATEGORY_NAME}: {ITEM_NAME}";
$cfg['TitleItem']['required'] = TRUE;

// TitleMarketplace
$cfg['TitleMarketplace']['section'] = "11";
$cfg['TitleMarketplace']['type'] = "text";
$cfg['TitleMarketplace']['help'] = "This is the Title format used on review pages. Leave as is for the default (e.g. {SITE_NAME}: {ITEM_NAME} - {OFFERS}{PAGE} ) or enter the title variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ITEM_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><b>{OFFERS}</b>&nbsp;&nbsp;&nbsp;shows string from lang string #354 (e.g. \"Marketplace Offers\")<br><br>";
$cfg['TitleMarketplace']['default'] = "{SITE_NAME}: {ITEM_NAME} - {OFFERS}{PAGE}";
$cfg['TitleMarketplace']['required'] = TRUE;

// MetaDescriptionHome
$cfg['MetaDescriptionHome']['section'] = "22";
$cfg['MetaDescriptionHome']['type'] = "text";
$cfg['MetaDescriptionHome']['help'] = "This is the Meta Description format used on the homepage. Leave as is for the default (e.g. {SITE_DESCRIPTION}{PAGE} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['MetaDescriptionHome']['default'] = "{SITE_DESCRIPTION}{PAGE}";
$cfg['MetaDescriptionHome']['required'] = TRUE;

// MetaDescriptionSearchAll
$cfg['MetaDescriptionSearchAll']['section'] = "22";
$cfg['MetaDescriptionSearchAll']['type'] = "text";
$cfg['MetaDescriptionSearchAll']['help'] = "This is the Meta Description format used when searching all categories. Leave as is for the default (e.g. {KEYWORD} - {SITE_DESCRIPTION}{PAGE} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['MetaDescriptionSearchAll']['default'] = "{KEYWORD} - {SITE_DESCRIPTION}{PAGE}";
$cfg['MetaDescriptionSearchAll']['required'] = TRUE;

// MetaDescriptionSearch
$cfg['MetaDescriptionSearch']['section'] = "22";
$cfg['MetaDescriptionSearch']['type'] = "text";
$cfg['MetaDescriptionSearch']['help'] = "This is the Meta Description format used on item pages. Leave as is for the default (e.g. {KEYWORD} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['MetaDescriptionSearch']['default'] = "{KEYWORD} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE}";
$cfg['MetaDescriptionSearch']['required'] = TRUE;

// MetaDescriptionCategory
$cfg['MetaDescriptionCategory']['section'] = "22";
$cfg['MetaDescriptionCategory']['type'] = "text";
$cfg['MetaDescriptionCategory']['help'] = "This is the Meta Description format used on item pages. Leave as is for the default (e.g. {CATEGORY_NAME} - {CATEGORY_DESCRIPTION} - {SITE_DESCRIPTION}{PAGE} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{CATEGORY_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses Category Descriptions if set up<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['MetaDescriptionCategory']['default'] = "{CATEGORY_NAME} - {CATEGORY_DESCRIPTION} - {SITE_DESCRIPTION}{PAGE}";
$cfg['MetaDescriptionCategory']['required'] = TRUE;

// MetaDescriptionSubcategory
$cfg['MetaDescriptionSubcategory']['section'] = "22";
$cfg['MetaDescriptionSubcategory']['type'] = "text";
$cfg['MetaDescriptionSubcategory']['help'] = "This is the Meta Description format used on item pages. Leave as is for the default (e.g. {SUBCATEGORY_NAME} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{PAGE}</b>&nbsp;&nbsp;&nbsp;shows page number (e.g. \"Page 3\") based on lang string #351<br><br>";
$cfg['MetaDescriptionSubcategory']['default'] = "{SUBCATEGORY_NAME} - {CATEGORY_NAME} - {SITE_DESCRIPTION}{PAGE}";
$cfg['MetaDescriptionSubcategory']['required'] = TRUE;

// MetaDescriptionItem
$cfg['MetaDescriptionItem']['section'] = "22";
$cfg['MetaDescriptionItem']['type'] = "text";
$cfg['MetaDescriptionItem']['help'] = "This is the Meta Description format used on item pages. Leave as is for the default (e.g. {ITEM_NAME} - {EDITORIAL_REVIEW} - {SUBCATEGORY_NAME} - {CATEGORY_NAME} ) or enter the Meta Description variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ITEM_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{EDITORIAL_REVIEW}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon (up to 200 characters)<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><br>";
$cfg['MetaDescriptionItem']['default'] = "{ITEM_NAME} - {EDITORIAL_REVIEW} - {SUBCATEGORY_NAME} - {CATEGORY_NAME}";
$cfg['MetaDescriptionItem']['required'] = TRUE;

// MetaKeywordsHome
$cfg['MetaKeywordsHome']['section'] = "21";
$cfg['MetaKeywordsHome']['type'] = "text";
$cfg['MetaKeywordsHome']['help'] = "This is the Meta Keywords format used on the homepage. Leave as is for the default (e.g. {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><br>";
$cfg['MetaKeywordsHome']['default'] = "{SITE_KEYWORDS}";
$cfg['MetaKeywordsHome']['required'] = TRUE;

// MetaKeywordsSearchAll
$cfg['MetaKeywordsSearchAll']['section'] = "21";
$cfg['MetaKeywordsSearchAll']['type'] = "text";
$cfg['MetaKeywordsSearchAll']['help'] = "This is the Meta Keywords format used when searching a all categories. Leave as is for the default (e.g. {KEYWORD}, {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><br>";
$cfg['MetaKeywordsSearchAll']['default'] = "{KEYWORD}, {SITE_KEYWORDS}";
$cfg['MetaKeywordsSearchAll']['required'] = TRUE;

// MetaKeywordsSearch
$cfg['MetaKeywordsSearch']['section'] = "21";
$cfg['MetaKeywordsSearch']['type'] = "text";
$cfg['MetaKeywordsSearch']['help'] = "This is the Meta Keywords format used on item pages. Leave as is for the default (e.g. {KEYWORD}, {CATEGORY_NAME}, {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{KEYWORD}</b>&nbsp;&nbsp;&nbsp;uses keyword entered by user<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><br>";
$cfg['MetaKeywordsSearch']['default'] = "{KEYWORD}, {CATEGORY_NAME}, {SITE_KEYWORDS}";
$cfg['MetaKeywordsSearch']['required'] = TRUE;

// MetaKeywordsCategory
$cfg['MetaKeywordsCategory']['section'] = "21";
$cfg['MetaKeywordsCategory']['type'] = "text";
$cfg['MetaKeywordsCategory']['help'] = "This is the Meta Keywords format used on item pages. Leave as is for the default (e.g. {CATEGORY_NAME}, {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SUBCATEGORIES}</b>&nbsp;&nbsp;&nbsp;uses first 5 subcategories (if available)<br><b>{BRANDS}</b>&nbsp;&nbsp;&nbsp;uses first 5 brands (if available)<br><b>{ITEMS}</b>&nbsp;&nbsp;&nbsp;uses first 5 item titles<br><br>";
$cfg['MetaKeywordsCategory']['default'] = "{CATEGORY_NAME}, {SITE_KEYWORDS}";
$cfg['MetaKeywordsCategory']['required'] = TRUE;

// MetaKeywordsSubcategory
$cfg['MetaKeywordsSubcategory']['section'] = "21";
$cfg['MetaKeywordsSubcategory']['type'] = "text";
$cfg['MetaKeywordsSubcategory']['help'] = "This is the Meta Keywords format used on item pages. Leave as is for the default (e.g. {SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SUBCATEGORIES}</b>&nbsp;&nbsp;&nbsp;uses first 5 subcategories (if available)<br><b>{BRANDS}</b>&nbsp;&nbsp;&nbsp;uses first 5 brands (if available)<br><b>{ITEMS}</b>&nbsp;&nbsp;&nbsp;uses first 5 item titles<br><br>";
$cfg['MetaKeywordsSubcategory']['default'] = "{SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS}";
$cfg['MetaKeywordsSubcategory']['required'] = TRUE;

// MetaKeywordsItem
$cfg['MetaKeywordsItem']['section'] = "21";
$cfg['MetaKeywordsItem']['type'] = "text";
$cfg['MetaKeywordsItem']['help'] = "This is the Meta Keywords format used on item pages. Leave as is for the default (e.g. {ITEM_NAME}, {SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS} ) or enter the Meta Keywords variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{CATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses applicable category name<br><b>{SUBCATEGORY_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ITEM_NAME}</b>&nbsp;&nbsp;&nbsp;uses value returned by Amazon<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number<br><b>{SITE_KEYWORDS}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_DESCRIPTION}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{SITE_SLOGAN}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{RELATED_CATEGORIES}</b>&nbsp;&nbsp;&nbsp;uses first 5 related categories (if available)<br><br>";
$cfg['MetaKeywordsItem']['default'] = "{ITEM_NAME}, {SUBCATEGORY_NAME}, {CATEGORY_NAME}, {SITE_KEYWORDS}";
$cfg['MetaKeywordsItem']['required'] = TRUE;

// ShoppingCart
$cfg['ShoppingCart']['section'] = "7";
$cfg['ShoppingCart']['list'] = Array('Yes', 'No');
$cfg['ShoppingCart']['type'] = "radio";
$cfg['ShoppingCart']['help'] = "Whether or not to use the built-in shopping cart. If, Yes, items will be added to the built-in cart and at checkout the cart contents are dumped into the Amazon shopping cart. If, No, the buy buttons will open a new browser window pointing to the specific product page on Amazon's site. Whether you use the built-in cart or not, eventually the shopper will do final checkout on Amazon's site.";
$cfg['ShoppingCart']['default'] = "Yes";
$cfg['ShoppingCart']['required'] = false;

// ShoppingCartInstructions
$cfg['ShoppingCartInstructions']['section'] = "7";
$cfg['ShoppingCartInstructions']['type'] = "textarea";
$cfg['ShoppingCartInstructions']['help'] = "If Shopping Cart is enabled above, this HTML will be presented on the view cart screen (<b>above</b> the cart contents and before checkout at Amazon). This is a good place to put any instructions or other messages.";

// ShoppingCartInstructions2
$cfg['ShoppingCartInstructions2']['section'] = "7";
$cfg['ShoppingCartInstructions2']['type'] = "textarea";
$cfg['ShoppingCartInstructions2']['help'] = "If Shopping Cart is enabled above, this HTML will be presented on the view cart screen (<b>below</b> the cart contents). This is a good place to put any instructions or other messages.";

// DisplayImageColumn
$cfg['DisplayImageColumn']['section'] = "7";
$cfg['DisplayImageColumn']['list'] = Array('Yes', 'No');
$cfg['DisplayImageColumn']['type'] = "radio";
$cfg['DisplayImageColumn']['help'] = "Whether you want to display a representative image/photo for items in the shopping cart";
$cfg['DisplayImageColumn']['default'] = "Yes";

// DisplayCategoryColumn
$cfg['DisplayCategoryColumn']['section'] = "7";
$cfg['DisplayCategoryColumn']['list'] = Array('Yes', 'No');
$cfg['DisplayCategoryColumn']['type'] = "radio";
$cfg['DisplayCategoryColumn']['help'] = "Whether you want to display the Category column in the shopping cart";
$cfg['DisplayCategoryColumn']['default'] = "Yes";

// DisplaySellerColumn
$cfg['DisplaySellerColumn']['section'] = "7";
$cfg['DisplaySellerColumn']['list'] = Array('Yes', 'No');
$cfg['DisplaySellerColumn']['type'] = "radio";
$cfg['DisplaySellerColumn']['help'] = "Whether you want to display the Seller column in the shopping cart";
$cfg['DisplaySellerColumn']['default'] = "No";

// DisplayCartSimilarItems
$cfg['DisplayCartSimilarItems']['section'] = "7";
$cfg['DisplayCartSimilarItems']['list'] = Array('Yes', 'No');
$cfg['DisplayCartSimilarItems']['type'] = "radio";
$cfg['DisplayCartSimilarItems']['help'] = "Whether you want to display links to Similar Items in the shopping cart";
$cfg['DisplayCartSimilarItems']['default'] = "Yes";

// DisplayCartSimilarViewedItems
$cfg['DisplayCartSimilarViewedItems']['section'] = "7";
$cfg['DisplayCartSimilarViewedItems']['list'] = Array('Yes', 'No');
$cfg['DisplayCartSimilarViewedItems']['type'] = "radio";
$cfg['DisplayCartSimilarViewedItems']['help'] = "Whether you want to display links to Similar Viewed Items in the shopping cart";
$cfg['DisplayCartSimilarViewedItems']['default'] = "No";

// DisplayCartBestsellers
$cfg['DisplayCartBestsellers']['section'] = "7";
$cfg['DisplayCartBestsellers']['list'] = Array('Yes', 'No');
$cfg['DisplayCartBestsellers']['type'] = "radio";
$cfg['DisplayCartBestsellers']['help'] = "Whether you want to display links to Bestselling Items related to Items in the shopping cart";
$cfg['DisplayCartBestsellers']['default'] = "No";

// DisplayCartNewReleases
$cfg['DisplayCartNewReleases']['section'] = "7";
$cfg['DisplayCartNewReleases']['list'] = Array('Yes', 'No');
$cfg['DisplayCartNewReleases']['type'] = "radio";
$cfg['DisplayCartNewReleases']['help'] = "Whether you want to display links to Newly Released Items related to Items in the shopping cart";
$cfg['DisplayCartNewReleases']['default'] = "No";

// BuyButtonLocations
$cfg['BuyButtonLocations']['section'] = "7";
$cfg['BuyButtonLocations']['list'] = Array('C1' => 'Category Pages (Usual Places)', 'I1' => 'Item Pages (Usual Place)', 'I2' => 'Item Pages (Bottom)');
$cfg['BuyButtonLocations']['type'] = "checkboxes";
$cfg['BuyButtonLocations']['key'] = TRUE;
$cfg['BuyButtonLocations']['help'] = "Select the Buy button locations for buy/add-to-cart buttons on Item/Category pages";
$cfg['BuyButtonLocations']['default'] = Array('C1', 'I1');
$cfg['BuyButtonLocations']['required'] = TRUE;

// BuyButtonQuantity
$cfg['BuyButtonQuantity']['section'] = "7";
$cfg['BuyButtonQuantity']['list'] = Array('Yes', 'No');
$cfg['BuyButtonQuantity']['type'] = "radio";
$cfg['BuyButtonQuantity']['help'] = "Whether you want to display the quantity box and in stock count along with buy buttons. Otherwise quantity is defaulted to 1.";
$cfg['BuyButtonQuantity']['default'] = "No";

// BuyButtonQuantityRange
$cfg['BuyButtonQuantityRange']['section'] = "7";
$cfg['BuyButtonQuantityRange']['type'] = "range";
$cfg['BuyButtonQuantityRange']['help'] = "If you have <b>Buy Button Quantity</b> above set to <b>Yes</b>, this is the Minimum/Maximum quantity that will trigger the display of the quantity box. Leave blank to always show the quantity box.";

// BuyButtonType
$cfg['BuyButtonType']['section'] = "7";
$cfg['BuyButtonType']['list'] = Array('product' => 'Amazon Product Page', 'cart' => 'Amazon Shopping Cart');
$cfg['BuyButtonType']['type'] = "complexmenu";
$cfg['BuyButtonType']['help'] = "When using the Lite version or when using the Full version with the built-in Shopping Cart turned off, this controls whether buy buttons go to the Amazon product page or Amazon shopping cart.";
$cfg['BuyButtonType']['default'] = "product";

// BuyButtonNewWindow
$cfg['BuyButtonNewWindow']['section'] = "7";
$cfg['BuyButtonNewWindow']['list'] = Array('_blank' => 'Yes', '_self' => 'No');
$cfg['BuyButtonNewWindow']['type'] = "complexmenu";
$cfg['BuyButtonNewWindow']['help'] = "When using the Lite version or when the built-in Shopping Cart is turned off in the Full version, this controls whether or not a new browser window is opened when someone clicks the buy button to go to Amazon.";
$cfg['BuyButtonNewWindow']['default'] = "_blank";

// BuyButtonViewCart
$cfg['BuyButtonViewCart']['section'] = "7";
$cfg['BuyButtonViewCart']['list'] = Array('Yes', 'No');
$cfg['BuyButtonViewCart']['type'] = "radio";
$cfg['BuyButtonViewCart']['help'] = "When the built-in Shopping Cart is turned on, this controls whether or not the buyer is redirected to the view cart screen when clicking a buy button. If set to No, a popup will tell them the item was added to the cart.";
$cfg['BuyButtonViewCart']['default'] = "Yes";

// CheckoutNewWindow
$cfg['CheckoutNewWindow']['section'] = "7";
$cfg['CheckoutNewWindow']['list'] = Array('_blank' => 'Yes', '_self' => 'No');
$cfg['CheckoutNewWindow']['type'] = "complexmenu";
$cfg['CheckoutNewWindow']['help'] = "When using the built-in Shopping Cart, this controls whether or not a new browser window is opened when someone clicks the checkout button/link to go to Amazon.";
$cfg['CheckoutNewWindow']['default'] = "_self";

// DisplayQuantityInStock
$cfg['DisplayQuantityInStock']['section'] = "7";
$cfg['DisplayQuantityInStock']['list'] = Array('Yes', 'No');
$cfg['DisplayQuantityInStock']['type'] = "radio";
$cfg['DisplayQuantityInStock']['help'] = "Whether you want to display the actual quantity next to the 'In Stock' message (if known).";
$cfg['DisplayQuantityInStock']['default'] = "No";

// CartBgColorOdd
$cfg['CartBgColorOdd']['section'] = "7";
$cfg['CartBgColorOdd']['type'] = "color";
$cfg['CartBgColorOdd']['help'] = "Choose the background color for odd numbered rows in the cart";
$cfg['CartBgColorOdd']['default'] = "#FFFFFF";
$cfg['CartBgColorOdd']['required'] = TRUE;

// CartBgColorEven
$cfg['CartBgColorEven']['section'] = "7";
$cfg['CartBgColorEven']['type'] = "color";
$cfg['CartBgColorEven']['help'] = "Choose the background color for even numbered rows in the cart";
$cfg['CartBgColorEven']['default'] = "#F5F5F5";
$cfg['CartBgColorEven']['required'] = TRUE;

// MiniCartBox
$cfg['MiniCartBox']['section'] = "7";
$cfg['MiniCartBox']['type'] = "box";
$cfg['MiniCartBox']['display']['list'] = Array('Yes', 'No');
$cfg['MiniCartBox']['display']['default'] = "No";
$cfg['MiniCartBox']['location']['list'] = Array('L', 'R', 'C1');
$cfg['MiniCartBox']['location']['default'] = "L";
$cfg['MiniCartBox']['displaypages']['list'] = Array('H' => 'Home', 'L' => 'Categories', 'S' => 'Subcategories', 'I' => 'Items', 'CP' => 'Custom Pages', 'SA' => 'Search All');
$cfg['MiniCartBox']['order']['default'] = "";
$cfg['MiniCartBox']['bordersize']['list'] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
$cfg['MiniCartBox']['bordersize']['default'] = "1";
$cfg['MiniCartBox']['bordercolor']['default'] = "#CCCCCC";
$cfg['MiniCartBox']['bgcolor']['default'] = "#FFFFFF";
$cfg['MiniCartBox']['label'] = "Shopping Cart";
$cfg['MiniCartBox']['help'] = "Displays dynamic shopping cart contents as a person shops. For Location: L=Left, R=Right, C1=Category Page Top Right. <b>Note:</b> The Mini Cart Box displays only when it contains items.";

// ReportsEmailTo
$cfg['ReportsEmailTo']['section'] = "12";
$cfg['ReportsEmailTo']['type'] = "text";
$cfg['ReportsEmailTo']['help'] = "If entered, this is To: email address where your store will automatically send reports";

// ReportsEmailFrom
$cfg['ReportsEmailFrom']['section'] = "12";
$cfg['ReportsEmailFrom']['type'] = "text";
$cfg['ReportsEmailFrom']['help'] = "If entered, this is the From: email address that will be used for your store reports. If left blank, the To: address above will be used as the From: address";

// ReportsEmailHeader
$cfg['ReportsEmailHeader']['section'] = "12";
$cfg['ReportsEmailHeader']['type'] = "text";
$cfg['ReportsEmailHeader']['help'] = "On some servers you may need to enter additional header information so that emails sends properly (e.g. -f email@yourdomain.com)";

// ReportsTitle
$cfg['ReportsTitle']['section'] = "12";
$cfg['ReportsTitle']['type'] = "text";
$cfg['ReportsTitle']['help'] = "This is the subject format that will be used in emailed reports. Leave as is for the default or enter the variables you want displayed, in the order you want them displayed along with any static text.<br><br><b>Available Variables</b>:<br><b>{REPORT}</b>&nbsp;&nbsp;&nbsp;uses the applicable report name<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{ASSOCIATE_ID}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{DATE}</b>&nbsp;&nbsp;&nbsp;uses format YYYY-MM-DD<br><b>{TIME}</b>&nbsp;&nbsp;&nbsp;uses format HH:MM:SS<br><b>{IP}</b>&nbsp;&nbsp;&nbsp;uses IP address of site visitor<br><b>{SUBTOTAL}</b>&nbsp;&nbsp;&nbsp;uses the subtotal of the cart contents (where applicable)<br><br>";
$cfg['ReportsTitle']['default'] = "{SITE_NAME} ({ASSOCIATE_ID}): Associate-O-Matic {REPORT} Report ({DATE} {TIME})";

// Reports
$cfg['Reports']['section'] = "12";
$cfg['Reports']['list'] = Array('R1' => 'Cart Checkout', 'R2' => 'Cart Add', 'R3' => 'Invalid Item', 'R4' => 'Invalid Category');
$cfg['Reports']['type'] = "checkboxes";
$cfg['Reports']['key'] = TRUE;
$cfg['Reports']['help'] = "Choose the reports you would like sent to your email above:<br><br><b>Cart Checkout</b> You will be sent remote cart content information in real-time, as visitors checkout from your site to Amazon. This does not mean they will complete the purchase, but it does give you an idea of what people are putting in their carts and what they might purchase.<br><br><b>Cart Add</b> You will be sent remote cart content information in real-time, as visitors add items to their shopping cart (on your site).<br><br><b>Invalid Item</b> You will be sent an email if Items (ASINs) you've setup for your homepage or ASIN-related categories/subcategories become invalid.<br><br><b>Invalid Category</b> You will be sent an email if Categories (Browse Nodes) you've setup in your store become invalid.<br><br>";
$cfg['Reports']['default'] = "R1";

// GoogleTrackingId
$cfg['GoogleTrackingId']['section'] = "7";
$cfg['GoogleTrackingId']['type'] = "text";
$cfg['GoogleTrackingId']['help'] = "If entered, this will enable Google Analytics conversion tracking and automatically place the required code in your store at checkout. The ID is assigned by Google and is in the format UA-XXXXX-X. <b>NOTE:</b> If used, do not enter the Google conversion code in the <b>Cart Checkout Tracking Code</b> setting below.<br><br>";
$cfg['GoogleTrackingId']['default'] = "";

// CartCheckoutTrackingCode
$cfg['CartCheckoutTrackingCode']['section'] = "7";
$cfg['CartCheckoutTrackingCode']['type'] = "textarea";
$cfg['CartCheckoutTrackingCode']['help'] = "This is where you can paste conversion tracking code from a third-party (e.g. Google Analytics) for Cart Checkouts. <b>Note:</b> This does not mean they will complete the purchase, but it will allow you to track what people are putting in their carts and what they might purchase.<br><br><b>Available Variables</b>:<br><b>{CARTID}</b>&nbsp;&nbsp;&nbsp;Amazon shopping cart identifier<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number(s) in shopping cart at checkout<br><b>{SUBTOTAL}</b>&nbsp;&nbsp;&nbsp;Shopping cart subtotal (shipping is determined on Amazon)<br><br>";
$cfg['CartCheckoutTrackingCode']['default'] = "";

// CartAddTrackingCode
$cfg['CartAddTrackingCode']['section'] = "7";
$cfg['CartAddTrackingCode']['type'] = "textarea";
$cfg['CartAddTrackingCode']['help'] = "This is where you can paste conversion tracking code from a third-party (e.g. Google Analytics) for Cart Adds. <b>Note:</b> This does not mean they will complete the purchase, but it will allow you to track what people are putting in their carts and what they might purchase.<br><br><b>Available Variables</b>:<br><b>{CARTID}</b>&nbsp;&nbsp;&nbsp;Amazon shopping cart identifier<br><b>{ASIN}</b>&nbsp;&nbsp;&nbsp;Amazon item number added to shopping cart<br><b>{SUBTOTAL}</b>&nbsp;&nbsp;&nbsp;Shopping cart subtotal (shipping is determined on Amazon)<br><br>";
$cfg['CartAddTrackingCode']['default'] = "";

// SearchAllProducts
$cfg['SearchAllProducts']['section'] = "13";
$cfg['SearchAllProducts']['type'] = "search";
$cfg['SearchAllProducts']['help'] = "This controls how the <b>All Products</b> search functions. The <b>Blended</b> option returns results for your store categories only. The <b>All</b> options returns results across all Amazon categories. Or you can set the <b>All Products</b> to search one of your store categories and also customize the browse node.";

// SearchWithinResults
$cfg['SearchWithinResults']['section'] = "13";
$cfg['SearchWithinResults']['list'] = Array('Yes', 'No');
$cfg['SearchWithinResults']['type'] = "radio";
$cfg['SearchWithinResults']['help'] = "If set to Yes, when a user searches inside a category, they will also have an option to search within the current subcategory.";
$cfg['SearchWithinResults']['default'] = "Yes";

// AdvancedSearch
$cfg['AdvancedSearch']['section'] = "13";
$cfg['AdvancedSearch']['list'] = Array('Yes', 'No');
$cfg['AdvancedSearch']['type'] = "radio";
$cfg['AdvancedSearch']['help'] = "If set to Yes, when a link will be displayed next to the Search button to go to an Advanced Search page.";
$cfg['AdvancedSearch']['default'] = "Yes";

// SearchCombo
$cfg['SearchCombo']['section'] = "13";
$cfg['SearchCombo']['list'] = Array('Yes', 'No');
$cfg['SearchCombo']['type'] = "radio";
$cfg['SearchCombo']['help'] = "If set to Yes, any user-entered search term(s) will be combined with the category-level keywords OR Site Default Keyword (if defined in Site section). If set to No, then only the user-entered search term(s) will be used. See our documentation for an in-depth look at how this works. <b>Note:</b> Setting this to Yes means you will see more focused search results, but it could also mean you lose out on sales if someone wants to search more generally.";
$cfg['SearchCombo']['default'] = "No";

// SearchAutocomplete
$cfg['SearchAutocomplete']['section'] = "13";
$cfg['SearchAutocomplete']['list'] = Array('Yes', 'No');
$cfg['SearchAutocomplete']['type'] = "radio";
$cfg['SearchAutocomplete']['help'] = "As you type in the search box, related keyword suggestions are automatically displayed and can be selected.";
$cfg['SearchAutocomplete']['default'] = "No";

// ItemPages
$cfg['ItemPages']['section'] = "13";
$cfg['ItemPages']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10');
$cfg['ItemPages']['type'] = "simplemenu";
$cfg['ItemPages']['help'] = "Enter the maximum number of Item pages to be listed from 1 to 10 (10 items per page). <b>Note:</b> Number of page links may be less than your specified number depending on results returned.";
$cfg['ItemPages']['default'] = "10";
$cfg['ItemPages']['required'] = TRUE;

// DisplayViewAllItemsLink
$cfg['DisplayViewAllItemsLink']['section'] = "13";
$cfg['DisplayViewAllItemsLink']['list'] = Array('Yes', 'No');
$cfg['DisplayViewAllItemsLink']['type'] = "radio";
$cfg['DisplayViewAllItemsLink']['help'] = "When more than 10 pages of items are available for a category or subcategory, a <b>View All Items</b> link is displayed which points to Amazon to show all item pages/results. <b>Note:</b> The link opens in a new window and includes your Amazon Associate ID.";
$cfg['DisplayViewAllItemsLink']['default'] = "Yes";

// HomePageFormat
$cfg['HomePageFormat']['section'] = "15";
$cfg['HomePageFormat']['type'] = "homepage";
$cfg['HomePageFormat']['list'] = Array(
	'all'		=> 'All',
	'mall'		=> 'Mall',
	'blended'	=> 'Blended',
	'item' 		=> 'Single Item',
	'node' 		=> 'Browse Node',
	'asin'		=> 'ASIN List',
	'custom'	=> 'Custom HTML',
	'file'		=> 'HTML/PHP File',
	);
$cfg['HomePageFormat']['help'] = "Select the format you would like for your homepage. Keep in mind there may be other settings that require input depending on which format you choose.<br><br><b>All:</b><br>Displays up to 10 items at a time (up to 5 pages) from all categories (based on the <b>Site Default Keyword</b> which is required - see Site section).<br><br><b>Mall:</b><br>Lists links to your site categories along with 3-4 related subcategories (see the documentation on how to customize these subcategories).<br><br><b>Blended:</b><br>Lists up to 3 items from each of your site categories. Requires the <b>Site Default Keyword</b> (Site section). <b>Note:</b> Amazon.cn and Amazon.it not supported. This format is ideal for stores with categories across many Amazon Categories (horizontal) and not ideal if you have many categories under a single Amazon Category (vertical).<br><br><b>Single Item:</b><br>Displays a detailed view of a single item (Amazon ASIN). Requires the <b>Home Item</b> (below)<br><br><b>Browse Node:</b><br>Displays up to 10 items at a time (with pagination) from the node of your choice. Requires the <b>Home Node</b> information (below)<br><br><b>ASIN List:</b><br>Lists up to 10 ASINs. Requires the <b>Home ASINs</b> (below)<br><br><b>Custom HTML:</b><br>Displays your own HTML. Requires the <b>Home HTML</b> (below)<br><br><b>HTML/PHP File:</b><br>Include an external file to be included on your homepage. Requires the <b>Home File</b> (below)<br><br><br>";
$cfg['HomePageFormat']['default'] = "mall";
$cfg['HomePageFormat']['required'] = TRUE;

// HomeWelcomeHtml
$cfg['HomeWelcomeHtml']['section'] = "15";
$cfg['HomeWelcomeHtml']['type'] = "textarea";
$cfg['HomeWelcomeHtml']['help'] = "Can be used with any of the Home Page formats above. If provided, this welcome HTML will be used at the top of the body section of the home page.";

// HomeWelcomeFile
$cfg['HomeWelcomeFile']['section'] = "15";
$cfg['HomeWelcomeFile']['type'] = "text";
$cfg['HomeWelcomeFile']['help'] = "Can be used with any of the Home Page formats above. If provided, the URL/filename you enter here will be included at the top of the body section of the home page. <b>Note:</b> On some servers you may need to enter the path to the file instead of the URL. If the header file is in the same location as your shop file, you might be able to simply enter the file name (e.g. header.html). Also, do not enter HTML directly in this field.";

// HomeBlendedCount
$cfg['HomeBlendedCount']['section'] = "15";
$cfg['HomeBlendedCount']['list'] = Array('1', '2', '3');
$cfg['HomeBlendedCount']['type'] = "simplemenu";
$cfg['HomeBlendedCount']['help'] = "When the <b>Home Page Format</b> is set to <b>Blended</b>, this is the number of items per category that will be displayed. Also affects blended search results. <b>Note:</b> Amazon returns a maximum of 3 items per category though some categories might return 1 or 2 results depending on the Site Default Keyword.";
$cfg['HomeBlendedCount']['default'] = "3";

// HomeItem
$cfg['HomeItem']['section'] = "15";
$cfg['HomeItem']['type'] = "text";
$cfg['HomeItem']['help'] = "When the <b>Home Page Format</b> is set to <b>Single Item</b>, it is the item (Amazon ASIN) that will be used. The ASIN must be from the main group of categories you setup for your site under the Categories section. <b>Note:</b> Also, the ASIN entered must be from the same locale as your store (e.g. Amazon.com, Amazon.co.uk, etc).";

// HomeNode
$cfg['HomeNode']['section'] = "15";
$cfg['HomeNode']['type'] = "node";
$cfg['HomeNode']['help'] = "When the <b>Home Page Format</b> is set to <b>Browse Node</b>, this is the node information that will be used. Amazon returns up to 10 items (with more items paginated). <b>Note:</b> The Amazon Category selected must be from the main group of categories you setup for your site under the Categories section.";

// HomeAsins
$cfg['HomeAsins']['section'] = "15";
$cfg['HomeAsins']['type'] = "text";
$cfg['HomeAsins']['help'] = "When the <b>Home Page Format</b> is set to <b>ASIN List</b>, these are the ASINs that will be used. Enter from 1 to an unlimited number of Amazon ASINs. ASINs are Amazon part numbers. If provided, these ASIN(s) will be displayed on the home page instead of the usual Blended Search based on the Site Default Keyword. Enter ASINs separated by comma (e.g. 0345428838,0345428838). <b>Note:</b> Only the first 10 (or fewer if Home ASINs Per Page below is changed) items in your list will be displayed. If you set the Home Asins Randomizer below, then a random set of items from your list will be displayed. Also, you cannot mix and match ASINs from the different locales (e.g. Amazon.com and Amazon.co.uk). They must all be from the same locale as your store.";

// HomeAsinsPerPage
$cfg['HomeAsinsPerPage']['section'] = "15";
$cfg['HomeAsinsPerPage']['list'] = Array('10', '9', '8', '7', '6', '5', '4', '3', '2');
$cfg['HomeAsinsPerPage']['type'] = "simplemenu";
$cfg['HomeAsinsPerPage']['help'] = "Set the number of ASINs to display per page. <b>Note:</b> Maximum of 10 items returned at a time.";
$cfg['HomeAsinsPerPage']['default'] = "10";

// HomeAsinsRandomizer
$cfg['HomeAsinsRandomizer']['enhanced'] = TRUE;
$cfg['HomeAsinsRandomizer']['section'] = "15";
$cfg['HomeAsinsRandomizer']['list'] = Array('On', 'Off');
$cfg['HomeAsinsRandomizer']['type'] = "radio";
$cfg['HomeAsinsRandomizer']['help'] = "When the <b>Home Page Format</b> is set to <b>Browse Node</b> or <b>ASIN List</b>, setting this to On causes a random set of up to 10 items (or fewer if Home ASINs Per Page above is changed) from your list to be displayed on your home page. <b>Note:</b> The randomization will occur each time the cache is cleared (either Automatically every Cache Lifetime period or Manually).";
$cfg['HomeAsinsRandomizer']['default'] = "Off";

// HomeHtml
$cfg['HomeHtml']['section'] = "15";
$cfg['HomeHtml']['type'] = "textarea";
$cfg['HomeHtml']['help'] = "When the <b>Home Page Format</b> is set to <b>Custom HTML</b>, the HTML you enter here will be used in the body section of the home page.";

// HomeFile
$cfg['HomeFile']['section'] = "15";
$cfg['HomeFile']['type'] = "text";
$cfg['HomeFile']['help'] = "When the <b>Home Page Format</b> is set to <b>HTML/PHP File</b>, the URL/filename you enter here will be included in the body section of the home page. <b>Note:</b> On some servers you may need to enter the path to the file instead of the URL. If the header file is in the same location as your shop file, you might be able to simply enter the file name (e.g. header.html). Also, do not enter HTML directly in this field.";

// ModRewrite
$cfg['ModRewrite']['section'] = "18";
$cfg['ModRewrite']['list'] = Array('On', 'Off');
$cfg['ModRewrite']['type'] = "modrewrite";
if (!DEFINED("BRANDED"))
	$cfg['ModRewrite']['help'] = "If set to On, search engine friendly URLs will be used inside your store. <b>WARNING:</b> This feature is for advanced users only and requires that you enable mod_rewrite on your server as well as upload an .htaccess file with the mod_rewrite rules. Leave set to Off if you do not know what this is. If set to On, URLs generated inside your store will be parsed according to the mod_rewrite rules provided in the yellow box below. For more information on how to setup these rules see our <a href=\"http://www.associate-o-matic.com/docs/doc_cp_seo.html\" target=\"_blank\">SEO documentation</a>.";
else
	$cfg['ModRewrite']['help'] = "If set to On, search engine friendly URLs will be used inside your store. <b>WARNING:</b> This feature is for advanced users only and requires that you enable mod_rewrite on your server as well as upload an .htaccess file with the mod_rewrite rules. Leave set to Off if you do not know what this is. If set to On, URLs generated inside your store will be parsed according to the mod_rewrite rules provided in the yellow box below.";	
$cfg['ModRewrite']['default'] = "Off";

// UrlSeparator
$cfg['UrlSeparator']['section'] = "18";
$cfg['UrlSeparator']['list'] = Array('-' => '- (Hyphen)', '_' => '_ (Underscore)');
$cfg['UrlSeparator']['type'] = "complexmenu";
$cfg['UrlSeparator']['help'] = "If Mod Rewrite is set to On, this setting tells how parameters in the URL will be separated. <b>Note:</b> If you have a pre-existing store with mod_rewrite, it is not recommended to set this to Underscore. This will cause your old links in search engines to die. Also, the opposite character will be used to separate words in the 'x' parameter (i.e. name of the link) if <b>Url With Name</b> below is set to Yes.<br><br><b>Hyphen (-) Examples:</b><br>http://www.yoursite.com/Books-1000-0553210793.html<br>http://www.yoursite.com/Books-1000-0099244721-Timeline.html<br>http://www.yoursite.com/Books-1000-0545010225-Harry_Potter_and_the_Deathly_Hallows.html<br><br><b>Underscore (_) Examples:</b><br>http://www.yoursite.com/Books_1000_0553210793.html<br>http://www.yoursite.com/Books_1000_0099244721_Timeline.html<br>http://www.yoursite.com/Books_1000_0545010225_Harry-Potter-and-the-Deathly-Hallows.html<br><br>";
$cfg['UrlSeparator']['default'] = "-";

// UrlHomeFile
$cfg['UrlHomeFile']['section'] = "18";
$cfg['UrlHomeFile']['type'] = "text";
$cfg['UrlHomeFile']['help'] = "If Mod Rewrite is set to On, this is the name used in links to your homepage from within the store (e.g. home, index.html, shop, etc...). Keep in mind the file doesn't have to exist because the URL will get rewritten to your actual store URL. <b>Note:</b> You will need to modify the first line in the mod rewrite rules we provide to reflect the name you choose: RewriteRule ^<b>[Url Home File]</b>	shop.php";
$cfg['UrlHomeFile']['default'] = "home";

// UrlEndsWith
$cfg['UrlEndsWith']['section'] = "18";
$cfg['UrlEndsWith']['list'] = Array('.html', '');
$cfg['UrlEndsWith']['type'] = "simplemenu";
$cfg['UrlEndsWith']['help'] = "If Mod Rewrite is set to On, this setting determines how mod_rewritten URLs end. Be sure to use the correct rule set for the ending you've chosen (see the online documentation).";
$cfg['UrlEndsWith']['default'] = ".html";

// UrlWithName
$cfg['UrlWithName']['section'] = "18";
$cfg['UrlWithName']['list'] = Array('Yes', 'No');
$cfg['UrlWithName']['type'] = "radio";
$cfg['UrlWithName']['help'] = "If set to Yes, where applicable (e.g. item links, category links, review links, marketplace links, etc), the Item Name or Category Name will be added to the link (depending on context). It's sole purpose is to help with search engine ranking. Setting it to Yes or No will not affect the functionality of your store. <b>Note:</b> This setting can be used with mod_rewrite On or Off (mod_rewrite is not available in Lite version). With mod_rewrite Off, a 'x=[name here]' parameter is added to the end of the URL. With mod_rewrite On, the name is simply added to the end of the URL. Be sure to use the correct rule set for the ending you've chosen (see the online documentation).";
$cfg['UrlWithName']['default'] = "Yes";

// UrlPlaceholder
$cfg['UrlPlaceholder']['section'] = "18";
$cfg['UrlPlaceholder']['type'] = "text";
$cfg['UrlPlaceholder']['help'] = "Because the SEO URLs are position based, when a value cannot be determined say for a Node, this placeholder is used (default is 'none').";
$cfg['UrlPlaceholder']['default'] = "none";
$cfg['UrlPlaceholder']['required'] = TRUE;

// UrlNameLength
$cfg['UrlNameLength']['section'] = "18";
$cfg['UrlNameLength']['type'] = "text";
$cfg['UrlNameLength']['help'] = "If the <b>Url With Name</b> setting above is set to Yes, this setting tells the maximum character length (default 200 characters). <b>Note:</b> Setting this too long or two short is not recommended. Too long (over 2000 characters) and search engines might not like your URLs. Too short and you defeat the purpose of adding names to the URLs. We recommend keeping it set at 200.";
$cfg['UrlNameLength']['default'] = "200";
$cfg['UrlNameLength']['required'] = TRUE;

// UrlCloak
$cfg['UrlCloak']['section'] = "18";
$cfg['UrlCloak']['list'] = Array('On', 'Off');
$cfg['UrlCloak']['type'] = "radio";
$cfg['UrlCloak']['help'] = "When set to <b>On</b>, links that would normally contain Amazon's domain will be cloaked to use your domain. This includes direct Amazon buy buttons, the View Cart link and the Checkout link (when the internal shopping cart is disabled).";
$cfg['UrlCloak']['default'] = "On";

// ImageCloak
$cfg['ImageCloak']['section'] = "18";
$cfg['ImageCloak']['list'] = Array('On', 'Off');
$cfg['ImageCloak']['type'] = "radio";
$cfg['ImageCloak']['help'] = "When set to <b>On</b>, Amazon product image URLs are replaced (cloaked) with 'img.php' and the image name. This is useful if you are wanting to hide Amazon image URL references inside the source of your pages.";
$cfg['ImageCloak']['default'] = "On";

// CanonicalLinks
$cfg['CanonicalLinks']['section'] = "18";
$cfg['CanonicalLinks']['list'] = Array('Yes', 'No');
$cfg['CanonicalLinks']['type'] = "radio";
$cfg['CanonicalLinks']['help'] = "If set to Yes, where applicable, canonical links will be added to the HEAD section of category and subcategory pages. This tells search engines there is a preferred page for a particular category/subcategory. This applies expecially to sub pages where the sort selection might change, but the category and items are the same (just ordered differently). See Google for more information about <a href='http://www.google.com/support/webmasters/bin/answer.py?answer=139394' target='_new'>Canonical Links</a>";
$cfg['CanonicalLinks']['default'] = "Yes";

// NoFollow
$cfg['NoFollow']['section'] = "18";
$cfg['NoFollow']['list'] = Array(
	'B' => 'Breadcrumbs',
	'I' => 'Similar Item Links',
	'M' => 'Marketplace Links',
	'SB' => 'Subcategory Box ',
	'RB' => 'Related Category Box',
	'BB' => 'Bestseller Box',
	'NB' => 'New Release Box',
	'GB' => 'Most Gifted Box',
	'WB' => 'Most Wished For Box',
	'N1' => 'Narrow By Brand Box',
	'N2' => 'Narrow By Price Box',
	'IB' => 'Info Box Links',
	);
$cfg['NoFollow']['cols'] = "4";
$cfg['NoFollow']['type'] = "checkboxes";
$cfg['NoFollow']['help'] = "NoFollow allows you to keep certain links from being spidered by search engines that honor this directive. We recommend using NoFollow with all of the link sections below. Check the boxes for those link sections you would like to be NoFollow (non-spiderable). Uncheck if you want search engines to spider them. This keeps unwanted links from showing up in search engine results and saves bandwidth. <b>Note:</b> Links to your main store Categories and Item pages are always spiderable.<br><br><b>Example:</b> &lt;a href='http://www.yourdomain.com/' rel='nofollow'&gt;Your Link&lt;/a&gt;<br><br><b>Link Sections:</b><br> &#149; Breadcrumbs - All breadcrumb links except the Home and first main Category link<br> &#149; Similar Item Links - Any similar/related/accessory/maker links <br> &#149; Marketplace Links - Links to and inside the Marketplace pages<br> &#149; Subcategory Box - All links inside this box<br> &#149; Related Category Box - All links inside this box<br> &#149; Bestseller Box - All links inside this box<br> &#149; New Release Box - All links inside this box<br> &#149; Most Gifted Box - All links inside this box<br> &#149; Most Wished For Box - All links inside this box<br> &#149; Narrow By Brand Box - All links inside this box<br> &#149; Narrow By Price Box - All links inside this box<br> &#149; Info Box - All links inside this box<br><br>";
$cfg['NoFollow']['key'] = TRUE;
$cfg['NoFollow']['default'] = Array('B', 'I', 'M', 'R', 'SB', 'RB', 'BB', 'NB', 'GB', 'WB', 'N1', 'N2', 'IB', 'RS');

// PageCaching
$cfg['PageCaching']['section'] = "19";
$cfg['PageCaching']['list'] = Array('On', 'Off');
$cfg['PageCaching']['type'] = "radio";
$cfg['PageCaching']['help'] = "Leave Page Caching set to On to have your store pages load faster. It means that instead of calling the Amazon servers with each request, pages are requested once and then stored (cached) on your server for future visitors for a period of 24 hours (default). Once the Cache Lifetime (below) number of hours passes, a new version of the page is loaded with the next visit and cached for another Cache Lifetime number of hours.";
$cfg['PageCaching']['default'] = "On";

// CacheLifetime
$cfg['CacheLifetime']['section'] = "19";
$cfg['CacheLifetime']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24');
$cfg['CacheLifetime']['type'] = "simplemenu";
$cfg['CacheLifetime']['help'] = "This is the number of hours your pages will be cached before they expire. Once expired, a new version of the page is loaded with the next visit and cached for this many hours.";
$cfg['CacheLifetime']['default'] = "24";

// CacheCleanup
$cfg['CacheCleanup']['section'] = "19";
$cfg['CacheCleanup']['list'] = Array('Never', '1000', '500', '400', '300', '200', '100', '90', '80', '70', '60', '50', '40', '30', '20', '10', '5');
$cfg['CacheCleanup']['type'] = "simplemenu";
$cfg['CacheCleanup']['help'] = "Page Caching requires server storage space. This settings ensures that old cached pages are cleaned from your server automatically and don't use up this valuable space. Setting this value to <b>20</b> means there is a 1 in <b>20</b> chance cache files older than the Cache Lifetime (24 hours is the default) will be cleared. Setting this value higher means your cache will be cleared less often which can improve performance at the cost of higher disk space usage. Setting this value lower means your cache will be cleared more frequently which will leave more disk space available at the cost of performance. We recommend the default of 20. Set higher or lower depending on your store traffic and storage limits.";
$cfg['CacheCleanup']['default'] = "20";

// CacheHeader
$cfg['CacheHeader']['section'] = "19";
$cfg['CacheHeader']['list'] = Array('Yes', 'No');
$cfg['CacheHeader']['type'] = "radio";
$cfg['CacheHeader']['help'] = "If Page Caching is On and you are using your own Site Header, setting this to No will cause your header file to load with each page load while the store content will pull from cache. <b>Warning:</b> If set to No, no variables are passed into your Site Header file meaning page titles and meta tags will not change based on the store page.";
$cfg['CacheHeader']['default'] = "Yes";

// CacheFooter
$cfg['CacheFooter']['section'] = "19";
$cfg['CacheFooter']['list'] = Array('Yes', 'No');
$cfg['CacheFooter']['type'] = "radio";
$cfg['CacheFooter']['help'] = "If Page Caching is On and you are using your own Site Footer, setting this to No will cause your footer file to load with each page load while the store content will pull from cache. <b>Warning:</b> If set to No, no variables are passed into your Site Footer file.";
$cfg['CacheFooter']['default'] = "Yes";

// CacheRss
$cfg['CacheRss']['section'] = "19";
$cfg['CacheRss']['list'] = Array('Yes', 'No');
$cfg['CacheRss']['type'] = "radio";
$cfg['CacheRss']['help'] = "If set to <b>Yes</b> and RSS and Page Caching are enabled, your store RSS feed pages will be cached for faster page loading.";
$cfg['CacheRss']['default'] = "Yes";

// CurrencyRate
$cfg['CurrencyRate']['section'] = "23";
$cfg['CurrencyRate']['type'] = "text";
$cfg['CurrencyRate']['help'] = "This is the static currency conversion rate for the currency you want to convert to. If you were converting from USD to EUR and the current conversion rate was 0.853026 you would enter this value. Keep in mind this would only be an estimated conversion as the rates will frequently change. It needs to be manually maintained.";
$cfg['CurrencyRate']['default'] = "";

// CurrencyRateFile
$cfg['CurrencyRateFile']['section'] = "23";
$cfg['CurrencyRateFile']['type'] = "text";
$cfg['CurrencyRateFile']['help'] = "Enter the URL or path to a file on your server that contains the currency conversion rate for the currency you want to convert to. If you were converting from USD to EUR and the current conversion rate was 0.853026 you would enter this value in the file. If supplied it will override the Currency Rate value above. ";
$cfg['CurrencyRateFile']['default'] = "";

// CurrencySymbolPrefix
$cfg['CurrencySymbolPrefix']['section'] = "23";
$cfg['CurrencySymbolPrefix']['type'] = "text";
$cfg['CurrencySymbolPrefix']['help'] = "This is the symbol to use at the beginning of the converted currency value, if supplied and if Currency Rate above is set. Using the above USD/EUR example for a $15 item with a prefix of 'EUR ' would be displayed as: $15.00 (EUR 12.80)";
$cfg['CurrencySymbolPrefix']['default'] = "";

// CurrencySymbolSuffix
$cfg['CurrencySymbolSuffix']['section'] = "23";
$cfg['CurrencySymbolSuffix']['type'] = "text";
$cfg['CurrencySymbolSuffix']['help'] = "This is the symbol to use at the end of the converted currency value, if supplied and if Currency Rate above is set. Using the above USD/EUR example for a $15 item with a suffix of ' EUR' would be displayed as: $15.00 (12.80 EUR)";
$cfg['CurrencySymbolSuffix']['default'] = "";

// Rss
$cfg['Rss']['section'] = "30";
$cfg['Rss']['list'] = Array('L' => 'Categories', 'S' => 'Subcategories', 'SA' => 'Search All');
$cfg['Rss']['type'] = "checkboxes";
$cfg['Rss']['key'] = TRUE;
if (!DEFINED("BRANDED"))
	$cfg['Rss']['help'] = "This setting allows you to turn on RSS feeds for your store pages. People can in turn subscribe to your feeds and include them in their RSS reader software and websites. For more information please see our <a href=\"http://www.associate-o-matic.com/docs/doc_cp_rss.html\" target=\"_blank\">documentation</a>.";
else
	$cfg['Rss']['help'] = "This setting allows you to turn on RSS feeds for your store pages. People can in turn subscribe to your feeds and include them in their RSS reader software and websites.";	
$cfg['Rss']['default'] = Array();

// RssIcons
$cfg['RssIcons']['section'] = "30";
$cfg['RssIcons']['list'] = Array('On', 'Off');
$cfg['RssIcons']['type'] = "radio";
$cfg['RssIcons']['help'] = "If RSS is activated above, this setting will automatically display a small RSS icon on applicable pages to notifiy visitors of your feeds. This will also help web browsers auto-detect your RSS feeds. To change the default RSS icon, simply replace the /aom/themes/[your theme]/images/rss.png file with a different image file.";
$cfg['RssIcons']['default'] = "On";

// RssFooter
$cfg['RssFooter']['section'] = "30";
$cfg['RssFooter']['type'] = "textarea";
$cfg['RssFooter']['help'] = "This lets you add extra content HTML under each of your RSS feed items such as a link back to your store.<br><br><b>Available Variables</b>:<br><b>{SITE_NAME}</b>&nbsp;&nbsp;&nbsp;uses value entered in the Site section<br><b>{ITEM_NAME}</b>&nbsp;&nbsp;&nbsp;name of your store item<br><b>{ITEM_URL}</b>&nbsp;&nbsp;&nbsp;direct link to your store item<br><br>";
$cfg['RssFooter']['default'] = "";

// ImageSizeRss
$cfg['ImageSizeRss']['section'] = "30";
$cfg['ImageSizeRss']['list'] = Array('Small', 'Tiny', 'Medium', 'Large');
$cfg['ImageSizeRss']['type'] = "simplemenu";
$cfg['ImageSizeRss']['help'] = "Select the item image size to display on the RSS feed pages. If you want to force images to a specific width and/or height specify those. Otherwise leave blank for images to display their normal size.";
$cfg['ImageSizeRss']['dimensions'] = TRUE;
$cfg['ImageSizeRss']['default'] = "Small";

// RssCustomPages
$cfg['RssCustomPages']['section'] = "30";
$cfg['RssCustomPages']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['RssCustomPages']['type'] = "simplemenu";
$cfg['RssCustomPages']['help'] = "Select the maximum number of RSS news feed items to display on RSS Custom Pages (external feeds)";
$cfg['RssCustomPages']['default'] = "10";

// RssCustomBoxes
$cfg['RssCustomBoxes']['section'] = "30";
$cfg['RssCustomBoxes']['list'] = Array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20');
$cfg['RssCustomBoxes']['type'] = "simplemenu";
$cfg['RssCustomBoxes']['help'] = "Select the maximum number of RSS news feed items to display inside RSS Custom Boxes (external feeds)";
$cfg['RssCustomBoxes']['default'] = "5";

// RssLinkTarget
$cfg['RssLinkTarget']['section'] = "30";
$cfg['RssLinkTarget']['list'] = Array('_self', '_top', '_blank', '_parent');
$cfg['RssLinkTarget']['type'] = "simplemenu";
$cfg['RssLinkTarget']['help'] = "Select the target window for RSS links. The default is '_blank' which will means the links will open in a new window.";
$cfg['RssLinkTarget']['default'] = "_blank";

// RssExternalFields
$cfg['RssExternalFields']['section'] = "30";
$cfg['RssExternalFields']['list'] = Array('item-description' => 'Item Description', 'item-pubDate' => 'Item Published Date');
$cfg['RssExternalFields']['type'] = "checkboxes";
$cfg['RssExternalFields']['key'] = TRUE;
$cfg['RssExternalFields']['help'] = "For external RSS feeds you can turn off certain RSS fields by unchecking the boxes below.";
$cfg['RssExternalFields']['default'] = Array();

// CategorySort
$cfg['CategorySort']['section'] = "4";
$cfg['CategorySort']['type'] = "sort";
$cfg['CategorySort']['help'] = "Set the default sort for each of your store categories.";

// CategoryItemRandomizer
$cfg['CategoryItemRandomizer']['section'] = "4";
$cfg['CategoryItemRandomizer']['list'] = Array('On', 'Off');
$cfg['CategoryItemRandomizer']['type'] = "radio";
$cfg['CategoryItemRandomizer']['help'] = "Randomizes the order of the 10 items displayed on Category and Subcategory pages. <b>Note:</b> The same 10 items are displayed whether set to On or Off.";
$cfg['CategoryItemRandomizer']['default'] = "Off";

// Theme
$cfg['Theme']['section'] = "33";
$cfg['Theme']['type'] = "theme";
$cfg['Theme']['help'] = "Select the theme for your store (the standard theme is named <b>AOM Default</b> in the <b>/aom/themes/default</b> directory).<br><a href=\"http://www.associate-o-matic.com/themes/\" target=\"_blank\"><b>Download more themes</b></a><br><br>";
$cfg['Theme']['default'] = "default";

?>