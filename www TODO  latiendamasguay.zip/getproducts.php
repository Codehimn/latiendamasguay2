<?php
if (!isset($_GET['keyword']) || !isset($_GET['amzcat'])) {
    echo "Faltan parametros!";
    exit(0);
}
require_once "ebayFunctions.php";
header('Content-Type: text/xml');

/*
 * Echo the XML out tag
 */
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <products>
        <?php
        include("amazonapi/amazon_api_class.php");
        $obj = new AmazonProductAPI();
        define('INCH_TO_CM', 2.54);
//        include ("class.html2text.inc");
        
// we connect to example.com and port 3307
        mysql_connect("localhost", "latienda_amz", "amz1qaz") or die(mysql_error());
//        echo "Connected to MySQL<br />";
        mysql_select_db("latienda_amazon") or die(mysql_error());
//        echo "Connected to Database";

        $row = null;
        $amzfile = null;
        $TotalPages = 2;
        $i = 1;
        $keyword = $_GET['keyword'];


        while ($i < $TotalPages && $i < 20) {
            try {

                $results = $obj->searchProducts($keyword, $_GET['amzcat'], "TITLE", $i);
            } catch (Exception $e) {
                echo $e->getMessage();
            }
            $TotalPages = $results->Items->TotalPages;
            if ($TotalPages < 1 && FALSE) {
                echo "We did not find any matches for your request";
            } else {
                echo $results->Items->Request->Errors->Error->Message;


                foreach ($results->Items->Item as $result) {
//        http://latiendamasguay.es/index.php?k=B0040JG2CC&c=9739
//  	foreach ($result->Offers->Offer as $Offer) {
                    $AmazonPrime = getPrice($result->Offers->MoreOffersUrl);
                    
                    $ASIN = $result->ASIN;
                    $qryResult = mysql_query("SELECT ASIN FROM usedproducts WHERE ASIN = '$ASIN' ");
                    if (mysql_num_rows($qryResult) == 0) {

                        $location = "http://latiendamasguay.es/index.php?k={$ASIN}&amp;c=all";
                        $image = $result->LargeImage->URL;
                        $desc = createdesc($result);
                        $desc2 = strip_tags($desc);
                        $container = array(
                            'id' => $ASIN,
                            'name' => $result->ItemAttributes->Title,
                            'price' => $result->OfferSummary->LowestNewPrice->Amount / 100,
                            'desc' => $desc,
                            'desc2' => $desc2,
                            'image' => $image,
                            'viewed' => 0,                            
                            'url' => $location,
                            'prime' => $AmazonPrime,
                        );

                        echo GenerateNode($container);
//                        $result = mysql_query("INSERT INTO `usedproducts`
//                                                (
//                                                  `ASIN`
//                                                ) 
//                                                VALUE ('$ASIN') ");
                    }
//                    exit();
                }
            }
            $i++;
        }
        ?>
    </products>
</urlset>
<?php

function GenerateNode($data) {
    $content = '';
    $content .= "\t" . '<product>' . "\n";
    $content .= "\t\t" . '<id>' . trim($data['id']) . '</id>' . "\n";
    $content .= "\t\t" . '<name>' . trim($data['name']) . '</name>' . "\n";
    $content .= "\t\t" . '<price>' . trim($data['price']) . '</price>' . "\n";
    $content .= "\t\t" . '<desc>' . trim($data['desc']) . '</desc>' . "\n";
    $content .= "\t\t" . '<desc2>' . trim($data['desc2']) . '</desc2>' . "\n";
    $content .= "\t\t" . '<image>' . trim($data['image']) . '</image>' . "\n";
    $content .= "\t\t" . '<viewed>' . trim($data['viewed']) . '</viewed>' . "\n";
    $content .= "\t\t" . '<url>' . trim($data['url']) . '</url>' . "\n";
    $content .= "\t\t" . '<prime>' . trim($data['prime']) . '</prime>' . "\n";
    $content .= "\t" . '</product>' . "\n";
    return $content;
}

function createdesc($result) {
    $amz_title = $result->ItemAttributes->Title;
    $description = "<h1><font ><CENTER>" . $result->ItemAttributes->Title . "</CENTER></font></h1>";
//    foreach ($result->ImageSets->ImageSet as $ImageSet) {
//        $description .= "<img src=\"" . $ImageSet->LargeImage->URL . "\" />";
//        break;
//    }
//    $Features = '<hr><h2 >Características</h2>';
//    $Features .= '<ul>';
//    foreach ($result->ItemAttributes->Feature as $Feature) {
//        $Features .= "<li>" . $Feature; //str_replace("\n",'',str_replace("\t",'',$EditorialReview->Content));
//    }
//    $Features .= '</ul>';
//    $description .= $Features;
    //rgb(204, 102, 0)
//    $EdReview = "";
//    if ($result->EditorialReviews->EditorialReview) {
//        $EdReview = '<hr><h2>Descripción</h2>';
//        foreach ($result->EditorialReviews->EditorialReview as $EditorialReview) {
//            $EdReview .= $EditorialReview->Content; //str_replace("\n",'',str_replace("\t",'',$EditorialReview->Content));
//            break;
//        }
//    }
    //$description .= $EdReview;
    $details = '<hr><h2>Detalles</h2>';
    $details .= '<ul>';
    if ($result->ItemAttributes->ItemDimensions->Height > 0) {
//        $details .= '<li><b>Tamaño:</b>  ' . $result->ItemAttributes->ItemDimensions->Height / 100 . ' x ' . $result->ItemAttributes->ItemDimensions->Length / 100 . ' x ' . $result->ItemAttributes->ItemDimensions->Width / 100 . ' Pulgadas</li>';
        $Height = $result->ItemAttributes->ItemDimensions->Height / 100;
        $Length = $result->ItemAttributes->ItemDimensions->Length / 100;
        $Width = $result->ItemAttributes->ItemDimensions->Width / 100;
        $ItemDimensions = $Height * $Length * $Width;
        $details .= '<li><b>Dimensiones de ' . $amz_title . ':</b>  ' . number_format(($Height) * INCH_TO_CM, 0, '.', ' ') . ' x ' . number_format(($Length) * INCH_TO_CM, 0, '.', '') . ' x ' . number_format(($Width) * INCH_TO_CM, 0, '.', ' ') . ' cm</li>';
    }
    if (isset($result->ItemAttributes->Binding)) {
        $details .= '<li><b>Tipo:</b> ' . $result->ItemAttributes->Binding . '</li>';
    }
    if ($result->ItemAttributes->ManufacturerMinimumAge > 0) {
        $details .= '<li><b>Edad recomendada del Fabricante:</b> ' . round($result->ItemAttributes->ManufacturerMinimumAge / 12) . ' - ' . round($result->ItemAttributes->ManufacturerMaximumAge / 12) . ' años</li>';
    }
    if ($result->ItemAttributes->Brand > 0) {
        $details .= '<li><b>Marca:</b>  ' . $result->ItemAttributes->Brand . '</li>';
    }
    if (isset($result->ItemAttributes->Color)) {
        $details .= '<li><b>Color:</b>  ' . $result->ItemAttributes->Color . '</li>';
    }
    if (isset($result->ItemAttributes->Manufacturer)) {
        $details .= '<li><b>Fabricante:</b>  ' . $result->ItemAttributes->Manufacturer . '</li>';
    }
    if (isset($result->ItemAttributes->Model)) {
        $details .= '<li><b>Modelo:</b>  ' . $result->ItemAttributes->Model . '</li>';
    }
    $details .= '</ul>';
    $domains = array(".com", ".net", ".org", ".info", ".us", ".net");
    $description .= str_replace($domains, "", $details);
    $description = htmlspecialchars(str_replace("&", "&amp;", $description), ENT_QUOTES);
//            $description .= htmlspecialchars($description, ENT_NOQUOTES);
//            $handle = fopen("desc.txt", "rb"); //$_GET['user']. SAME DESCRIPTION FOR EVERYBODY
//            $description .= stream_get_contents($handle);
//            fclose($handle);

    return $description;
}
?>