<?php
define("MINIMUM_ITEM_SHPPING_FEE", 5);
define("DEBUG", FALSE);


function getEbayPrice($AmazonOfferPrice) {
    $feearray = array();
$feearray[0] = array('min' => 0, 'max' => 19.99, 'fee' => 0.46);
$feearray[1] = array('min' => 20, 'max' => 29.99, 'fee' => 0.40);
$feearray[2] = array('min' => 30, 'max' => 39.99, 'fee' => 0.35);
$feearray[3] = array('min' => 40, 'max' => 49.99, 'fee' => 0.30);
$feearray[4] = array('min' => 50, 'max' => 59.99, 'fee' => 0.28);
$feearray[5] = array('min' => 60, 'max' => 99.99, 'fee' => 0.25);
$feearray[6] = array('min' => 100, 'max' => 999.99, 'fee' => 0.23);

    foreach ($feearray as $fee) {
        if (($fee["min"] <= $AmazonOfferPrice) && ($AmazonOfferPrice <= $fee["max"])) {
            //$log .= $fee["fee"]."<br>";
            $shipping = ($AmazonOfferPrice) * $fee["fee"];
            $shipping = ($shipping < MINIMUM_ITEM_SHPPING_FEE ? MINIMUM_ITEM_SHPPING_FEE : $shipping);
            $AmazonOfferPrice += $shipping;
            break;
            //$log .= $shipping."<br>";
        }
    }
    $AmazonOfferPrice = number_format($AmazonOfferPrice, 2, '.', '');
    //=($itemPrice+($itemPrice-($AmazonOfferPrice/GO_DOWN_PRICE_FACTOR)))/2
    //=+(A4+(A4-($A$2/$A$3)))/2
    return $AmazonOfferPrice;
}

function getPrice($url) {
    try {
    $wdata = null;
    $wurl = $url;
    $content = null;
    $arrprice = array();
    $maxprice = 0 ;
//    $price = 0;
    $primeprice = 0;
    $useragent="j1awiki/1.0 (juguetes1a.com)"; 
    $wch = curl_init();
            curl_setopt($wch, CURLOPT_USERAGENT, $useragent); 
            curl_setopt($wch, CURLOPT_URL, $wurl);
            curl_setopt($wch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($wch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($wch, CURLOPT_TIMEOUT,3);
            curl_setopt($wch, CURLOPT_REFERER, "http://juguetes1a.com");
            $html= curl_exec($wch);
            curl_close($wch);
            if ($html) {

                    $doc = new DOMDocument;
                    $doc->preserveWhiteSpace = false; 
                    libxml_use_internal_errors(TRUE); 
                    $doc->loadHTML($html);
                    libxml_use_internal_errors(FALSE);
                    // grab all the on the page
                    $xpath = new DOMXPath($doc);
//                    $bodycontent = $xpath->query("//span[contains(@class, 'price') and not(contains(@class, 'pricePerUnit'))]");
//                    $availability = $xpath->query("//div[contains(@class, 'availability')]");
//                    $condition = $xpath->query("//div[contains(@class, 'condition')]");
                    $results = $xpath->query("//tbody[contains(@class, 'result')]/*");
//                    header('Content-type: text/plain');
//                    $xpath2 = new DOMXPath($results);
//                    
//                        $tbody = $results->item(0);
//
//                        // our query is relative to the tbody node
//                        $query = "//span[contains(@class, 'price') and not(contains(@class, 'pricePerUnit'))]";
//
//                        $entries = $xpath2->query($query, $tbody);
//$doc2 = new DOMDocument('1.0', 'UTF-8');



            foreach ($results as $result) {
                //echo $result->textContent;
                $condition = $xpath->query(".//div[@class='condition']", $result);
                $availability = $xpath->query(".//div[@class='availability']", $result);
//                echo ">".strpos(strtolower(trim($availability->item(0)->nodeValue)),strtolower("In Stock")).trim($availability->item(0)->nodeValue)."<";
                if (($condition->length > 0 && trim($condition->item(0)->nodeValue) == "New") 
                    && ($availability->length > 0 ) 
                        && (strpos(strtolower($availability->item(0)->nodeValue),strtolower("Back-ordered."))===FALSE) 
                        && ((strpos(strtolower($availability->item(0)->nodeValue),strtolower("In Stock"))!==FALSE) 
                            || (strpos(strtolower($availability->item(0)->nodeValue),strtolower("Usually ships within 2 - 3 business days"))!==FALSE))) {
                    $price = $xpath->query(".//span[@class='price']", $result);
                    if ($price->length > 0) {
                        $price = preg_replace('/[^0-9]/','',$price->item(0)->nodeValue)/100;
                        $price_shipping = $xpath->query(".//span[@class='price_shipping']", $result);
                        $supersaver = $xpath->query(".//span[@class='supersaver']", $result);
//                        echo $price_shipping->length.'prime'.$price_shipping->item(0)->nodeValue.$supersaver->item(0)->nodeValue;
                        if ($price_shipping->length>0) {
                            $price_shipping = preg_replace('/[^0-9]/','',$price_shipping->item(0)->nodeValue)/100;
                            $price += $price_shipping;
                            echo "price$price shipping $price_shipping max".$maxprice;
                            $maxprice = $price > $maxprice? $price: $maxprice;
//                            $maxprice = $price > $maxprice? ($maxprice==0?$price:($price+$maxprice)/2): $maxprice;
//                            $maxprice = $maxprice==0?$price:($price+$maxprice)/2;
                            echo "price$price shipping $price_shipping max".$maxprice;
                        }
                         elseif ($supersaver->length>0) {
                             $primeprice = $price;
                             break;
                        }
                    }
                }
            }
//            echo ($primeprice>0?"PRIME:".$primeprice:"NOprime:".$maxprice);   
            return ($primeprice>0?"prime":($maxprice>0?'noprime':'noprime'));
//                        foreach ($entries as $entry) {
//                            echo "Found {$entry->nodeName}," .
//                                 " by {$entry->nodeValue}\n";
//                        }
//                        
//                                            
//                     
//                                    foreach($results as $result) {
//
//                        $entries = $xpath->query("/div", $result);

//foreach ($entries as $entry) {
//    echo "Found {$entry->previousSibling->previousSibling->nodeValue}," .
//         " by {$entry->previousSibling->nodeValue}\n";
//}
                
                
//                $innerHTML = '';
//
//                // see http://fr.php.net/manual/en/class.domelement.php#86803
//                $children = $result->childNodes;
//                foreach ($children as $child) {
//                    $tmp_doc = new DOMDocument();
//                    $tmp_doc->appendChild($tmp_doc->importNode($child,true));       
//                    $innerHTML .= $tmp_doc->saveHTML();
//                }
//
//                //var_dump(trim($innerHTML));
//                echo $result->nodeValue.'<br>';
//                $xml = new new DOMDocument;
//                SimpleXMLElement($innerHTML);
//
///* Search for <a><b><c> */
//$r = $xml->xpath("/div[contains(@class, 'availability')]");
//  while(list( , $node) = each($r)) {
//    echo '/a/b/c: ',$node,"\n";
//}  
//                //$row = simplexml_load_string($resut->asXML()); 
                //$v = $row->xpath("//div[contains(@class, 'condition')]");
                //echo $v->nodeValue;
//            }
//if (DEBUG) {        
//        $j = 0;
//for ($i = 0; $i < $bodycontent->length; $i++) {
//    if (($condition->item($j)->nodeValue == "New") && ((strpos(strtolower($availability->item($j)->nodeValue),strtolower("In Stock"))!==FALSE) || (strpos(strtolower($availability->item($j)->nodeValue),strtolower("Usually ships within 2 - 3 business days"))!==FALSE))) {
//        echo $condition->item($j)->nodeValue.$bodycontent->length.$bodycontent->item($i)->getAttribute('class'). 
//                $condition->item($j)->nodeValue.$bodycontent->item($i)->nodeValue .($bodycontent->item($i)->getAttribute('class')=="price"?$availability->item($j)->getAttribute('class'). $availability->item($j)->nodeValue:'') . "<br>";
//    }
//    ($bodycontent->item($i)->getAttribute('class')=="price"?$j++:void);
//}           
//}
//    $j = 0;
//    $i = 0;
//    $price = 0;
//    if ($bodycontent->length == 1) {
//        echo (DEBUG?$bodycontent->item($i)->getAttribute('class'). $bodycontent->item($i)->nodeValue . "<br>":'');
//        if (($bodycontent->item($i)->getAttribute('class') == "price") && ((strpos($availability->item($j)->nodeValue,"In Stock")!==FALSE) || (strpos(strtolower($availability->item($j)->nodeValue),strtolower("Usually ships within 2 - 3 business days"))!==FALSE) ) && ((strpos(strtolower($bodycontent->item($i)->nodeValue),strtolower("Price not displayed"))===FALSE))) {
//            $price = preg_replace('/[^0-9]/','',$bodycontent->item($i)->nodeValue)/100;
//            $arrprice[] = $price;
//            echo (DEBUG? 'FOUND'.$price:'');;
//        }
//    }
//    else {
//        for ($i = 0; $i < $bodycontent->length; $i++) {
//            if (($bodycontent->item($i)->getAttribute('class') == "price") && ((strpos(strtolower($bodycontent->item($i)->nodeValue),strtolower("Price not displayed"))==FALSE))) {//($bodycontent->item($i)->getAttribute('class') <> "pricePerUnit") && ($bodycontent->item($i)->getAttribute('class') <> "price_shipping")
//            echo (DEBUG?$bodycontent->item($i)->getAttribute('class'). $bodycontent->item($i)->nodeValue .trim($condition->item($j)->nodeValue).$availability->item($j)->nodeValue. "<br>":'');
//                if ((trim($condition->item($j)->nodeValue) == "New") && ((strpos(strtolower($availability->item($j)->nodeValue),strtolower("In Stock"))!==FALSE) || (strpos(strtolower($availability->item($j)->nodeValue),strtolower("Usually ships within 2 - 3 business days"))!==FALSE))) {//($bodycontent->item($i)->getAttribute('class') <> "pricePerUnit") && ($bodycontent->item($i)->getAttribute('class') <> "price_shipping")
//
//                    $price = preg_replace('/[^0-9]/','',$bodycontent->item($i)->nodeValue)/100;
//                    //echo $bodycontent->item($i+1)->getAttribute('class'). $bodycontent->item($i+1)->nodeValue . "IN<br>";
//                    if (($i+1 < $bodycontent->length) && $bodycontent->item($i+1)->getAttribute('class') == "price_shipping") {
//                        $shipping = preg_replace('/[^0-9]/','',$bodycontent->item($i+1)->nodeValue)/100;
//                        $price += $shipping;
//                        $maxprice = $price > $maxprice? $price: $maxprice;
//                        echo (DEBUG?'maxprice:'.$maxprice.'<br>':'');
//                        $i++;
//                    }
//                    elseif (($i+1 < $bodycontent->length)) {
//                        $arrprice[] = $price;
//                        echo (DEBUG?$i.'-'.$j.'FOUND'.$price:'');
//                        break;
//                    }
//                    elseif (($i = ($bodycontent->length-1)) && $bodycontent->item($i)->getAttribute('class') == "price") {
//                        $arrprice[] = $price;
//                        echo (DEBUG?$i.'-'.$j.'FOUND'.$price:'');
//                        break;
//                    }
//                }
//                $j++;
//            }
//
//            echo (DEBUG?"total".$price:'');
//        }
//    }
//no ordenarlo, pues los primeros valores que entrega son los de los articulos nuevos, el problema seria cuando no hay nuevos y si hay usados.
    //asort($arrprice);
            }
        //print_r($arrprice);
//    return (count($arrprice)>0?$arrprice[0]:($maxprice>0?$maxprice.'noprime':'noprime'));
    
    }
    catch (Exception $e) {
        print_r($e);
        return 'noprime';
    }
}
?>
