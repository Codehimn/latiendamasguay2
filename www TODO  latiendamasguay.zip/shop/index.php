<?php
/*
Template Name: Search
http://woorkup.com/2010/09/13/how-to-create-your-own-instant-search/
In this file you need to change the path to instant.js <script type="text/javascript" src="PATH/TO/instant.js"></script><style>
*/
?>

<html>
<head>
<title>Instant Shop</title>	
<link title="Instant Shop" rel="search" type="application/opensearchdescription+xml" href="">
<meta name="Title" content="Instant Shop">
<meta name="DC.Title" content="Instant Shop">
<meta name="description" content="Instant Shop, let you find you Amazon products instantly. Million products, one search">
<meta name="DC.description" content="With Instant Shop, search million Amazon products instantly">
<meta name="keywords" content="Instant Shop, search Instant Shoply, amazon fast search, instant amazon">
<meta name="DC.subject" content="Instant Shop, search Instant Shoply, amazon fast search, instant amazon">

	<meta http-equiv="Content-Language" content="en">
	<meta content="en" scheme="DCTERMS.URI" name="DC.language">

<meta property="fb:admins" content="100000923283404">
<meta property="fb:app_id" content="185957791435335">
<meta property="og:description" content="Instant Shop, let you find Amazon products instantly. Million products, one search">
<meta property="og:title" content="Instant Shop">
<meta property="og:type" content="website">
<meta property="og:url" content="http://LaTiendaMasGuay.es">
<meta property="og:email" content="info@LaTiendaMasGuay.es">
<meta property="og:site_name" content="Search Million Amazon Products Instantly">    
<meta property="og:country-name" content="USA">
<meta name="robots" content="all"> 
<meta name="expires" content="never"> 
<meta name="distribution" content="world"> 
	
	<!-- <link rel="stylesheet" href="styles/nyroModal.css" type="text/css" media="screen" /> -->
	<link rel="icon" type="image/gif" href="favicon.ico">
	<link rel="shortcut icon" type="image/gif" href="favicon.ico">
	<meta name="DC.creator" content="LaTiendaMasGuay.es S.A.">
	 
	<meta name="DC.type" scheme="DCTERMS.DCMIType" content="Text"> 
	<meta name="DC.format" content="text/html"> 
	<meta name="DC.language" scheme="DCTERMS.URI" content="es"> 
	<meta name="copyright" content="Copyright (c) 2010 LaTiendaMasGuay.es S.A."> 
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	
	<meta name="Generator" content="Instant Shop">
        
       <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
        <script type="text/javascript" src="instant.js"></script>
        <script type="text/javascript" src="tooltip.js"></script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

<link rel="stylesheet" type="text/css" href="stylesheet.css" />
</head>
<body onLoad="document.searchform.q.focus()">
<div id="searchbox">
<span class="slogan"><br>Búsque Instantáneamente en Amazon.es</span>
    <form method="get" action="" name="searchform">
        <input type="text" id="q" name="q" class="lst" size="55" maxlength="2048" value="" autocomplete="off"/><br>
    </form>
</div>
<div id="header">
<ul id="tabs">
	<li id="selected"><a href="#">Todo</a></li>
<!--	<li><a href="#">Toys</a></li>
	<li><a href="#">The Other</a></li>
	<li><a href="#">Banana</a></li> -->
</ul>
</div>
<div id="results">
</div>
</body>
</html>