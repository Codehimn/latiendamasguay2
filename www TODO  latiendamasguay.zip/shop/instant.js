$(document).ready(function(){
var runningRequest = false;
    var request;

    $('input#q').keyup(function(e){
        e.preventDefault();
        var $q = $(this);
        if (e.keyCode > '14' && e.keyCode < '46' && e.keyCode != '9') {
			return false;
		}
        if($q.val() == ''){
            $('div#results').html('');
            return false;
        }

        //Abort opened requests to speed it up
        if(runningRequest){
            request.abort();
            resultHtml = '<DIV id="loading_image"><img src="loading.gif" style="border-style:none"/></DIV>';
            $('div#results').html(resultHtml);
        }

        runningRequest=true;


// THis needs to be changed to the location of the search.php file

        request = $.getJSON("search.php",{
            q:$q.val()
        },function(data){           
            showResults(data,$q.val());
            runningRequest=false;
        });

function showResults(data, highlight){
           var resultHtml = '';
            $.each(data, function(i,item){
                resultHtml+='<div class="result">';
                resultHtml+=item.title;
                resultHtml+=item.content;
                resultHtml+='<div id="clear"></div>';
                resultHtml+='</div>';
            });

            $('div#results').html(resultHtml);
        }

        $('form').submit(function(e){
            e.preventDefault();
        });
    });
 });
