<?php
if(!empty($_GET['q'])) {
    searchamazon();
}
function search() {
define(KEYWORD_OFFSET,200);
$con = mysql_connect('localhost','juguetes1a', 'juguetes1a');
    mysql_select_db('juguetes_j1adb', $con);

    $q = htmlspecialchars($_GET['q']);

    $sql = mysql_query("
        SELECT
            pd.products_name as title, SUBSTR(pd.products_description,1,300) as post
        FROM osc_products_description pd
        WHERE pd.products_name LIKE '%{$q}%' OR pd.products_description LIKE '%{$q}%'
        ");

    //Create an array with the results
    $results=array();
    while($v = mysql_fetch_object($sql)){
        $results[] = array(
          'title'=>$v->title,
          'content'=>$v->post
        );
    }

    //using JSON to encode the array
    echo json_encode($results);
}
function searchamazon(){
    include_once("amazonapi/amazon_api_class.php");
	include_once("amazonapi/config.php");
    $obj = new AmazonProductAPI();
    $keyword = $_GET['q'];
	try
    {
        $amazonresults = $obj->getItemByKeyword($keyword,
                                       AmazonProductAPI::ALL);
    }
    catch(Exception $e)
    {
        $e->getMessage();
    }
//echo json_encode($results);            
if (isset($amazonresults->Items->Item)) {
	

foreach ($amazonresults->Items->Item as $Item){
	//foreach ($result->Offers->Offer as $Offer){	
	//}
	$description = "";
	$desc_brief = "";
    if ($Item->EditorialReviews->EditorialReview) {
	    foreach ($Item->EditorialReviews->EditorialReview as $EditorialReview){
	    	$description .= $EditorialReview->Content;//str_replace("\n",'',str_replace("\t",'',$EditorialReview->Content));
		    $desc_brief = strip_tags($description);
		    $keypos = strpos($desc_brief, $keyword, 1);
		    $desc_brief = substr($desc_brief,0,350);
		    $desc_brief = hightlight($desc_brief, $keyword,'hll');
		    break;
	    }	    
    }
    $imagedesc = '<div><h3>'.$Item->ASIN.'</h3>'.'</div>';
    $tooltiptext = '<div>ASIN: '.$Item->ASIN.'<br><img src=' . $Item->LargeImage->URL . ' /></div> ';//str_replace("'","�",$imagedesc).
    $image = '<div id="image"><a href="'.$Item->Offers->MoreOffersUrl.'"  target="_blank" style="border-style:none" onmouseout="hideTooltip()" onmouseover="showTooltip(event,\''.$tooltiptext.'\');return false"><img src="' . $Item->SmallImage->URL . '" style="border-style:none" ALIGN="left"/></a></div>';
    $price = "<font color='grey' size='-1'><s>".$Item->ItemAttributes->ListPrice->FormattedPrice."</s></font>  <font color='red'>".$Item->OfferSummary->LowestNewPrice->FormattedPrice."</font>";
    //$title = '<div id="image"><a href="'.$Item->Offers->MoreOffersUrl.'"  target="_blank" style="border-style:none" onmouseout="hideTooltip()" onmouseover="showTooltip(event,\''."<img src=" . $Item->LargeImage->URL . " />".' \');return false">'.$image.'</a></div>';
    $title = '<div id="content">'.$image.'<h2><a href="'.$Item->Offers->MoreOffersUrl.'"  target="_blank" style="border-style:none" onmouseout="hideTooltip()" onmouseover="showTooltip(event,\''.$tooltiptext.'\');return false">'.hightlight($Item->ItemAttributes->Title, $keyword,'hll').'</a>  '.$price.'</h2>';
    $desc_brief = '<p>'.$desc_brief.'</p>';
    $desc_brief.='<a href="'.$Item->Offers->MoreOffersUrl.'" class="readMore" target="_blank">Read more..</a></div>';
    /*<iframe src="http://www.facebook.com/plugins/like.php?href='.$Item->Offers->MoreOffersUrl.'%2F&amp;layout=button_count&amp;show_faces=true&amp;width=50&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:visible; width:120px; height:21px;" allowTransparency="true"></iframe>*/
	$results[] = array(
          'title'=>$title,
          'content'=>$desc_brief //$result->SmallImage->URL
          );
}
}
else {
	$results[] = array(
          'title'=>$keyword." not found",
          'content'=>implode(",",$amazonresults)
          );

}
echo json_encode($results);	
}

function hightlight($str, $keywords = '', $style = '')
{
$keywords = preg_replace('/\s\s+/', ' ', strip_tags(trim($keywords))); // filter

//$style = 'highlight';
$style_i = 'highlight_important';

/* Apply Style */

$var = '';

foreach(explode(' ', $keywords) as $keyword)
{
$replacement = "<span class='".$style."'>".$keyword."</span>";
$var .= $replacement." ";

$str = str_ireplace($keyword, $replacement, $str);
}

/* Apply Important Style */

//$str = str_ireplace(rtrim($var), "<span class='".$style_i."'>".$keywords."</span>", $str);

return $str;
}
?>
