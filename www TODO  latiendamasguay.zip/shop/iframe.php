<iframe src="http://latiendamasguay.es/shop/index.php" width="100%" height="1000">
  <p>Your browser does not support iframes.</p>
</iframe>
<?php



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>